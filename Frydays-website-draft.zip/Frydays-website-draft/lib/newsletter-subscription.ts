import { ReplitConnectors } from "@replit/connectors-sdk"

type ResendContact = {
  unsubscribed?: boolean
}

export class NewsletterSubscriptionError extends Error {
  constructor(readonly status: number | "connection error") {
    super(`Resend newsletter subscription failed with status ${status}`)
    this.name = "NewsletterSubscriptionError"
  }
}

async function getContact(connectors: ReplitConnectors, email: string): Promise<ResendContact | null> {
  const response = await connectors.proxy("resend", `/contacts/${encodeURIComponent(email)}`, {
    method: "GET",
  })

  if (response.status === 404) return null
  if (!response.ok) throw new NewsletterSubscriptionError(response.status)

  const body = await response.json() as { data?: unknown; unsubscribed?: unknown }
  const contact = body.data && typeof body.data === "object"
    ? body.data as ResendContact
    : body as ResendContact
  if (typeof contact.unsubscribed !== "boolean") {
    throw new NewsletterSubscriptionError(response.status)
  }

  return contact
}

async function resubscribe(connectors: ReplitConnectors, email: string) {
  const response = await connectors.proxy("resend", `/contacts/${encodeURIComponent(email)}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ unsubscribed: false }),
  })
  if (!response.ok) throw new NewsletterSubscriptionError(response.status)
}

export async function subscribeToNewsletter(rawEmail: string) {
  const email = rawEmail.trim().toLowerCase()
  const connectors = new ReplitConnectors()
  let existingContact: ResendContact | null

  try {
    existingContact = await getContact(connectors, email)
  } catch (error) {
    if (error instanceof NewsletterSubscriptionError) throw error
    throw new NewsletterSubscriptionError("connection error")
  }

  if (existingContact) {
    if (existingContact.unsubscribed) {
      await resubscribe(connectors, email)
      return { alreadySubscribed: false }
    }
    return { alreadySubscribed: true }
  }

  const response = await connectors.proxy("resend", "/contacts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, unsubscribed: false }),
  })

  if (response.status === 409) {
    const racedContact = await getContact(connectors, email)
    if (racedContact?.unsubscribed) {
      await resubscribe(connectors, email)
      return { alreadySubscribed: false }
    }
    if (racedContact) return { alreadySubscribed: true }
  }

  if (!response.ok) throw new NewsletterSubscriptionError(response.status)
  return { alreadySubscribed: false }
}

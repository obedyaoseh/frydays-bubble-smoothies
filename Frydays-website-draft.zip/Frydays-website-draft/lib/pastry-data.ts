export type PastryItem = {
  id: string
  type: "pastry"
  name: string
  price: number
}

export const pastryItems: PastryItem[] = [
  { id: "pastry-meat-pie", type: "pastry", name: "Meat pie", price: 15 },
  { id: "pastry-croissant", type: "pastry", name: "Croissant", price: 40 },
  { id: "pastry-spring-roll", type: "pastry", name: "Spring roll", price: 5 },
  { id: "pastry-samosa", type: "pastry", name: "Samosa", price: 5 },
  { id: "pastry-doughnut", type: "pastry", name: "Doughnut", price: 15 },
  { id: "pastry-banana-bread", type: "pastry", name: "Banana bread", price: 15 },
  { id: "pastry-sausage-roll", type: "pastry", name: "Sausage roll", price: 5 },
  { id: "pastry-burger", type: "pastry", name: "Burger", price: 40 },
  { id: "pastry-cupcake", type: "pastry", name: "Cupcake", price: 15 },
]

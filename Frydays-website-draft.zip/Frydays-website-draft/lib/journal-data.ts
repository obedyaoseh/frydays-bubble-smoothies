export type JournalStory = {
  slug: string
  category: string
  title: string
  excerpt: string
  body: string[]
  image: string
  accent: string
}

export const journalStories: JournalStory[] = [
  {
    slug: "little-rituals",
    category: "Frydays Stories",
    title: "The little rituals that make a day",
    excerpt: "A good drink can be a small pause, a shared laugh, or the reason a friend stays a little longer.",
    body: [
      "Some of our favourite Frydays moments are the ones that were never planned. Someone drops by after work. A family orders one more drink for the table. Two friends turn a quick pickup into a long catch-up.",
      "That is what we mean when we say every day deserves a little Friday. It is not about waiting for a special occasion. It is about making room for small, good things while the day is still happening.",
      "So take the scenic route home. Order the flavour you have never tried. Pull up a chair and stay a little longer. We will keep the blender running.",
    ],
    image: "/images/signature-blueberry.jpg",
    accent: "Bright & icy",
  },
  {
    slug: "behind-the-pour",
    category: "Behind the Cup",
    title: "What goes into a Frydays pour",
    excerpt: "Fresh ingredients, thoughtful combinations, and a little room for you to make it yours.",
    body: [
      "Every drink starts with a simple question: what would make this taste better today? Sometimes the answer is a bright fruit, sometimes it is a creamy finish, and sometimes it is the perfect amount of ice.",
      "Our menu is made to be explored. Choose your size, find your sweetness, add a topping, or keep it clean. The best drink is the one that feels like it was made for you.",
      "Behind every colourful cup is a team paying attention to the details — the texture, the balance, the last pour, and the smile across the counter.",
    ],
    image: "/images/signature-matcha-pour.jpg",
    accent: "Clean & earthy",
  },
  {
    slug: "built-around-the-table",
    category: "From Our Community",
    title: "Built around the table",
    excerpt: "Frydays began with family and is growing through the people who keep showing up.",
    body: [
      "Frydays was born in Teshie, around a family kitchen counter and the belief that food tastes better when there is someone to share it with.",
      "Today, that same feeling shows up in different ways: neighbours saying hello, students making a quick stop between plans, and friends bringing someone new through the door.",
      "We are building more than a drinks bar. We are building a warm, open place where people can meet, create memories, and find something good in the middle of an ordinary day.",
    ],
    image: "/images/signature-pistachio.jpg",
    accent: "Smooth & indulgent",
  },
]

export function getJournalStory(slug: string) {
  return journalStories.find((story) => story.slug === slug)
}
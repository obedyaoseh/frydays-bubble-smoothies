import { ReplitConnectors } from "@replit/connectors-sdk"

export const contactSubjects = {
  order: "Place an Order",
  event: "Book for an Event",
  corporate: "Corporate Wellness",
  partnership: "Partnership or Franchise",
  supplier: "Supplier Enquiry",
  general: "General Enquiry",
} as const

export type ContactSubject = keyof typeof contactSubjects

export type ContactEmailDetails = {
  name: string
  email: string
  subject: ContactSubject
  message: string
}

const FRYDAYS_SENDER_EMAIL = "order@frydaysghana.com"
const FRYDAYS_CONTACT_EMAIL = "frydaysghana@gmail.com"

function escapeHtml(value: string) {
  return value.replace(/[&<>"']/g, (character) => {
    const entities: Record<string, string> = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    }
    return entities[character]
  })
}

export class ContactEmailDeliveryError extends Error {
  constructor(readonly status: number) {
    super(`Resend contact email request failed with status ${status}`)
    this.name = "ContactEmailDeliveryError"
  }
}

export async function sendContactEmail(details: ContactEmailDetails) {
  const subjectLabel = contactSubjects[details.subject]
  const safeName = escapeHtml(details.name)
  const safeEmail = escapeHtml(details.email)
  const safeMessageHtml = escapeHtml(details.message).replace(/\r?\n/g, "<br>")
  const emailSubject = `New contact message: ${subjectLabel}`
  const text = [
    "New message from the Frydays website",
    "",
    `Name: ${details.name}`,
    `Email: ${details.email}`,
    `Subject: ${subjectLabel}`,
    "",
    details.message,
  ].join("\n")
  const html = `<!doctype html>
<html lang="en">
  <body style="margin:0;background:#f5f0e5;color:#09403b;font-family:Arial,sans-serif;">
    <div style="max-width:620px;margin:24px auto;padding:28px;background:#ffffff;border-radius:16px;">
      <p style="margin:0 0 8px;color:#648078;font-size:12px;font-weight:bold;letter-spacing:2px;text-transform:uppercase;">Frydays Bubble &amp; Smoothies Bar</p>
      <h1 style="margin:0 0 20px;font-size:24px;">New website message</h1>
      <p><strong>Subject:</strong> ${escapeHtml(subjectLabel)}</p>
      <p><strong>Name:</strong> ${safeName}<br><strong>Email:</strong> <a href="mailto:${safeEmail}">${safeEmail}</a></p>
      <div style="margin-top:20px;padding:16px;background:#f5f0e5;border-radius:12px;line-height:1.6;">${safeMessageHtml}</div>
    </div>
  </body>
</html>`

  const connectors = new ReplitConnectors()
  const response = await connectors.proxy("resend", "/emails", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      from: `Frydays Bubble & Smoothies Bar <${FRYDAYS_SENDER_EMAIL}>`,
      to: FRYDAYS_CONTACT_EMAIL,
      reply_to: details.email,
      subject: emailSubject,
      text,
      html,
    }),
  })

  if (!response.ok) throw new ContactEmailDeliveryError(response.status)
}

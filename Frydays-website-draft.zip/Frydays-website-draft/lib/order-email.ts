import { ReplitConnectors } from "@replit/connectors-sdk"

const FRYDAYS_SENDER_EMAIL = "order@frydaysghana.com"
const FRYDAYS_NOTIFICATION_EMAIL = "frydaysghana@gmail.com"
const FRYDAYS_REPLY_EMAIL = "frydaysghana@gmail.com"

export type OrderEmailLine = {
  name: string
  quantity: number
  unitPrice: number
  lineTotal: number
  details: string
}

export type OrderEmailDetails = {
  orderReference: string
  customer: {
    name: string
    email: string
    phone: string
  }
  fulfillment: {
    type: string
    area: string
    address?: string
  }
  paymentMethod: string
  items: OrderEmailLine[]
  subtotal: number
  discount: number
  deliveryFee: number
  total: number
  promoCode?: string
  notes?: string
  placedAt: string
}

type OrderEmailAudience = "frydays" | "customer"

function escapeHtml(value: string) {
  return value.replace(/[&<>"']/g, (character) => {
    const entities: Record<string, string> = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    }
    return entities[character]
  })
}

function formatMoney(value: number) {
  return `GH₵ ${value.toFixed(2)}`
}

function buildEmailContent(details: OrderEmailDetails, audience: OrderEmailAudience) {
  const isFrydays = audience === "frydays"
  const subject = isFrydays
    ? `New Frydays order ${details.orderReference}`
    : `Frydays order request received — ${details.orderReference}`
  const title = isFrydays ? "New order request" : "We received your order"
  const intro = isFrydays
    ? `A new order request was submitted on ${details.placedAt}.`
    : `Hi ${details.customer.name}, thanks for ordering from Frydays. We received your order request on ${details.placedAt}.`
  const itemText = details.items.map((item) => {
    const extra = item.details ? ` — ${item.details}` : ""
    return `${item.quantity} × ${item.name}${extra}: ${formatMoney(item.lineTotal)}`
  })
  const fulfillmentText = `${details.fulfillment.type} · ${details.fulfillment.area}`
  const textLines = [
    title,
    "",
    intro,
    `Order reference: ${details.orderReference}`,
    `Fulfillment: ${fulfillmentText}`,
    ...(isFrydays && details.fulfillment.address ? [`Delivery address: ${details.fulfillment.address}`] : []),
    `Payment option: ${details.paymentMethod}`,
    "",
    "Items:",
    ...itemText,
    "",
    `Subtotal: ${formatMoney(details.subtotal)}`,
    ...(details.discount > 0 ? [`${details.promoCode ? `Discount (${details.promoCode})` : "Discount"}: -${formatMoney(details.discount)}`] : []),
    ...(details.deliveryFee > 0 ? [`Delivery fee: ${formatMoney(details.deliveryFee)}`] : []),
    `Total: ${formatMoney(details.total)}`,
    ...(details.notes ? ["", `Order notes: ${details.notes}`] : []),
    "",
    isFrydays
      ? `Reply to ${details.customer.email} or call ${details.customer.phone} to confirm the order.`
      : "The Frydays team will contact you by phone or WhatsApp to confirm your order and pickup or delivery details.",
  ]
  const tableRows = details.items.map((item) => `
    <tr>
      <td style="padding:12px 8px;border-bottom:1px solid #e8e1d1;">
        <strong>${item.quantity} × ${escapeHtml(item.name)}</strong>
        ${item.details ? `<br><span style="color:#64716c;font-size:13px;">${escapeHtml(item.details)}</span>` : ""}
      </td>
      <td style="padding:12px 8px;border-bottom:1px solid #e8e1d1;text-align:right;white-space:nowrap;">${formatMoney(item.lineTotal)}</td>
    </tr>`).join("")
  const totalRows = [
    `<tr><td style="padding:6px 8px;">Subtotal</td><td style="padding:6px 8px;text-align:right;">${formatMoney(details.subtotal)}</td></tr>`,
    ...(details.discount > 0
      ? [`<tr><td style="padding:6px 8px;">${details.promoCode ? `Discount (${escapeHtml(details.promoCode)})` : "Discount"}</td><td style="padding:6px 8px;text-align:right;">-${formatMoney(details.discount)}</td></tr>`]
      : []),
    ...(details.deliveryFee > 0
      ? [`<tr><td style="padding:6px 8px;">Delivery fee</td><td style="padding:6px 8px;text-align:right;">${formatMoney(details.deliveryFee)}</td></tr>`]
      : []),
    `<tr><td style="padding:12px 8px;border-top:1px solid #d8cfbc;font-weight:700;">Total</td><td style="padding:12px 8px;border-top:1px solid #d8cfbc;text-align:right;font-weight:700;">${formatMoney(details.total)}</td></tr>`,
  ].join("")
  const recipientDetails = isFrydays
    ? `<p><strong>Customer:</strong> ${escapeHtml(details.customer.name)}<br><strong>Email:</strong> ${escapeHtml(details.customer.email)}<br><strong>Phone:</strong> ${escapeHtml(details.customer.phone)}</p>`
    : ""
  const addressDetails = isFrydays && details.fulfillment.address
    ? `<p><strong>Delivery address:</strong> ${escapeHtml(details.fulfillment.address)}</p>`
    : ""
  const notesDetails = details.notes ? `<p><strong>Order notes:</strong><br>${escapeHtml(details.notes).replace(/\n/g, "<br>")}</p>` : ""
  const nextStep = isFrydays
    ? "Reply to the customer by email or call/WhatsApp to confirm the order."
    : "The Frydays team will contact you by phone or WhatsApp to confirm your order and pickup or delivery details."
  const html = `<!doctype html>
<html lang="en">
  <body style="margin:0;background:#f5f0e5;color:#09403b;font-family:Arial,sans-serif;">
    <div style="max-width:620px;margin:24px auto;padding:28px;background:#ffffff;border-radius:16px;">
      <p style="margin:0 0 8px;color:#648078;font-size:12px;font-weight:bold;letter-spacing:2px;text-transform:uppercase;">Frydays Bubble &amp; Smoothies Bar</p>
      <h1 style="margin:0 0 12px;font-size:26px;">${title}</h1>
      <p style="line-height:1.6;">${escapeHtml(intro)}</p>
      <p><strong>Order reference:</strong> ${escapeHtml(details.orderReference)}<br><strong>Fulfillment:</strong> ${escapeHtml(fulfillmentText)}<br><strong>Payment option:</strong> ${escapeHtml(details.paymentMethod)}</p>
      ${recipientDetails}
      ${addressDetails}
      <table role="presentation" style="width:100%;border-collapse:collapse;margin-top:20px;">
        <thead><tr><th style="padding:8px;text-align:left;border-bottom:2px solid #09403b;">Item</th><th style="padding:8px;text-align:right;border-bottom:2px solid #09403b;">Amount</th></tr></thead>
        <tbody>${tableRows}</tbody>
      </table>
      <table role="presentation" style="width:100%;border-collapse:collapse;margin-top:12px;">${totalRows}</table>
      ${notesDetails}
      <p style="margin-top:24px;line-height:1.6;color:#53635d;">${escapeHtml(nextStep)}</p>
    </div>
  </body>
</html>`

  return {
    to: isFrydays ? FRYDAYS_NOTIFICATION_EMAIL : details.customer.email,
    subject,
    text: textLines.join("\n"),
    html,
  }
}

export class OrderEmailDeliveryError extends Error {
  constructor(readonly status: number) {
    super(`Resend email request failed with status ${status}`)
    this.name = "OrderEmailDeliveryError"
  }
}

export async function sendOrderEmail(details: OrderEmailDetails, audience: OrderEmailAudience) {
  const message = buildEmailContent(details, audience)
  const connectors = new ReplitConnectors()
  const response = await connectors.proxy("resend", "/emails", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      from: `Frydays Bubble & Smoothies Bar <${FRYDAYS_SENDER_EMAIL}>`,
      to: message.to,
      reply_to: FRYDAYS_REPLY_EMAIL,
      subject: message.subject,
      text: message.text,
      html: message.html,
    }),
  })

  if (!response.ok) throw new OrderEmailDeliveryError(response.status)
}

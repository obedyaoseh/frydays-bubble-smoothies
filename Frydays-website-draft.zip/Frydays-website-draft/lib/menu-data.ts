export type MenuItem = {
  id: number
  name: string
  tagline: string
  description: string
  image: string
  bgColor: string
  accentColor: string
  tags: string[]
  price: number
}

export const menuItems: MenuItem[] = [
  {
    id: 1,
    name: "Matcha Cloud",
    tagline: "Our Signature",
    description: "Creamy matcha with a soft whipped finish — earthy, smooth, and made for a slower sip.",
    image: "/images/signature-matcha.jpg",
    bgColor: "from-emerald-200/30 via-emerald-100/10 to-transparent",
    accentColor: "#09403B",
    tags: ["Bubble Pearls", "Real Fruit", "Customisable", "Fan Favourite"],
    price: 36,
  },
  {
    id: 2,
    name: "Blueberry Slush",
    tagline: "Bright & Icy",
    description: "A cool, berry-forward slush made with bright blueberry flavour and a refreshing finish.",
    image: "/images/signature-blueberry.jpg",
    bgColor: "from-green-300/30 via-green-100/10 to-transparent",
    accentColor: "#2d8c5a",
    tags: ["Detox", "Vitamins", "Cold-Pressed", "Low Calorie"],
    price: 36,
  },
  {
    id: 3,
    name: "Pistachio Cream",
    tagline: "Smooth & Indulgent",
    description: "A rich, nutty pistachio blend with a creamy texture and a little everyday indulgence.",
    image: "/images/signature-pistachio.jpg",
    bgColor: "from-purple-300/30 via-purple-100/10 to-transparent",
    accentColor: "#7c3aed",
    tags: ["Antioxidants", "Thick Blend", "No Added Sugar", "Berry Rich"],
    price: 36,
  },
  {
    id: 4,
    name: "Matcha Pour",
    tagline: "Clean & Earthy",
    description: "A fresh matcha pour with a clean, earthy taste and gentle natural energy.",
    image: "/images/signature-matcha-pour.jpg",
    bgColor: "from-orange-300/30 via-orange-100/10 to-transparent",
    accentColor: "#f59e0b",
    tags: ["Vitamin C", "Fresh Squeezed", "Immunity Boost", "Energy"],
    price: 36,
  },
  {
    id: 5,
    name: "Green Glow",
    tagline: "Fresh & Made to Order",
    description: "A fresh green blend poured to order for a bright, feel-good start to the day.",
    image: "/images/signature-green-pour.jpg",
    bgColor: "from-amber-900/20 via-amber-700/10 to-transparent",
    accentColor: "#92400e",
    tags: ["Creamy", "Indulgent", "Natural Cocoa", "Crowd Pleaser"],
    price: 36,
  },
]
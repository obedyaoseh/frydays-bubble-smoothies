import type { Metadata } from "next"

export const SITE_URL = "https://frydays-website-draft--yaosehobed.replit.app"
export const SITE_NAME = "Frydays Bubble & Smoothies Bar"
export const DEFAULT_DESCRIPTION =
  "Order fresh smoothies, bubble tea, and pastries from Frydays in Teshie, Accra. Customize your drink and choose pickup or delivery."
export const SOCIAL_IMAGE_PATH = "/opengraph-image"

type PageMetadataInput = {
  title: string
  description: string
  path: string
  type?: "website" | "article"
}

export function pageMetadata({ title, description, path, type = "website" }: PageMetadataInput): Metadata {
  return {
    title,
    description,
    alternates: { canonical: path },
    openGraph: {
      type,
      title,
      description,
      url: path,
      siteName: SITE_NAME,
      locale: "en_GH",
      images: [{
        url: SOCIAL_IMAGE_PATH,
        width: 1200,
        height: 630,
        alt: "Frydays smoothies, bubble tea, and pastries in Teshie, Accra",
      }],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [SOCIAL_IMAGE_PATH],
    },
  }
}

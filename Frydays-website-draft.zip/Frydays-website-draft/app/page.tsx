import { Navigation } from "@/components/navigation"
import { HeroSection } from "@/components/hero-section"
import { HomepageSections } from "@/components/homepage-sections"
import { LifestyleSection } from "@/components/lifestyle-section"
import { Footer } from "@/components/footer"
import { pageMetadata } from "@/lib/seo"

export const metadata = pageMetadata({
  title: "Fresh Smoothies & Bubble Tea in Teshie",
  description: "Order fresh smoothies, bubble tea, and pastries from Frydays in Teshie, Accra. Customize your drink and choose pickup or delivery.",
  path: "/",
})

export default function Home() {
  return (
    <main className="min-h-screen bg-[#F2DBB2]">
      <Navigation />
      <HeroSection />
      <HomepageSections />
      <LifestyleSection />
      <Footer />
    </main>
  )
}

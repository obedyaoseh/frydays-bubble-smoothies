import type { Metadata } from "next"
import type { ReactNode } from "react"
import { pageMetadata } from "@/lib/seo"

export const metadata: Metadata = pageMetadata({
  title: "Order Smoothies, Bubble Tea & Pastries",
  description: "Browse Frydays smoothies, bubble tea, and pastries in Teshie, Accra. Customize your drink and request pickup or local delivery.",
  path: "/order",
})

export default function OrderLayout({ children }: { children: ReactNode }) {
  return children
}

"use client"

import Image from "next/image"
import Link from "next/link"
import { useState } from "react"
import { Minus, Plus, ShoppingBag, Trash2, CheckCircle2, ArrowLeft } from "lucide-react"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { menuItems } from "@/lib/menu-data"
import { pastryItems } from "@/lib/pastry-data"
import { useCart } from "@/components/cart-provider"
import { ProductCustomizationModal } from "@/components/product-customization-modal"

export default function OrderPage() {
  const { cart, addToCart, updateQuantity, removeFromCart, total, itemCount, clearCart, openCart } = useCart()
  const [showCheckout, setShowCheckout] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [orderError, setOrderError] = useState("")
  const [orderReference, setOrderReference] = useState("")
  const [receiptSent, setReceiptSent] = useState(false)
  const [activeItem, setActiveItem] = useState<(typeof menuItems)[number] | null>(null)
  const [customer, setCustomer] = useState({ name: "", email: "", phone: "", pickup: "Pickup at Teshie bar", address: "", notes: "" })

  const submitOrder = async (event: React.FormEvent) => {
    event.preventDefault()
    setOrderError("")
    setIsSubmitting(true)

    const isDelivery = customer.pickup === "Delivery in Teshie"
    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customer: { name: customer.name, email: customer.email, phone: customer.phone },
          orderType: isDelivery ? "delivery" : "pickup",
          deliveryZone: isDelivery ? "teshie" : null,
          address: isDelivery ? customer.address : "",
          paymentMethod: "pending",
          notes: customer.notes,
          items: cart.map((line) => ({
            itemId: line.item.id,
            quantity: line.quantity,
            customization: line.customization,
          })),
        }),
      })
      const result = await response.json().catch(() => null)

      if (!response.ok || !result?.ok) {
        setOrderError(result?.error ?? "We couldn’t send your order. Your basket is unchanged; please try again or contact Frydays.")
        return
      }

      setOrderReference(result.orderReference)
      setReceiptSent(result.receiptSent === true)
      setSubmitted(true)
      clearCart()
    } catch {
      setOrderError("We couldn’t confirm that Frydays received your order. Your basket is unchanged; please contact Frydays before retrying to avoid a duplicate order.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <main className="min-h-screen bg-[#F2DBB2] text-[#09403B]">
      <Navigation />
      <section className="pt-32 pb-10 bg-[#09403B] text-[#F2DBB2]">
        <div className="max-w-7xl mx-auto px-6">
          <Link href="/" className="inline-flex items-center gap-2 text-sm font-semibold text-[#F2DBB2]/70 hover:text-[#F2DBB2]">
            <ArrowLeft className="w-4 h-4" /> Back home
          </Link>
          <h1 className="text-5xl md:text-6xl font-black tracking-tight mt-8">Order Smoothies, Bubble Tea &amp; Pastries</h1>
          <p className="mt-3 max-w-xl text-[#F2DBB2]/70 font-medium">Choose your favourites from Frydays in Teshie, Accra, then request pickup or local delivery.</p>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 py-12 grid lg:grid-cols-[1fr_380px] gap-10 items-start">
        <div>
          <section id="drinks" aria-labelledby="drinks-heading" className="scroll-mt-28">
            <div className="mb-6 flex items-center justify-between">
              <h2 id="drinks-heading" className="text-2xl font-black">Smoothies &amp; bubble tea</h2>
              <span className="text-sm font-semibold text-[#09403B]/50">{menuItems.length} favourites</span>
            </div>
            <div className="grid gap-5 sm:grid-cols-2">
              {menuItems.map((item) => (
                <article key={item.id} className="flex gap-4 rounded-2xl bg-[#09403B] p-4 text-[#F2DBB2]">
                  <div className="relative h-28 w-28 shrink-0 overflow-hidden rounded-xl bg-white/10">
                    <Image src={item.image} alt={item.name} fill className="object-cover" />
                  </div>
                  <div className="flex min-w-0 flex-col">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-[#F2DBB2]/50">{item.tagline}</span>
                    <h3 className="mt-1 text-lg font-black leading-tight">{item.name}</h3>
                    <p className="mt-auto text-sm font-bold text-[#F2DBB2]/70">GH₵ {item.price}</p>
                    <button
                      onClick={() => setActiveItem(item)}
                      className="mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-[#F2DBB2] px-3 py-2 text-xs font-black text-[#09403B] transition-colors hover:bg-white"
                    >
                      <Plus className="h-3 w-3" /> Customize
                    </button>
                  </div>
                </article>
              ))}
            </div>
          </section>

          <section id="pastries" className="mt-12 scroll-mt-28" aria-labelledby="pastries-heading">
            <div className="mb-6 flex flex-wrap items-end justify-between gap-2">
              <div>
                <h2 id="pastries-heading" className="text-2xl font-black">Pastries, desserts &amp; bites</h2>
                <p className="mt-1 text-sm font-medium text-[#09403B]/55">Add a bite to your order.</p>
              </div>
              <span className="text-sm font-semibold text-[#09403B]/50">{pastryItems.length} options</span>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              {pastryItems.map((item) => {
                const quantityInOrder = cart.find((line) => line.item.id === item.id)?.quantity ?? 0
                return (
                  <article key={item.id} className="flex items-center justify-between gap-4 rounded-2xl border border-[#09403B]/10 bg-white/35 p-4">
                    <div>
                      <h3 className="font-black">{item.name}</h3>
                      <p className="mt-1 text-sm font-bold text-[#09403B]/60">GH₵ {item.price}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => addToCart(item)}
                      aria-label={`Add ${item.name} for GH₵ ${item.price}`}
                      className="inline-flex min-h-10 shrink-0 items-center gap-2 rounded-full bg-[#09403B] px-4 text-xs font-black text-[#F2DBB2] transition-colors hover:bg-[#0f5c54]"
                    >
                      <Plus className="h-3 w-3" />
                      {quantityInOrder > 0 ? `Add more · ${quantityInOrder}` : "Add"}
                    </button>
                  </article>
                )
              })}
            </div>
          </section>
        </div>

        <aside className="bg-white/35 border-2 border-[#09403B]/10 rounded-3xl p-6 lg:sticky lg:top-28">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-black flex items-center gap-2"><ShoppingBag className="w-5 h-5" /> Your order</h2>
            {itemCount > 0 && <span className="rounded-full bg-[#09403B] text-[#F2DBB2] px-2.5 py-1 text-xs font-black">{itemCount}</span>}
          </div>

          {submitted ? (
            <div className="py-12 text-center">
              <CheckCircle2 className="w-12 h-12 mx-auto text-[#2d8c5a]" />
              <h3 className="text-xl font-black mt-4">Order received!</h3>
              <p className="text-sm text-[#09403B]/60 mt-2">
                {orderReference && <>Reference: <strong>{orderReference}</strong>. </>}
                {receiptSent
                  ? `A confirmation was sent to ${customer.email}. We’ll contact you shortly to confirm your order.`
                  : "Frydays received your order. The team will contact you shortly; the email receipt could not be sent."}
              </p>
              <button onClick={() => setSubmitted(false)} className="mt-6 rounded-full bg-[#09403B] text-[#F2DBB2] px-5 py-3 text-sm font-black">Place another order</button>
            </div>
          ) : cart.length === 0 ? (
            <div className="py-12 text-center">
              <ShoppingBag className="w-10 h-10 mx-auto text-[#09403B]/25" />
              <p className="font-bold mt-4">Your basket is empty.</p>
              <p className="text-sm text-[#09403B]/50 mt-1">Add a smoothie or pastry to get started.</p>
            </div>
          ) : (
            <>
              <div className="space-y-4 mt-6">
                 {cart.map((line) => (
                   <div key={line.lineId} className="flex items-center gap-3">
                     {"image" in line.item ? (
                       <div className="relative h-12 w-12 shrink-0 overflow-hidden rounded-lg">
                         <Image src={line.item.image} alt={line.item.name} fill className="object-cover" />
                       </div>
                     ) : (
                       <div aria-hidden="true" className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-[#09403B]/[0.06] text-[#09403B]/55">
                         <ShoppingBag className="h-5 w-5" />
                       </div>
                     )}
                    <div className="min-w-0 flex-1">
                       <p className="font-black text-sm truncate">{line.item.name}</p>
                         <p className="text-xs font-bold text-[#09403B]/50">{line.customization ? `${line.customization.size === "Regular" ? "Regular · 500 ml" : line.customization.size} · ${line.customization.sweetness} sugar` : "Pastry"}</p>
                       <p className="text-xs font-bold text-[#09403B]/50">GH₵ {(line.unitPrice * line.quantity).toFixed(2)}</p>
                    </div>
                    <div className="flex items-center gap-2">
                       <button onClick={() => updateQuantity(line.lineId, line.quantity - 1)} className="w-6 h-6 rounded-full border border-[#09403B]/20 flex items-center justify-center"><Minus className="w-3 h-3" /></button>
                      <span className="text-sm font-black w-3 text-center">{line.quantity}</span>
                       <button onClick={() => updateQuantity(line.lineId, line.quantity + 1)} className="w-6 h-6 rounded-full bg-[#09403B] text-[#F2DBB2] flex items-center justify-center"><Plus className="w-3 h-3" /></button>
                    </div>
                     <button onClick={() => removeFromCart(line.lineId)} aria-label={`Remove ${line.item.name}`} className="text-[#09403B]/35 hover:text-red-700"><Trash2 className="w-4 h-4" /></button>
                  </div>
                ))}
              </div>
              <div className="border-t border-[#09403B]/15 mt-6 pt-5 flex justify-between font-black text-lg">
                <span>Total</span><span>GH₵ {total}</span>
              </div>
              {!showCheckout ? (
               <button onClick={() => { setShowCheckout(true); openCart() }} className="w-full mt-5 rounded-xl bg-[#09403B] text-[#F2DBB2] py-4 font-black text-sm hover:bg-[#0f5c54] transition-colors">Continue to checkout</button>
              ) : (
                <form onSubmit={submitOrder} className="mt-5 space-y-3">
                  <p className="text-sm font-black">Your details</p>
                  <input required placeholder="Full name" value={customer.name} onChange={(e) => setCustomer({ ...customer, name: e.target.value })} className="w-full rounded-xl border-2 border-[#09403B]/15 bg-transparent px-3 py-3 text-sm outline-none focus:border-[#09403B]" />
                  <input required type="email" autoComplete="email" placeholder="Email for your receipt" value={customer.email} onChange={(e) => setCustomer({ ...customer, email: e.target.value })} className="w-full rounded-xl border-2 border-[#09403B]/15 bg-transparent px-3 py-3 text-sm outline-none focus:border-[#09403B]" />
                  <input required type="tel" placeholder="Phone / WhatsApp number" value={customer.phone} onChange={(e) => setCustomer({ ...customer, phone: e.target.value })} className="w-full rounded-xl border-2 border-[#09403B]/15 bg-transparent px-3 py-3 text-sm outline-none focus:border-[#09403B]" />
                  <select value={customer.pickup} onChange={(e) => setCustomer({ ...customer, pickup: e.target.value })} className="w-full rounded-xl border-2 border-[#09403B]/15 bg-transparent px-3 py-3 text-sm outline-none focus:border-[#09403B]">
                    <option>Pickup at Teshie bar</option><option>Delivery in Teshie</option>
                  </select>
                   {customer.pickup === "Delivery in Teshie" && (
                     <input required placeholder="Street name, house / landmark number" value={customer.address} onChange={(e) => setCustomer({ ...customer, address: e.target.value })} className="w-full rounded-xl border-2 border-[#09403B]/15 bg-transparent px-3 py-3 text-sm outline-none focus:border-[#09403B]" />
                   )}
                  <textarea placeholder="Order notes (optional)" rows={3} value={customer.notes} onChange={(e) => setCustomer({ ...customer, notes: e.target.value })} className="w-full rounded-xl border-2 border-[#09403B]/15 bg-transparent px-3 py-3 text-sm outline-none focus:border-[#09403B] resize-none" />
                   {orderError && <p role="alert" className="text-sm font-bold text-red-700">{orderError}</p>}
                   <button type="submit" disabled={isSubmitting} className="w-full rounded-xl bg-[#09403B] text-[#F2DBB2] py-4 font-black text-sm disabled:cursor-wait disabled:opacity-60">{isSubmitting ? "Sending order…" : "Submit order request"}</button>
                  <p className="text-[11px] text-[#09403B]/50 text-center">Payment is confirmed with our team by phone or WhatsApp.</p>
                </form>
              )}
            </>
          )}
        </aside>
      </section>
      <ProductCustomizationModal
        item={activeItem}
        onClose={() => setActiveItem(null)}
        onAddToCart={(item, customization, quantity) => {
          addToCart(item, customization, quantity)
          openCart()
        }}
      />
      <Footer />
    </main>
  )
}
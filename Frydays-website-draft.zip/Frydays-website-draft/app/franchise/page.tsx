import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { FranchiseContent } from "@/components/franchise-content"
import { pageMetadata } from "@/lib/seo"

export const metadata = pageMetadata({
  title: "Franchise & Partnership Opportunities",
  description: "Explore franchise, investment, and partnership opportunities with Frydays, a smoothie and bubble tea bar founded in Teshie, Accra.",
  path: "/franchise",
})

export default function FranchisePage() {
  return (
    <main className="min-h-screen bg-[#F2DBB2]">
      <Navigation />
      <FranchiseContent />
      <Footer />
    </main>
  )
}
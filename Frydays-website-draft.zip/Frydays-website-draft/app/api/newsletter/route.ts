import { NextResponse } from "next/server"
import { z } from "zod"
import { NewsletterSubscriptionError, subscribeToNewsletter } from "@/lib/newsletter-subscription"

export const runtime = "nodejs"

const newsletterRequestSchema = z.object({
  email: z.string().trim().email().max(254),
  consent: z.literal(true),
  website: z.string().trim().max(200).optional().default(""),
}).strict()

export async function POST(request: Request) {
  const contentLength = Number(request.headers.get("content-length") ?? 0)
  if (contentLength > 4_000) {
    return NextResponse.json({ ok: false, error: "That sign-up is too large to submit." }, { status: 413 })
  }

  let requestBody: unknown
  try {
    requestBody = await request.json()
  } catch {
    return NextResponse.json({ ok: false, error: "The sign-up details were not valid JSON." }, { status: 400 })
  }

  const parsed = newsletterRequestSchema.safeParse(requestBody)
  if (!parsed.success) {
    return NextResponse.json({
      ok: false,
      error: "Enter a valid email and agree to receive Frydays updates.",
    }, { status: 400 })
  }

  // Quietly accept honeypot submissions without adding them to Resend.
  if (parsed.data.website) return NextResponse.json({ ok: true, alreadySubscribed: false })

  try {
    const result = await subscribeToNewsletter(parsed.data.email)
    return NextResponse.json({ ok: true, ...result })
  } catch (error) {
    const status = error instanceof NewsletterSubscriptionError ? error.status : "connection error"
    console.error("Frydays newsletter sign-up could not be saved.", status)
    return NextResponse.json({
      ok: false,
      error: "We couldn't add you to the list right now. Please try again later.",
    }, { status: 502 })
  }
}

import { NextResponse } from "next/server"
import { z } from "zod"
import { ContactEmailDeliveryError, sendContactEmail } from "@/lib/contact-email"

export const runtime = "nodejs"

const contactRequestSchema = z.object({
  name: z.string().trim().min(1).max(100),
  email: z.string().trim().email().max(254),
  subject: z.enum(["order", "event", "corporate", "partnership", "supplier", "general"]),
  message: z.string().trim().min(1).max(5000),
  website: z.string().trim().max(200).optional().default(""),
}).strict()

export async function POST(request: Request) {
  const contentLength = Number(request.headers.get("content-length") ?? 0)
  if (contentLength > 12_000) {
    return NextResponse.json({ ok: false, error: "Your message is too long to submit." }, { status: 413 })
  }

  let requestBody: unknown
  try {
    requestBody = await request.json()
  } catch {
    return NextResponse.json({ ok: false, error: "The message details were not valid JSON." }, { status: 400 })
  }

  const parsed = contactRequestSchema.safeParse(requestBody)
  if (!parsed.success) {
    return NextResponse.json({
      ok: false,
      error: "Please check your name, email, subject, and message.",
    }, { status: 400 })
  }

  // Quietly accept honeypot submissions without forwarding them to the business inbox.
  if (parsed.data.website) return NextResponse.json({ ok: true })

  try {
    await sendContactEmail(parsed.data)
  } catch (error) {
    const status = error instanceof ContactEmailDeliveryError ? error.status : "connection error"
    console.error("Frydays contact message could not be sent.", status)
    return NextResponse.json({
      ok: false,
      error: "We couldn't send your message right now. Please try again or email Frydays directly.",
    }, { status: 502 })
  }

  return NextResponse.json({ ok: true })
}

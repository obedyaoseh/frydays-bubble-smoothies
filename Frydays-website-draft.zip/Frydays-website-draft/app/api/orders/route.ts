import { randomUUID } from "node:crypto"
import { NextResponse } from "next/server"
import { z } from "zod"
import { menuItems } from "@/lib/menu-data"
import { pastryItems } from "@/lib/pastry-data"
import { OrderEmailDeliveryError, sendOrderEmail, type OrderEmailDetails, type OrderEmailLine } from "@/lib/order-email"

export const runtime = "nodejs"

const toppingNames = ["Brown sugar pearls", "Coconut jelly", "Whipped cream", "Chia & granola"] as const
const deliveryZoneIds = ["teshie", "spintex", "labadi", "osu", "cantonments", "airport", "east-legon", "tema"] as const

const deliveryZones: Record<(typeof deliveryZoneIds)[number], { label: string; price: number }> = {
  teshie: { label: "Teshie / Nungua", price: 15 },
  spintex: { label: "Spintex Road", price: 15 },
  labadi: { label: "Labadi & Trade Fair", price: 18 },
  osu: { label: "Osu & Oxford Street", price: 20 },
  cantonments: { label: "Cantonments & Labone", price: 20 },
  airport: { label: "Airport Residential", price: 25 },
  "east-legon": { label: "East Legon", price: 25 },
  tema: { label: "Sakumono / Tema West", price: 25 },
}

const customizationSchema = z.object({
  size: z.enum(["Regular", "Large"]),
  sweetness: z.enum(["No sugar", "Light", "Half", "Standard"]),
  ice: z.enum(["No ice", "Light", "Regular", "Extra"]),
  milk: z.enum(["Oat milk", "Whole milk", "Coconut milk", "No milk"]),
  toppings: z.array(z.enum(toppingNames)).max(toppingNames.length),
  notes: z.string().trim().max(500).optional(),
}).strict()

const orderLineSchema = z.object({
  itemId: z.union([z.number().int().positive(), z.string().trim().min(1).max(100)]),
  quantity: z.number().int().min(1).max(50),
  customization: customizationSchema.nullable(),
}).strict()

const orderRequestSchema = z.object({
  customer: z.object({
    name: z.string().trim().min(1).max(100),
    email: z.string().trim().email().max(254),
    phone: z.string().trim().min(5).max(30),
  }).strict(),
  orderType: z.enum(["pickup", "delivery"]),
  deliveryZone: z.enum(deliveryZoneIds).nullable().optional(),
  address: z.string().trim().max(500).optional(),
  paymentMethod: z.enum(["momo", "telecel", "bank", "card", "cash", "pending"]),
  promoCode: z.enum(["FRYDAYS25", "WELCOME15"]).nullable().optional(),
  notes: z.string().trim().max(1000).optional(),
  items: z.array(orderLineSchema).min(1).max(50),
}).strict().superRefine((order, context) => {
  if (order.orderType === "delivery" && !order.deliveryZone) {
    context.addIssue({ code: z.ZodIssueCode.custom, path: ["deliveryZone"], message: "Choose a delivery area." })
  }
  if (order.orderType === "delivery" && !order.address?.trim()) {
    context.addIssue({ code: z.ZodIssueCode.custom, path: ["address"], message: "Add a delivery address." })
  }

  order.items.forEach((line, index) => {
    const isDrink = typeof line.itemId === "number"
    const exists = isDrink
      ? menuItems.some((item) => item.id === line.itemId)
      : pastryItems.some((item) => item.id === line.itemId)
    if (!exists) {
      context.addIssue({ code: z.ZodIssueCode.custom, path: ["items", index, "itemId"], message: "Choose a current menu item." })
    }
    if (isDrink && !line.customization) {
      context.addIssue({ code: z.ZodIssueCode.custom, path: ["items", index, "customization"], message: "Drink customizations are required." })
    }
    if (!isDrink && line.customization) {
      context.addIssue({ code: z.ZodIssueCode.custom, path: ["items", index, "customization"], message: "Pastries do not accept drink customizations." })
    }
  })
})

const paymentLabels = {
  momo: "MTN MoMo",
  telecel: "Telecel Cash",
  bank: "Bank transfer",
  card: "Debit / Visa",
  cash: "Pay on pickup",
  pending: "To be confirmed with Frydays",
} as const

function roundMoney(value: number) {
  return Math.round((value + Number.EPSILON) * 100) / 100
}

function calculateOrderDetails(order: z.infer<typeof orderRequestSchema>): OrderEmailDetails {
  const items: OrderEmailLine[] = order.items.map((line) => {
    const item = typeof line.itemId === "number"
      ? menuItems.find((menuItem) => menuItem.id === line.itemId)
      : pastryItems.find((pastry) => pastry.id === line.itemId)
    if (!item) throw new Error("Menu item not found")

    const customization = line.customization
    const unitPrice = item.price
      + (customization?.toppings.length ?? 0) * 3
      + (customization?.size === "Large" ? 10 : 0)
    const details = customization
      ? [
          customization.size === "Regular" ? "Regular · 500 ml" : "Large",
          `${customization.sweetness} sugar`,
          `${customization.ice} ice`,
          customization.milk,
          ...(customization.toppings.length ? [`Toppings: ${customization.toppings.join(", ")}`] : []),
        ].join(" · ")
      : "Pastry"

    return {
      name: item.name,
      quantity: line.quantity,
      unitPrice,
      lineTotal: roundMoney(unitPrice * line.quantity),
      details,
    }
  })

  const subtotal = roundMoney(items.reduce((total, item) => total + item.lineTotal, 0))
  const discount = order.promoCode === "FRYDAYS25"
    ? Math.min(subtotal, 25)
    : order.promoCode === "WELCOME15"
      ? roundMoney(subtotal * 0.15)
      : 0
  const deliveryFee = order.orderType === "delivery" && order.deliveryZone ? deliveryZones[order.deliveryZone].price : 0
  const total = roundMoney(Math.max(0, subtotal - discount) + deliveryFee)
  const notes = [
    order.notes,
    ...order.items.flatMap((line, index) => {
      const note = line.customization?.notes
      return note ? [`${items[index].name}: ${note}`] : []
    }),
  ].filter(Boolean).join("\n")
  const fulfillment = order.orderType === "delivery"
    ? { type: "Delivery", area: deliveryZones[order.deliveryZone!].label, address: order.address }
    : { type: "Pickup", area: "Frydays Teshie Bar" }

  return {
    orderReference: `FD-${randomUUID().slice(0, 8).toUpperCase()}`,
    customer: { ...order.customer, email: order.customer.email.toLowerCase() },
    fulfillment,
    paymentMethod: paymentLabels[order.paymentMethod],
    items,
    subtotal,
    discount,
    deliveryFee,
    total,
    promoCode: order.promoCode ?? undefined,
    notes: notes || undefined,
    placedAt: new Intl.DateTimeFormat("en-GH", {
      dateStyle: "medium",
      timeStyle: "short",
      timeZone: "Africa/Accra",
    }).format(new Date()),
  }
}

export async function POST(request: Request) {
  const contentLength = Number(request.headers.get("content-length") ?? 0)
  if (contentLength > 50_000) {
    return NextResponse.json({ ok: false, error: "That order is too large to submit." }, { status: 413 })
  }

  let requestBody: unknown
  try {
    requestBody = await request.json()
  } catch {
    return NextResponse.json({ ok: false, error: "The order details were not valid JSON." }, { status: 400 })
  }

  const parsed = orderRequestSchema.safeParse(requestBody)
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: "Please check your contact details, delivery information, and order items." }, { status: 400 })
  }

  const order = calculateOrderDetails(parsed.data)

  try {
    await sendOrderEmail(order, "frydays")
  } catch (error) {
    const status = error instanceof OrderEmailDeliveryError ? error.status : "connection error"
    console.error("Frydays order notification could not be sent.", status)
    return NextResponse.json({
      ok: false,
      error: "We couldn't confirm that Frydays received your order. Your bag is unchanged; please contact Frydays before retrying to avoid a duplicate order.",
    }, { status: 502 })
  }

  let receiptSent = false
  try {
    await sendOrderEmail(order, "customer")
    receiptSent = true
  } catch (error) {
    const status = error instanceof OrderEmailDeliveryError ? error.status : "connection error"
    console.error("Customer order receipt could not be sent.", order.orderReference, status)
  }

  return NextResponse.json({
    ok: true,
    orderReference: order.orderReference,
    receiptSent,
  })
}

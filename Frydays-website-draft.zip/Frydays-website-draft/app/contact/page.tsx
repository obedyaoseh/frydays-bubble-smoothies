import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { ContactContent } from "@/components/contact-content"
import { pageMetadata } from "@/lib/seo"

export const metadata = pageMetadata({
  title: "Visit Us in Teshie, Accra",
  description: "Visit Frydays in Teshie or contact us about smoothie and bubble tea orders, pickup, delivery, events, and partnerships.",
  path: "/contact",
})

export default function ContactPage() {
  return (
    <main className="min-h-screen bg-[#F2DBB2]">
      <Navigation />
      <ContactContent />
      <Footer />
    </main>
  )
}

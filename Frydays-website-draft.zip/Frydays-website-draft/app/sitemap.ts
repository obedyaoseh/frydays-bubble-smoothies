import type { MetadataRoute } from "next"
import { journalStories } from "@/lib/journal-data"
import { SITE_URL } from "@/lib/seo"

const pages = [
  { path: "/", changeFrequency: "weekly" as const, priority: 1 },
  { path: "/order", changeFrequency: "weekly" as const, priority: 0.95 },
  { path: "/about", changeFrequency: "monthly" as const, priority: 0.7 },
  { path: "/contact", changeFrequency: "monthly" as const, priority: 0.8 },
  { path: "/blog", changeFrequency: "monthly" as const, priority: 0.6 },
  { path: "/franchise", changeFrequency: "monthly" as const, priority: 0.5 },
  { path: "/esg", changeFrequency: "monthly" as const, priority: 0.4 },
  { path: "/privacy", changeFrequency: "yearly" as const, priority: 0.2 },
  { path: "/terms", changeFrequency: "yearly" as const, priority: 0.2 },
]

export default function sitemap(): MetadataRoute.Sitemap {
  return [
    ...pages.map((page) => ({
      url: page.path === "/" ? SITE_URL : new URL(page.path, SITE_URL).toString(),
      changeFrequency: page.changeFrequency,
      priority: page.priority,
    })),
    ...journalStories.map((story) => ({
      url: new URL(`/blog/${story.slug}`, SITE_URL).toString(),
      changeFrequency: "yearly" as const,
      priority: 0.45,
    })),
  ]
}

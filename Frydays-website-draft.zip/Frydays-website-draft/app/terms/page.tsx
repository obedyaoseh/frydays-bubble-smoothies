import type { Metadata } from "next"
import type { ReactNode } from "react"
import { Footer } from "@/components/footer"
import { Navigation } from "@/components/navigation"
import { pageMetadata } from "@/lib/seo"

export const metadata: Metadata = pageMetadata({
  title: "Terms of Service",
  description: "Read Frydays website and ordering terms, including order requests, payment, pickup, delivery, and customer responsibilities.",
  path: "/terms",
})

const termsMarkdown = `
## 1. Introduction

Welcome to FryDays Bubble & Smoothies Bar (“FryDays”, “we”, “us” or “our”).

These Terms and Conditions explain the rules for using our website, official social media pages, online ordering services and other communication channels. They also set out the conditions that apply when you order or purchase our smoothies, bubble tea and related products.

By accessing or using our website, interacting with our official social media pages, or placing an order through a channel operated by FryDays, you agree to the terms relevant to that activity. If you do not agree with these terms, please do not use the relevant service.

These Terms and Conditions should be read together with our [Privacy Policy](/privacy), which explains how we collect, use and protect personal information.

Nothing in these terms removes any consumer right or legal protection that cannot lawfully be excluded under the laws of Ghana.

## 2. About FryDays

- **Business name:** FryDays Bubble & Smoothies Bar
- **Email:** frydaysghana@gmail.com
- **Telephone/WhatsApp:** 059 619 8209
- **Official social media platforms:** Instagram, Facebook, TikTok and LinkedIn
- **Official Instagram:** [Visit Instagram](https://www.instagram.com/frydaysghana?mdxt=eXRvZTRuZTZuczJt&utm_source=qr)
- **Official Facebook:** [Visit Facebook](https://www.facebook.com/share/1C78bDbC2J/?mibextid=wwXIfr)
- **Official TikTok:** [Visit TikTok](https://www.tiktok.com/@frydaysghana)
- **Official LinkedIn:** [Visit LinkedIn](https://www.linkedin.com/company/frydays-bubble-smoothies-bar/home/?viewAsMember=true)

FryDays is a food and beverage business offering smoothies, bubble tea and related products. Our menu, product availability, prices, promotions and service options may change over time.

Only accounts and contact channels verified and identified by FryDays as official should be treated as authorised business channels.

## 3. Use of Our Website and Social Media

You may use our digital platforms to learn about FryDays, view our products, check available offers, place orders through supported channels, contact us, submit feedback and engage with our content.

You agree to use these platforms lawfully and responsibly. You must not use them to:

- Commit fraud or engage in unlawful activity;
- Impersonate FryDays, our staff or another person;
- Publish abusive, threatening, defamatory or knowingly misleading content;
- Share another person's private information without proper authorisation;
- Upload malicious links or attempt to disrupt our website or services;
- Infringe intellectual property or other legal rights; or
- Send spam, fraudulent offers or unauthorised advertisements.

We may take reasonable steps to address misuse, including removing content, restricting access or reporting conduct to the relevant platform or authority where appropriate.

## 4. Website Information and Availability

We make reasonable efforts to ensure that the information on our website and official pages is accurate and current. However, information may occasionally contain errors, omissions or outdated details.

Product descriptions, photographs, prices, menus, opening hours and promotional materials are provided for general information and may be updated as our business changes.

We may correct errors, update content, modify website features or temporarily suspend access for maintenance, security or technical reasons.

We do not guarantee uninterrupted access to our website or social media pages. However, changes to our website will not automatically cancel an accepted order or remove a customer's rights under applicable law.

## 5. Products, Menus and Images

We aim to provide clear information about our smoothies, bubble tea and other products, including available flavours, sizes, toppings and ingredients where relevant.

Photographs are intended to illustrate our products. Actual appearance may vary slightly due to ingredients, preparation, packaging or availability.

We may occasionally experience shortages of particular ingredients, flavours, toppings or sizes. If an item is unavailable after you place an order, we will make reasonable efforts to contact you about the available options.

We will not knowingly substitute a materially different product without appropriate communication and agreement where required.

Customers should contact us before ordering if they need clarification about ingredients, portion sizes or product suitability.

## 6. Allergies and Dietary Requirements

Customers with allergies, intolerances or dietary requirements should inform FryDays before placing an order.

We will make reasonable efforts to provide accurate ingredient information based on the information available to us and our actual preparation practices.

Ingredients may be handled in shared premises, equipment or preparation areas. Depending on our processes, cross-contact with other ingredients may occur.

Customers should not assume that a product is allergen-free, vegan, dairy-free, gluten-free or suitable for a particular medical or dietary condition unless FryDays has specifically confirmed the relevant claim and can support it.

If you have a serious allergy or are unsure whether a product is suitable for you, contact us before ordering. We may be unable to fulfil a request if we cannot reasonably confirm that the product meets the stated requirement.

Nothing in this section limits any food safety obligation imposed on FryDays by law.

## 7. Prices and Additional Charges

Our prices are displayed or communicated in **Ghana cedis (GHS)** unless expressly stated otherwise.

**Delivery charges are separate from product prices.** The applicable delivery fee should be communicated to the customer before the order is finalised.

The total payable amount should be made clear before the customer completes the purchase, including applicable delivery fees and any other disclosed charges.

Prices may change from time to time. A change in price will not automatically change the agreed price of an order already accepted by FryDays, except where a lawful correction or other agreed adjustment applies.

If an obvious pricing error occurs, we will take reasonable steps to contact the customer before proceeding. If an order cannot be fulfilled at the displayed price, we may cancel the affected order and arrange any refund required by applicable law.

## 8. Placing and Confirming Orders

Customers may order through the channels FryDays makes available, which may include the website, WhatsApp, telephone, in-store ordering or an approved third-party ordering platform.

When placing an order, you must provide accurate information, including the selected products, quantities, contact details and delivery or collection details where applicable.

Submitting an order request through our website does not by itself mean that FryDays has accepted or confirmed the order. Our team will contact you by phone or WhatsApp to confirm product availability, the order total, payment arrangements and pickup or delivery details. An order is accepted when FryDays confirms it through an official channel.

Please review your order before submitting it. If you notice a mistake, contact us immediately. We cannot guarantee that a change can be made after preparation or dispatch has started.

An order may be declined or cancelled where reasonably necessary, including where a product is unavailable, payment cannot be verified, essential information is missing, fraud is reasonably suspected or an unexpected operational issue prevents fulfilment.

Where FryDays cancels a paid order, we will handle any refund in accordance with applicable law and the refund provisions below.

## 9. Payment Methods

Payment methods currently offered through the website order request may include:

- MTN Mobile Money (MoMo);
- Telecel Cash;
- Bank transfer;
- Debit or Visa card; and
- Pay on Pickup.

Available payment methods may vary by ordering channel and fulfilment option. FryDays will confirm the applicable payment instructions and amount through an official channel.

Submitting payment details in an order request does not itself confirm that payment has been received. Payment is treated as received only after FryDays verifies it.

Customers must use the verified payment details or secure payment interface provided by FryDays. Before authorising a transaction, please check the amount and recipient.

FryDays will not ask you to disclose your mobile money PIN, card security code, banking password or one-time password through ordinary messages or email.

Payment processing may involve third-party providers. If a payment has been deducted but you have not received confirmation, contact us using our verified contact details and provide the relevant transaction reference. Do not send your PIN or password.

## 10. Delivery and Collection

FryDays may fulfil orders through a combination of **our own delivery arrangements and third-party delivery providers**. Shop collection may also be available where offered.

The delivery or collection options, service areas, charges and estimated timeframes applicable to an order will be communicated through the relevant ordering channel.

### 10.1 Accurate delivery details

Customers must provide an accurate delivery address, GhanaPost GPS address where applicable, contact number and any reasonable directions needed to locate the delivery destination.

We may contact you to clarify delivery information or resolve a delivery issue.

### 10.2 Delivery times

Delivery times are estimates unless FryDays expressly confirms a guaranteed time. Delays may occur because of traffic, weather, high order volumes, technical problems or circumstances affecting a third-party delivery provider.

We will make reasonable efforts to communicate significant delays where appropriate.

### 10.3 Failed deliveries

If a delivery cannot be completed because the address is incorrect, the customer cannot be reached or access to the destination is unavailable, we may contact the customer to agree on the next step.

Any additional delivery charge or re-delivery arrangement must be communicated to the customer. Charges and cancellation outcomes remain subject to applicable law.

### 10.4 Collection orders

Customers should follow the collection instructions provided by FryDays and collect their orders promptly. Because smoothies and bubble tea are perishable, customers should follow any storage or consumption guidance provided.

### 10.5 Third-party delivery providers

A third-party delivery platform may have its own terms and conditions. Those terms may apply to the services it provides, but they do not remove obligations that applicable law places on FryDays.

## 11. Product Quality and Order Complaints

We take reasonable care in preparing and supplying our products.

If your order is incorrect, incomplete, damaged, spoiled or materially different from what was agreed, please contact us as soon as reasonably possible.

We may request the order reference, transaction details, a description of the problem and a photograph where relevant and reasonably available.

We will review the complaint and determine an appropriate response based on the circumstances and applicable law.

Customers should not consume a product they reasonably believe is unsafe or spoiled. Please contact FryDays promptly if you have a food safety concern.

## 12. Cancellations and Refunds

FryDays' current policy is that **refunds will be provided where required by law or approved by FryDays**.

Refund requests will be reviewed according to the circumstances, our obligations under applicable law and any terms specifically agreed for the order.

A refund may be appropriate where, for example:

- FryDays cancels a paid order and cannot fulfil it;
- Payment is confirmed but the order is not fulfilled;
- A product is materially defective, unsafe or not as described; or
- Applicable law otherwise requires a refund or another remedy.

If you wish to cancel or change an order, contact us as soon as possible. We cannot guarantee that a change or cancellation can be made after preparation or dispatch has begun.

Smoothies and bubble tea are perishable products, so a change of mind after preparation or delivery may not always justify a refund. This does not remove any legal right a customer may have where a product is defective, unsafe or otherwise covered by applicable law.

To request a refund, contact us at frydaysghana@gmail.com or 059 619 8209 with your order reference, purchase date and a description of the issue. If a refund is approved or legally required, we will explain the process. The time taken for the funds to appear may depend on the payment provider or financial institution.

Nothing in this section excludes a consumer right or remedy that cannot lawfully be excluded.

## 13. Promotions, Discounts and Competitions

FryDays may run promotions, discounts, giveaways, competitions or other marketing activities through its website or official social media accounts.

Each promotion may have its own rules, which may specify:

- The opening and closing dates;
- Eligible products or participants;
- How to enter;
- Any minimum purchase or other entry requirements;
- The number or value of prizes;
- How winners will be selected and contacted;
- How and when prizes must be claimed; and
- Any applicable geographical or delivery restrictions.

Customers must follow the specific rules published for each promotion. If those rules conflict with these general terms, the specific promotion rules will apply to the extent of the conflict.

Unless stated otherwise in the promotion rules, offers should not be assumed to be transferable, exchangeable for cash or combinable with other offers.

FryDays may amend, suspend or withdraw a promotion where reasonably necessary because of an error, suspected fraud, technical problem or other legitimate reason, subject to applicable law and any rights already acquired by participants.

We will not knowingly misrepresent a promotion or its conditions. Where a promotion is conducted through a third-party platform, participants must also follow that platform's rules.

## 14. Loyalty and Rewards Programmes

FryDays may introduce a loyalty or rewards programme in the future.

No loyalty points, membership benefits or rewards should be assumed to be available unless FryDays has officially introduced the programme and published its rules.

If a programme is introduced, separate terms may explain how rewards are earned and redeemed, whether they expire, whether they can be transferred and what happens if the programme changes or ends.

## 15. Official Social Media Platforms

FryDays uses or intends to use the following social media platforms:

- [Instagram](https://www.instagram.com/frydaysghana?mdxt=eXRvZTRuZTZuczJt&utm_source=qr);
- [Facebook](https://www.facebook.com/share/1C78bDbC2J/?mibextid=wwXIfr);
- [TikTok](https://www.tiktok.com/@frydaysghana); and
- [LinkedIn](https://www.linkedin.com/company/frydays-bubble-smoothies-bar/home/?viewAsMember=true).

We may use these platforms to publish product information, photographs, videos, menus, offers, announcements and customer service updates.

Our social media pages are also subject to the terms, policies and technical rules of the relevant platform. FryDays does not control all aspects of those services, including outages, account restrictions, changes to platform features or the platform's own data practices.

A message sent through social media is not automatically an accepted order. An order is subject to the confirmation and payment terms in Sections 8 and 9.

Customers should verify that an account is genuinely operated by FryDays before sending money or personal information. Do not rely solely on a display name or profile photograph.

## 16. Comments, Messages and Social Media Conduct

We welcome respectful questions, reviews and feedback. Users must not post or send content through our platforms that is unlawful, threatening, abusive, fraudulent, defamatory, discriminatory, misleading or in breach of another person's rights.

We may hide or remove content, report violations or restrict access to our pages where reasonably necessary to enforce these rules or protect customers, staff and the business.

We do not promise to monitor every comment or message. The presence of a comment on a FryDays page does not mean that FryDays endorses it.

Please avoid posting private information such as phone numbers, delivery addresses, payment references or allergy details in public comments. Where necessary, we may ask you to continue a conversation privately.

FryDays will not ask customers to disclose PINs, passwords or one-time passwords through social media messages.

## 17. Customer Reviews, Photographs and Submissions

Customers may be able to submit reviews, comments, photographs, suggestions or other content.

You are responsible for ensuring that content you submit is lawful, accurate to the best of your knowledge and does not violate another person's rights.

By submitting content to FryDays, you allow us to receive and use it for the purpose for which it was submitted, such as responding to a complaint or displaying a review on the relevant platform.

Submitting a photograph, testimonial or review does not automatically authorise FryDays to use it in advertising or other promotional material. Where we intend to use identifiable customer content for marketing, we will obtain appropriate permission where required by law.

You retain the rights you hold in your content. You should not submit photographs, text or other material that you do not own or have permission to share.

We may remove content that breaches these terms or applicable law.

## 18. Intellectual Property

Unless stated otherwise, FryDays or its licensors own or have permission to use the branding, logo, original photographs, videos, graphics, product descriptions, website text and other creative materials published on our platforms.

You may view and share publicly available FryDays content for personal, non-commercial purposes, provided that you do not misrepresent its source, remove ownership notices or alter it in a misleading way.

You must not reproduce, sell, modify or commercially exploit our content without prior permission, except where the use is permitted by law.

Third-party names, logos and trademarks remain the property of their respective owners. Their appearance on our platforms does not necessarily imply endorsement or partnership.

## 19. Privacy and Personal Information

Our [Privacy Policy](/privacy) explains how FryDays handles personal information.

When placing an order or contacting us, you should provide accurate information that is relevant to your request. We will handle information in accordance with our Privacy Policy and applicable Ghanaian law.

If you use a third-party payment, messaging, social media, ordering or delivery service, that provider may separately process information under its own terms and privacy policy.

Please do not send passwords, PINs, card security codes or other security credentials to FryDays through ordinary messages or email.

## 20. Third-Party Links and Services

Our website and social media pages may link to third-party services, including payment providers, online ordering and delivery platforms, Google Maps, WhatsApp and social media services.

Those providers may have their own terms, privacy policies and security arrangements. FryDays does not control every aspect of their services and cannot guarantee their uninterrupted availability.

A link to a third-party service does not necessarily mean that FryDays endorses every product, statement or service offered by that provider.

Customers should review the relevant terms before using a third-party service or providing information directly to it.

## 21. Website Security and Availability

We take reasonable steps to maintain the security and operation of our website and digital channels. However, no online service can be guaranteed to operate without interruption or to be completely secure.

You must not attempt to gain unauthorised access to our website, interfere with its operation, introduce malicious software or use our systems in a way that could harm the business or other users.

We may suspend or restrict access where reasonably necessary to address a security risk, technical issue, suspected fraud or misuse.

## 22. Responsibility and Legal Rights

FryDays will take reasonable care in providing information, handling accepted orders and supplying our products.

To the extent permitted by law, we are not responsible for losses arising solely from circumstances outside our reasonable control, such as certain third-party platform outages, network failures or inaccurate delivery details supplied by a customer.

Nothing in these terms excludes or limits liability for fraud, deliberate wrongdoing or any other matter for which liability cannot lawfully be excluded or limited.

These terms do not remove statutory consumer rights, food safety obligations or other legal protections that apply under Ghanaian law.

## 23. Changes to These Terms

We may update these Terms and Conditions to reflect changes to our products, business operations, ordering channels, technology or legal obligations.

The latest version will be published on our website with an updated “Last updated” date.

Changes will apply from the stated effective date or as otherwise communicated. They will not automatically change the terms of an order already accepted by FryDays, except where permitted by law or agreed with the customer.

We encourage customers to review this page periodically.

## 24. Complaints and Dispute Resolution

If you have a complaint about a product, order, payment, delivery, promotion or interaction with FryDays, please contact us first so we can try to resolve the matter.

- **Customer service telephone/WhatsApp:** 059 619 8209
- **Email:** frydaysghana@gmail.com

Please provide relevant information, such as the order reference, date of purchase and a clear explanation of the problem. Do not include passwords, PINs or other security credentials.

We will review complaints fairly and make reasonable efforts to respond. Resolution times may depend on the nature of the complaint and whether information from a payment or delivery provider is needed.

If a dispute cannot be resolved directly, the parties may consider an appropriate mediation process or other lawful method of dispute resolution. Nothing in this section prevents a customer from exercising a legal right to approach a competent court or relevant authority.

## 25. Governing Law

These Terms and Conditions are governed by the laws of the Republic of Ghana.

Any dispute that cannot be resolved informally will be handled through the appropriate legal process in Ghana, subject to applicable law and the jurisdiction of the relevant court or authority.

## 26. General Provisions

**Entire agreement:** These Terms and Conditions, together with our Privacy Policy and any applicable order or promotion terms, describe the relevant arrangements between FryDays and the user or customer.

**Severability:** If a provision is found to be invalid or unenforceable, the remaining provisions will continue to apply to the extent permitted by law.

**No waiver:** If FryDays does not enforce a provision immediately, this does not mean that we have permanently waived the right to enforce it.

**Transfer of rights:** Any transfer of rights or obligations by FryDays will be subject to applicable law and must not unlawfully reduce a customer's rights.

**Language:** These terms are written in English. If a translation is provided for convenience, the English version will apply to the extent permitted by law where the versions conflict.

## 27. Contact FryDays

For questions about these Terms and Conditions, our products, website or social media pages, contact:

- **FryDays Bubble & Smoothies Bar**
- **Telephone/WhatsApp:** 059 619 8209
- **Email:** frydaysghana@gmail.com

We welcome customer feedback and will make reasonable efforts to address genuine concerns.
`

function renderInline(text: string): ReactNode[] {
  const normalizedText = text.replaceAll("FryDays", "Frydays")
  const tokens = normalizedText.split(/(\*\*[^*]+\*\*|\[[^\]]+\]\([^)]+\)|frydaysghana@gmail\.com|059 619 8209)/g)

  return tokens.map((token, index) => {
    if (token.startsWith("**") && token.endsWith("**")) {
      return <strong key={index} className="font-bold text-[#09403B]">{token.slice(2, -2)}</strong>
    }
    const link = /^\[([^\]]+)\]\(([^)]+)\)$/.exec(token)
    if (link) {
      const isExternal = link[2].startsWith("https://")
      return (
        <a
          key={index}
          href={link[2]}
          target={isExternal ? "_blank" : undefined}
          rel={isExternal ? "noopener noreferrer" : undefined}
          className="font-semibold text-[#09403B] underline underline-offset-4"
        >
          {link[1]}
        </a>
      )
    }
    if (token === "frydaysghana@gmail.com") {
      return <a key={index} href="mailto:frydaysghana@gmail.com" className="font-semibold text-[#09403B] underline underline-offset-4">frydaysghana@gmail.com</a>
    }
    if (token === "059 619 8209") {
      return <a key={index} href="tel:+233596198209" className="font-semibold text-[#09403B] underline underline-offset-4">059 619 8209</a>
    }
    return token
  })
}

function renderTerms(markdown: string): ReactNode[] {
  const lines = markdown.trim().split(/\r?\n/)
  const content: ReactNode[] = []
  let index = 0

  while (index < lines.length) {
    const line = lines[index].trim()
    if (!line) {
      index += 1
      continue
    }

    const heading = /^(#{2,3})\s+(.+)$/.exec(line)
    if (heading) {
      const Heading = heading[1].length === 2 ? "h2" : "h3"
      content.push(
        <Heading
          key={`heading-${index}`}
          className={heading[1].length === 2
            ? "mt-12 border-b border-[#09403B]/15 pb-3 text-2xl font-black tracking-tight text-[#09403B] first:mt-0 md:text-3xl"
            : "mt-8 text-lg font-bold text-[#09403B]"}
        >
          {renderInline(heading[2])}
        </Heading>,
      )
      index += 1
      continue
    }

    if (line.startsWith("- ")) {
      const items: string[] = []
      while (index < lines.length && lines[index].trim().startsWith("- ")) {
        items.push(lines[index].trim().slice(2))
        index += 1
      }
      content.push(
        <ul key={`list-${index}`} className="my-5 list-disc space-y-2 pl-6 marker:text-[#8EBE27]">
          {items.map((item, itemIndex) => <li key={itemIndex} className="pl-1">{renderInline(item)}</li>)}
        </ul>,
      )
      continue
    }

    const paragraph = [line]
    index += 1
    while (
      index < lines.length
      && lines[index].trim()
      && !lines[index].trim().startsWith("- ")
      && !/^(#{2,3})\s+/.test(lines[index].trim())
    ) {
      paragraph.push(lines[index].trim())
      index += 1
    }
    content.push(
      <p key={`paragraph-${index}`} className="my-4 leading-7 text-[#09403B]/75">
        {renderInline(paragraph.join(" "))}
      </p>,
    )
  }

  return content
}

export default function TermsPage() {
  return (
    <main className="min-h-screen bg-[#F2DBB2]">
      <Navigation />
      <section className="bg-[#09403B] px-6 pb-14 pt-36 md:pb-20">
        <div className="mx-auto max-w-5xl">
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-[#F2DBB2]/60">Frydays Bubble &amp; Smoothies Bar</p>
          <h1 className="mt-4 text-5xl font-black leading-[0.95] tracking-tight text-[#F2DBB2] md:text-7xl">Terms of Service</h1>
          <div className="mt-8 flex flex-wrap gap-x-8 gap-y-2 text-sm font-medium text-[#F2DBB2]/65">
            <p><span className="text-[#F2DBB2]">Effective date:</span> 2026</p>
            <p><span className="text-[#F2DBB2]">Last updated:</span> 2026</p>
          </div>
        </div>
      </section>

      <article className="mx-auto max-w-5xl px-6 py-12 md:py-16">
        <div className="rounded-2xl border border-[#09403B]/10 bg-[#F7E8CB] p-6 text-sm leading-6 text-[#09403B]/75 md:p-10 md:text-base">
          {renderTerms(termsMarkdown)}
        </div>
      </article>
      <Footer />
    </main>
  )
}

import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { AboutContent } from "@/components/about-content"
import { pageMetadata } from "@/lib/seo"

export const metadata = pageMetadata({
  title: "Our Story in Teshie, Accra",
  description: "Meet Frydays, a Teshie-born smoothie and bubble tea bar. Learn about our story, community, fresh drinks, and growing menu.",
  path: "/about",
})

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-[#F2DBB2]">
      <Navigation />
      <AboutContent />
      <Footer />
    </main>
  )
}

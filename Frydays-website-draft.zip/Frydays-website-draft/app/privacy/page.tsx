import type { Metadata } from "next"
import type { ReactNode } from "react"
import { Footer } from "@/components/footer"
import { Navigation } from "@/components/navigation"
import { pageMetadata } from "@/lib/seo"

export const metadata: Metadata = pageMetadata({
  title: "Privacy Policy",
  description: "Learn how Frydays collects, uses, and protects personal information when you browse the site, contact us, or place an order.",
  path: "/privacy",
})

const policyMarkdown = `
## 1. Introduction

FryDays Bubble & Smoothies Bar (“FryDays”, “we”, “us” or “our”) respects the privacy of our customers and website visitors. We understand that people want to know what happens to their personal information when they browse our website, place an order, contact us or use our services.

This Privacy Policy explains the types of personal information we may collect, why we collect it, how we use and protect it, when we may share it with other organisations, and the choices available to you.

FryDays is a food and beverage business offering smoothies, bubble tea and related products. We may receive personal information through our website, online ordering and delivery services, WhatsApp, email, telephone, and in-person interactions, depending on the services available at the time.

We handle personal information in line with applicable laws of the Republic of Ghana, including the **Data Protection Act, 2012 (Act 843)**, where applicable.

By using our website or providing your information to us, you acknowledge that you have had the opportunity to read this Privacy Policy. Where the law requires consent for a particular activity, we will seek that consent separately.

## 2. Who We Are

- **Business name:** FryDays Bubble & Smoothies Bar
- **Business address:** Teshie, Accra, Ghana
- **Privacy contact email:** frydaysghana@gmail.com
- **Telephone/WhatsApp:** 059 619 8209

For questions about this Privacy Policy or how we handle your personal information, please contact us using the details above.

## 3. Personal Information We Collect

The information we collect depends on how you interact with FryDays. We aim to collect only information that is reasonably needed for the relevant purpose.

### 3.1 Information you provide directly

We may collect the following information when you place an order, contact us, complete a form, leave a review or communicate with our team:

- **Name:** To identify you and address your order or enquiry.
- **Phone number:** To confirm orders, contact you about delivery or collection, and respond to questions.
- **Email address:** To send order confirmations, respond to enquiries and, where permitted, send marketing messages.
- **Delivery address or GhanaPost GPS address:** To deliver your order to the correct location.
- **Order details and purchase history:** Such as the drinks or products ordered, quantities, prices, order dates and relevant order instructions.
- **Payment confirmation or transaction reference:** To confirm whether a payment has been made, reconcile transactions and handle payment-related enquiries.
- **Customer reviews or photographs:** If you submit feedback, a review or a photograph to us, we may collect the content you provide.
- **Allergy or dietary information:** If you voluntarily tell us about an allergy, dietary requirement or ingredient concern, we may use that information to help respond to your request and communicate relevant information about your order.

Please provide only the information necessary for your request. Do not send sensitive personal information unless it is relevant and you are comfortable sharing it.

### 3.2 Payment information

FryDays may accept payments through methods such as:

- MTN Mobile Money (MoMo);
- Visa or Mastercard;
- Bank transfer;
- Cash on delivery or collection; and
- Other payment methods we may make available.

Depending on the payment method, we may receive a transaction reference, payment status, amount paid, date of payment and other limited information needed to verify the transaction.

**We should not collect or store full card numbers, card security codes, mobile money PINs, banking passwords or one-time passwords through ordinary website forms, WhatsApp messages or email.** Card and electronic payment transactions should be handled through the relevant payment provider's secure process.

The payment information actually received by FryDays will depend on the payment providers and systems we use.

### 3.3 Information collected automatically

When you visit our website, certain information may be collected automatically through cookies, analytics tools or similar technologies. Depending on the website configuration, this may include:

- IP address and general device or browser information;
- Pages visited and links clicked;
- Time spent on pages and general website interaction;
- Referring website or campaign information;
- Approximate location derived from technical information; and
- Cookie identifiers and advertising or analytics events.

We may use Google Analytics and Meta Pixel or related Facebook advertising tools to understand website activity, assess advertising performance and improve our marketing. The information collected depends on which tools are active and how they are configured.

Some information may be collected by the service providers operating these tools. Please see Sections 7 and 8 for more information.

## 4. How We Collect Personal Information

We may collect personal information through:

- Our website and online order forms;
- Online ordering or delivery platforms;
- WhatsApp links or WhatsApp Business;
- Email, telephone and other customer communications;
- Payment confirmations and transaction records;
- Customer reviews, feedback forms or photographs you choose to submit;
- Google Analytics, Meta Pixel, cookies and similar technologies; and
- Other interactions with FryDays, including in-person orders, where relevant.

If a third-party platform collects information directly from you, its own privacy policy may also apply.

## 5. Why We Use Your Information

We may use personal information for the following purposes:

### 5.1 To process and fulfil orders

We use your name, contact details, order information and delivery address to receive, prepare, confirm and fulfil orders, including arranging delivery or collection.

### 5.2 To communicate with you

We may contact you about order confirmations, payment status, delivery arrangements, collection instructions, changes to an order, customer enquiries or complaints.

### 5.3 To manage payments and records

We may use transaction references and payment confirmations to verify payments, investigate discrepancies, prevent fraud and maintain appropriate business and financial records.

### 5.4 To respond to allergies and dietary requests

Where you provide allergy or dietary information, we may use it to understand your request and communicate relevant ingredient or preparation information. We will not treat a customer's disclosure as a guarantee that a product is free from a particular allergen unless that claim has been verified and can be supported.

Customers should contact us before ordering if they have an allergy or serious dietary concern.

### 5.5 To improve our website and services

We may use website usage data and analytics to understand which pages customers visit, identify technical problems, improve the ordering process and assess how our website performs.

### 5.6 To measure advertising

Where enabled, Meta Pixel and related advertising tools may help us measure the effectiveness of advertisements, understand visits to our website and improve the relevance of future advertising.

### 5.7 To send marketing messages

If you have agreed to receive marketing or where otherwise permitted by applicable law, we may use your contact details to share new products, special offers, promotions, events and other FryDays updates.

You can opt out of marketing messages at any time. See Section 9.

### 5.8 To manage reviews and customer photographs

We may use reviews or photographs to respond to feedback, improve our services or, where you have given appropriate permission, promote FryDays. We will not assume that a photograph or review submitted privately can automatically be published in our marketing.

### 5.9 To comply with legal obligations

We may process or disclose relevant information where necessary to comply with applicable laws, lawful requests, tax or accounting obligations, or to establish, exercise or defend legal claims.

## 6. Our Reasons for Processing Information

We will process personal information only where we have an appropriate basis for doing so under applicable law. Depending on the situation, this may include:

- Processing necessary to take steps at your request or fulfil an order;
- Meeting legal or regulatory obligations;
- Protecting legitimate business interests, where permitted by law and where those interests do not override your rights; and
- Your consent, where consent is required or is the appropriate basis for an activity, such as certain marketing or tracking activities.

Where we rely on consent, you may withdraw it. Withdrawing consent does not make processing that took place lawfully before withdrawal unlawful.

## 7. Cookies and Similar Technologies

Cookies are small files or identifiers that a website may place on your device. Similar technologies can help a website remember settings, measure activity or support advertising.

FryDays may use cookies or similar technologies for the following purposes:

- **Essential functions:** To support core website features and security, where necessary.
- **Analytics:** To understand how visitors use the website, including through Google Analytics.
- **Maps and location features:** To display maps or support location-related functions through Google Maps.
- **Advertising measurement:** To measure advertising activity or website events through Meta Pixel or related tools.
- **Website performance:** To identify technical issues and improve the customer experience.

The exact cookies and technologies used will depend on the website's configuration and the services enabled.

Where required by law, we will request consent before placing non-essential analytics or advertising cookies on your device. You may also be able to control cookies through your browser settings. Disabling certain cookies may affect website functions.

## 8. When We Share Personal Information

FryDays does not need to share all customer information with every service provider. We may share the information necessary for a specific task with the following categories of recipients:

### 8.1 Payment service providers

Payment providers or financial institutions may process payment details to authorise, complete or verify a transaction. The provider's own terms and privacy policy may apply.

### 8.2 Delivery and online ordering providers

If we use an online ordering or delivery platform, we may share information such as your name, phone number, order details and delivery address so that your order can be processed and delivered.

### 8.3 Website hosting and technical service providers

Our website hosting provider and technical support providers may process information as needed to host, maintain, secure or troubleshoot the website.

### 8.4 Google services

If enabled, Google Analytics may process website usage data and Google Maps may process information needed to display maps or provide location-related functions. Google's own privacy terms may apply to its processing.

### 8.5 Meta advertising services

If Meta Pixel or related advertising tools are enabled, certain website events and technical identifiers may be shared with Meta to measure advertising performance or support advertising services. The information shared depends on the tool's configuration.

### 8.6 WhatsApp and communications providers

When you contact us through WhatsApp, your messages and related information may be processed by WhatsApp and its service providers under their own terms and privacy policies. We may also use an email marketing service to manage communications where that service is enabled.

### 8.7 Professional advisers and authorities

We may disclose information to our professional advisers, auditors, insurers, regulators, law enforcement agencies or other authorities where reasonably necessary and legally permitted or required.

### 8.8 Business changes

If FryDays undergoes a business restructuring, sale or transfer, relevant information may be transferred as part of that process where lawful and subject to appropriate safeguards.

We expect service providers handling information on our behalf to use it only for authorised purposes and to apply appropriate safeguards.

## 9. Marketing and Your Choices

FryDays may use email, WhatsApp, SMS or other communication channels to share marketing messages, depending on the channels we operate and the permissions we have.

Where consent is required, we will seek it before sending marketing communications. We will not treat the act of placing an order as automatic consent to receive unrelated promotional messages.

You may opt out of marketing at any time by:

- Using the unsubscribe link in an email, where available;
- Replying to a marketing message with a clear request to stop;
- Contacting us using the official contact details in Section 2; or
- Following another opt-out method we provide.

After receiving your request, we will take reasonable steps to stop the relevant marketing communications. We may still send essential service messages, such as order confirmations or important updates about an order.

## 10. How We Protect Personal Information

We take reasonable steps to protect personal information from loss, misuse, unauthorised access, disclosure, alteration or destruction.

Depending on our systems and operations, these steps may include:

- Restricting access to customer information to people who need it for their work;
- Using passwords and appropriate access controls;
- Using reputable website hosting and payment providers;
- Keeping business devices and software appropriately secured;
- Avoiding the unnecessary sharing of customer information through public or unsecured channels; and
- Reviewing our handling of customer information when our systems or services change.

No website, electronic system or method of transmission is completely secure. We therefore cannot guarantee absolute security, but we will take reasonable steps appropriate to the nature of the information and the risks involved.

If a personal data breach occurs, we will assess it and take the steps required by applicable law, including any required notification to affected individuals or the relevant authority.

## 11. How Long We Keep Information

We keep personal information only for as long as reasonably necessary for the purpose for which it was collected, unless a longer period is required or permitted by law.

For example:

- Order and transaction records may be kept for business, accounting, tax, dispute-resolution or legal purposes.
- Contact details may be kept while we are responding to an enquiry or managing an ongoing customer relationship.
- Marketing information may be retained until you opt out or it is no longer needed, subject to any lawful recordkeeping needs.
- Reviews and photographs may be retained while they remain relevant to the purpose for which they were provided or authorised.
- Website analytics information may be retained according to the settings of the relevant analytics service.

When information is no longer needed, we will take reasonable steps to delete it, anonymise it or securely dispose of it, subject to applicable legal obligations.

## 12. Your Privacy Rights

Subject to applicable law and any relevant exceptions, you may have the right to:

- Ask whether we hold personal information about you;
- Request access to personal information we hold about you;
- Request correction of inaccurate or incomplete information;
- Ask us to stop or restrict certain processing where the law provides that right;
- Withdraw consent where processing is based on consent;
- Object to certain uses of your information, including direct marketing where applicable; and
- Make a complaint about how your information has been handled.

To make a request, contact us using the details in Section 2. We may need to verify your identity before responding, to help protect your information and prevent unauthorised disclosure.

We will respond in accordance with applicable law. Some information may need to be retained where a legal obligation or another lawful basis applies.

## 13. Children's Privacy

FryDays is a food and beverage business and may be used by customers of different ages. Our website is not intended to collect personal information from children in a way that breaches applicable law.

Where a child provides personal information, we will handle it in accordance with applicable legal requirements. Parents or guardians who believe a child has provided personal information to us may contact us to discuss the matter.

## 14. Third-Party Websites and Services

Our website may contain links to third-party websites or services, including WhatsApp, Google Maps, payment providers, social media platforms and online ordering or delivery services.

When you follow a link or use a third-party service, that provider may collect and process information under its own privacy policy and terms. FryDays does not control the privacy practices of independent third parties.

We encourage you to read the privacy information of any third-party service you use.

## 15. Changes to This Privacy Policy

We may update this Privacy Policy when our business, website, technology, services or legal obligations change.

When we make changes, we will update the “Last updated” date at the top of this policy. Where a change materially affects how we use personal information, we will take any additional steps required by applicable law.

We encourage you to review this policy from time to time.

## 16. Complaints and Contact

If you have a question, concern or complaint about how FryDays handles your personal information, please contact us first:

- **FryDays Bubble & Smoothies Bar**
- **Email:** frydaysghana@gmail.com
- **Phone/WhatsApp:** 059 619 8209
- **Address:** Teshie, Accra, Ghana

Please explain your concern and provide enough information for us to investigate. Do not include payment PINs, passwords or other security credentials in your complaint.

`

function renderInline(text: string): ReactNode[] {
  const normalizedText = text.replaceAll("FryDays", "Frydays")
  const tokens = normalizedText.split(/(\*\*[^*]+\*\*|frydaysghana@gmail\.com|059 619 8209)/g)

  return tokens.map((token, index) => {
    if (token.startsWith("**") && token.endsWith("**")) {
      return <strong key={index} className="font-bold text-[#09403B]">{token.slice(2, -2)}</strong>
    }
    if (token === "frydaysghana@gmail.com") {
      return <a key={index} href="mailto:frydaysghana@gmail.com" className="font-semibold text-[#09403B] underline underline-offset-4">frydaysghana@gmail.com</a>
    }
    if (token === "059 619 8209") {
      return <a key={index} href="tel:+233596198209" className="font-semibold text-[#09403B] underline underline-offset-4">059 619 8209</a>
    }
    return token
  })
}

function renderPolicy(markdown: string): ReactNode[] {
  const lines = markdown.trim().split(/\r?\n/)
  const content: ReactNode[] = []
  let index = 0

  while (index < lines.length) {
    const line = lines[index].trim()
    if (!line) {
      index += 1
      continue
    }

    const heading = /^(#{2,3})\s+(.+)$/.exec(line)
    if (heading) {
      const Heading = heading[1].length === 2 ? "h2" : "h3"
      content.push(
        <Heading
          key={`heading-${index}`}
          className={heading[1].length === 2
            ? "mt-12 border-b border-[#09403B]/15 pb-3 text-2xl font-black tracking-tight text-[#09403B] first:mt-0 md:text-3xl"
            : "mt-8 text-lg font-bold text-[#09403B]"}
        >
          {renderInline(heading[2])}
        </Heading>,
      )
      index += 1
      continue
    }

    if (line.startsWith("- ")) {
      const items: string[] = []
      while (index < lines.length && lines[index].trim().startsWith("- ")) {
        items.push(lines[index].trim().slice(2))
        index += 1
      }
      content.push(
        <ul key={`list-${index}`} className="my-5 list-disc space-y-2 pl-6 marker:text-[#8EBE27]">
          {items.map((item, itemIndex) => <li key={itemIndex} className="pl-1">{renderInline(item)}</li>)}
        </ul>,
      )
      continue
    }

    const paragraph = [line]
    index += 1
    while (
      index < lines.length
      && lines[index].trim()
      && !lines[index].trim().startsWith("- ")
      && !/^(#{2,3})\s+/.test(lines[index].trim())
    ) {
      paragraph.push(lines[index].trim())
      index += 1
    }
    content.push(
      <p key={`paragraph-${index}`} className="my-4 leading-7 text-[#09403B]/75">
        {renderInline(paragraph.join(" "))}
      </p>,
    )
  }

  return content
}

export default function PrivacyPolicyPage() {
  return (
    <main className="min-h-screen bg-[#F2DBB2]">
      <Navigation />
      <section className="bg-[#09403B] px-6 pb-14 pt-36 md:pb-20">
        <div className="mx-auto max-w-5xl">
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-[#F2DBB2]/60">Frydays Bubble &amp; Smoothies Bar</p>
          <h1 className="mt-4 text-5xl font-black leading-[0.95] tracking-tight text-[#F2DBB2] md:text-7xl">Privacy Policy</h1>
          <div className="mt-8 flex flex-wrap gap-x-8 gap-y-2 text-sm font-medium text-[#F2DBB2]/65">
            <p><span className="text-[#F2DBB2]">Effective date:</span> 2026</p>
            <p><span className="text-[#F2DBB2]">Last updated:</span> 2026</p>
          </div>
        </div>
      </section>

      <article className="mx-auto max-w-5xl px-6 py-12 md:py-16">
        <div className="rounded-2xl border border-[#09403B]/10 bg-[#F7E8CB] p-6 text-sm leading-6 text-[#09403B]/75 md:p-10 md:text-base">
          {renderPolicy(policyMarkdown)}
        </div>
      </article>
      <Footer />
    </main>
  )
}

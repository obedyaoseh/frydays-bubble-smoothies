import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { EsgContent } from "@/components/esg-content"
import { pageMetadata } from "@/lib/seo"

export const metadata = pageMetadata({
  title: "Community & Sustainability in Teshie",
  description: "Learn how Frydays supports its Teshie community and works toward responsible, locally connected operations.",
  path: "/esg",
})

export default function EsgPage() {
  return (
    <main className="min-h-screen bg-[#F2DBB2]">
      <Navigation />
      <EsgContent />
      <Footer />
    </main>
  )
}

import type React from "react"
import type { Metadata, Viewport } from "next"
import { LenisProvider } from "@/components/lenis-provider"
import ClickSpark from "@/components/click-spark"
import { CartProvider } from "@/components/cart-provider"
import { SiteStructuredData } from "@/components/site-structured-data"
import { DEFAULT_DESCRIPTION, SITE_NAME, SITE_URL } from "@/lib/seo"
import "./globals.css"

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "Smoothies & Bubble Tea in Teshie, Accra | Frydays",
    template: "%s | Frydays",
  },
  description: DEFAULT_DESCRIPTION,
  applicationName: SITE_NAME,
  icons: {
    icon: [
      { url: "/icon.svg", type: "image/svg+xml" },
      { url: "/icon-dark-32x32.png", sizes: "32x32", type: "image/png" },
    ],
    apple: "/apple-icon.png",
  },
  keywords: [
    "smoothies in Teshie",
    "bubble tea in Teshie",
    "smoothie bar Accra",
    "bubble tea Accra",
    "pastries in Teshie",
    "order smoothies Ghana",
    "Frydays",
  ],
  robots: { index: true, follow: true },
  openGraph: {
    type: "website",
    siteName: SITE_NAME,
    locale: "en_GH",
    title: "Smoothies & Bubble Tea in Teshie, Accra | Frydays",
    description: DEFAULT_DESCRIPTION,
    images: [{
      url: "/opengraph-image",
      width: 1200,
      height: 630,
      alt: "Frydays smoothies, bubble tea, and pastries in Teshie, Accra",
    }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Smoothies & Bubble Tea in Teshie, Accra",
    description: DEFAULT_DESCRIPTION,
    images: ["/opengraph-image"],
  },
}

export const viewport: Viewport = {
  themeColor: "#09403B",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className="font-sans antialiased">
        <SiteStructuredData />
        <ClickSpark
          sparkColor="#09403B"
          sparkSize={12}
          sparkRadius={20}
          sparkCount={8}
          duration={400}
          easing="ease-out"
        >
          <LenisProvider>
            <CartProvider>{children}</CartProvider>
          </LenisProvider>
        </ClickSpark>
      </body>
    </html>
  )
}

import { ImageResponse } from "next/og"

export const size = { width: 1200, height: 630 }
export const contentType = "image/png"
export const alt = "Frydays smoothies, bubble tea, and pastries in Teshie, Accra"

export default function OpenGraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          backgroundColor: "#09403B",
          color: "#F2DBB2",
          padding: "68px 78px",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            right: -100,
            top: -160,
            width: 520,
            height: 520,
            borderRadius: 260,
            border: "2px solid rgba(242, 219, 178, 0.15)",
          }}
        />
        <div
          style={{
            position: "absolute",
            right: 30,
            bottom: -330,
            width: 560,
            height: 560,
            borderRadius: 280,
            backgroundColor: "rgba(142, 190, 39, 0.18)",
          }}
        />
        <div style={{ display: "flex", flexDirection: "column", maxWidth: 930, position: "relative" }}>
          <div style={{ color: "#A9C36C", fontSize: 22, fontWeight: 700, letterSpacing: 5 }}>
            FRYDAYS BUBBLE &amp; SMOOTHIES BAR
          </div>
          <div style={{ display: "flex", flexDirection: "column", marginTop: 28, fontSize: 72, fontWeight: 800, lineHeight: 1.05, letterSpacing: -2 }}>
            <span>Fresh smoothies.</span>
            <span>Bubble tea. Teshie.</span>
          </div>
          <div style={{ marginTop: 28, fontSize: 28, color: "rgba(242, 219, 178, 0.78)" }}>
            Pastries, pickup, and delivery in Accra
          </div>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              alignSelf: "flex-start",
              marginTop: 34,
              padding: "13px 24px",
              borderRadius: 999,
              backgroundColor: "#8EBE27",
              color: "#09403B",
              fontSize: 20,
              fontWeight: 800,
            }}
          >
            ORDER ONLINE
          </div>
        </div>
      </div>
    ),
    size,
  )
}

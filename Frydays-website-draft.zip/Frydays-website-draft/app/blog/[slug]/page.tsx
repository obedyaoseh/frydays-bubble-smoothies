import type { Metadata } from "next"
import { notFound } from "next/navigation"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { JournalStory } from "@/components/journal-story"
import { getJournalStory, journalStories } from "@/lib/journal-data"
import { pageMetadata } from "@/lib/seo"

export function generateStaticParams() {
  return journalStories.map((story) => ({ slug: story.slug }))
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params
  const story = getJournalStory(slug)
  if (!story) return pageMetadata({
    title: "Frydays Journal",
    description: "Stories about drinks, people, and life in Teshie, Accra.",
    path: `/blog/${slug}`,
  })
  return pageMetadata({
    title: story.title,
    description: story.excerpt,
    path: `/blog/${slug}`,
    type: "article",
  })
}

export default async function JournalStoryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  if (!getJournalStory(slug)) notFound()

  return (
    <main className="min-h-screen bg-[#F2DBB2]">
      <Navigation />
      <JournalStory slug={slug} />
      <Footer />
    </main>
  )
}
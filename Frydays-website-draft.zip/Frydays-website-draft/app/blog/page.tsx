import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { BlogContent } from "@/components/blog-content"
import { pageMetadata } from "@/lib/seo"

export const metadata = pageMetadata({
  title: "Drinks & Stories from Teshie",
  description: "Read the Frydays Journal for stories about smoothies, bubble tea, fresh flavours, community, and everyday life in Teshie, Accra.",
  path: "/blog",
})

export default function BlogPage() {
  return (
    <main className="min-h-screen bg-[#F2DBB2]">
      <Navigation />
      <BlogContent />
      <Footer />
    </main>
  )
}
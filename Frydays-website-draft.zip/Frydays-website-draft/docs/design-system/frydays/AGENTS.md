# Frydays Design System

This directory is the source of truth for the Frydays visual language. Read this file and `design-system.md` before creating or restyling any Frydays UI artifact.

## Product character

Frydays is a family-grown smoothie and bubble tea brand in Teshie, Accra. The experience should feel sunny, welcoming, confident, and easy to remember: a little playful, never childish; crafted, never precious.

## Application rules

1. Use the semantic tokens in `app/globals.css` and the values documented in `design-system.md`; do not invent a competing palette.
2. Use Axiforma for display typography and Neuzeit for supporting/body typography. Until licensed font files are added, preserve the declared fallback stacks.
3. Prefer the existing cream/forest contrast system over white/gray defaults.
4. Use short, warm, direct copy. Keep “Every day deserves a little Friday.” as the recurring brand line.
5. Preserve responsive behavior: layouts should work from narrow phones through wide desktop screens.
6. Keep interactions tactile but restrained. Motion should clarify hierarchy or reward an action, not distract from ordering or navigation.
7. Use real product imagery with rounded crops, strong contrast, and generous breathing room. Do not add generic stock imagery when an existing Frydays asset is suitable.
8. Maintain accessible contrast, visible focus states, descriptive image alt text, keyboard access, and reduced-motion support for animated interactions.

## Before authoring an artifact

- Read `design-system.md`.
- Map any new color, type, spacing, radius, or motion choice to an existing token.
- Reuse existing navigation, button, card, link, and order-flow patterns where possible.
- If a new primitive is genuinely needed, add it to the design-system document before using it broadly.
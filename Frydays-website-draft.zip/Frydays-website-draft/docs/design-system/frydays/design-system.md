# Frydays Design System

**Status:** Extracted from the current Frydays website draft  
**Version:** 1.0  
**Brand:** Frydays Smoothie & Bubble Tea Shop  
**Place:** Teshie, Accra, Ghana

## 1. Design north star

Frydays turns an everyday drink stop into a small social ritual. The design should feel like warm afternoon light, a family table, and a confident handwritten recommendation from someone who knows what tastes good.

The system balances:

- **Warmth:** cream backgrounds, soft edges, welcoming language
- **Confidence:** oversized display type, forest-green blocks, decisive CTAs
- **Freshness:** fruit-forward imagery, clean negative space, natural green accents
- **Togetherness:** invitations to gather, share, stay, and come back

Avoid anything clinical, overly corporate, luxury-minimal, or visually noisy.

## 2. Brand tokens

### Core colors

| Token | Value | Role |
|---|---|---|
| `--cream` | `#F2DBB2` | Primary light canvas and warm text on dark surfaces |
| `--forest` | `#09403B` | Primary dark canvas, display text, navigation, and CTA |
| `--cream-dark` | `#E8C98A` | Subtle borders, hover tint, and secondary warm surfaces |
| `--forest-light` | `#0F5C54` | Hover state and softened forest accent |
| `--sun` | `#F5B735` | High-attention ordering/action accent |
| `--paper` | `#F8EFD9` | Soft alternate section background |

### Color behavior

- Default light composition: cream canvas with forest text.
- Default dark composition: forest canvas with cream text.
- Use sun yellow sparingly for the primary “Explore our menu” or urgent ordering action.
- Muted copy is the base color at 55–70% opacity, not a separate gray palette.
- Do not use pure white as the main page background.
- Product photography may introduce supporting colors, but text and controls must remain in the core palette.

## 3. Typography

### Families

| Role | Family | Fallback |
|---|---|---|
| Display / headlines | Axiforma | `"Arial Black", "Helvetica Neue", Arial, sans-serif` |
| Body / UI / supporting copy | Neuzeit | `"Helvetica Neue", Arial, sans-serif` |

### Type roles

| Role | Guidance |
|---|---|
| Hero display | Very large, tight leading, strong weight, minimal line count |
| Section heading | Bold and compact with a clear editorial rhythm |
| Eyebrow | Uppercase, small, semibold, wide tracking |
| Body | Comfortable reading width, medium weight, relaxed line height |
| CTA | Bold, compact, sentence case or short title case |
| Product label | Small uppercase metadata above a bold product name |

Use sentence case for meaningful messages. Reserve uppercase for eyebrows, labels, and compact CTAs.

## 4. Layout and spacing

### Container

- Primary content width: `max-w-7xl` for broad landing-page compositions.
- Reading width: `max-w-xl` to `max-w-2xl`.
- Horizontal padding: `px-6` on desktop and mobile, with responsive expansion only when needed.
- Keep major sections generous: roughly `py-20` to `py-28` on desktop, reduced but still breathable on mobile.

### Rhythm

Use a calm spacing scale based on multiples of 4:

`4 / 8 / 12 / 16 / 20 / 24 / 32 / 48 / 64 / 80 / 112`

- 4–12: icon gaps, label gaps, small control padding
- 16–24: card padding, button padding, compact content groups
- 32–48: content group separation
- 64–112: section separation and hero breathing room

Do not make every section equally dense. Alternate full-bleed color blocks with spacious editorial sections.

## 5. Shape language

- Default card radius: `rounded-2xl`
- Feature/hero media radius: `rounded-3xl`
- Pills and compact actions: `rounded-full`
- Use soft corners consistently; avoid sharp rectangular cards unless a media crop or editorial block benefits from contrast.
- Borders should be subtle forest/cream alpha layers rather than gray outlines.

## 6. Component patterns

### Navigation

- Fixed, lightweight, and transparent over the light hero.
- On scroll, use a forest backdrop with cream logo/text.
- Use the supplied light/dark Frydays PNG logo variants.
- Keep desktop links concise and expose the order action clearly.
- Mobile navigation should remain simple, full-width, and easy to dismiss.

### Buttons and links

Primary:

- Forest background
- Cream text
- Rounded pill or soft rectangle
- Bold type
- Small directional icon where useful

Accent:

- Sun yellow background
- Forest text
- Reserved for the highest-priority conversion action

Secondary:

- Transparent or cream surface
- Forest border/text
- Use for exploratory or supporting actions

Hover behavior should lift or shift subtly, not flash. Every button needs a visible focus state.

### Cards

- Use a clear tonal surface: forest, soft paper, or a low-alpha forest tint.
- Keep a single strong message per card.
- Use real imagery with an intentional crop and a readable overlay when text sits on media.
- Product cards should make the product name, description, price, and order action scannable.

### Sections

Recommended sequence logic for landing pages:

1. High-impact brand statement
2. Warm explanation or invitation
3. Product proof through imagery
4. Community or story moment
5. Values / impact
6. Growth or partnership invitation
7. Short final CTA

This is a composition guideline, not a requirement to duplicate a fixed page.

## 7. Imagery

Preferred imagery:

- Fresh drinks, fruit, matcha, pours, and hands-in-process
- Vertical crops that make drinks feel tactile and close
- Natural or warm light
- Cream, green, berry, and fruit tones that complement the palette

Current signature assets:

- `public/images/signature-matcha.jpg`
- `public/images/signature-blueberry.jpg`
- `public/images/signature-pistachio.jpg`
- `public/images/signature-matcha-pour.jpg`
- `public/images/signature-green-pour.jpg`

Always provide useful alt text. Decorative background images should be hidden from assistive technology.

## 8. Motion and interaction

- Use staggered entrance reveals for hero and section content.
- Use small upward lifts for cards and buttons.
- Use slow, low-amplitude ambient shapes only in large open areas.
- Use spring-like motion for carousel or tactile product interactions.
- Keep animation durations around 200–800ms for UI and up to 9s for ambient motion.
- Respect `prefers-reduced-motion` and preserve content visibility when motion is disabled.

## 9. Content voice

Frydays copy is:

- Warm, direct, and optimistic
- Youthful without slang overload
- Community-minded without sounding institutional
- Specific about freshness and care
- Inviting rather than pushy

Preferred phrases:

- “Every day deserves a little Friday.”
- “Made fresh. Served with heart.”
- “Come as you are. Stay a little longer.”
- “Good food fills the table. Good people fill the heart.”
- “Fresh by choice. Family by nature. Community at heart.”

Avoid exaggerated health claims, generic “premium experience” language, and hard-sell investment copy.

## 10. Accessibility checklist

- Maintain readable forest-on-cream and cream-on-forest contrast.
- Never use color alone to communicate state.
- Keep focus rings visible against both core backgrounds.
- Use semantic headings in order.
- Keep touch targets at least 44px where practical.
- Provide labels for form controls and useful alt text for meaningful images.
- Ensure animated content remains understandable with reduced motion.
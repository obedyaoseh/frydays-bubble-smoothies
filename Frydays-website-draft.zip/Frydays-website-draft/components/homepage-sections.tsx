"use client"

import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { ArrowRight, ArrowUpRight, Heart, Leaf, Users } from "lucide-react"
import { journalStories } from "@/lib/journal-data"

const signatureDrinks = [
  {
    name: "Matcha Cloud",
    detail: "Creamy matcha · Whipped finish",
    image: "/images/signature-matcha.jpg",
    tone: "bg-[#274d3e]",
  },
  {
    name: "Blueberry Slush",
    detail: "Real berries · Bright & icy",
    image: "/images/signature-blueberry.jpg",
    tone: "bg-[#d6e1eb]",
  },
  {
    name: "Pistachio Cream",
    detail: "Nutty · Smooth · Indulgent",
    image: "/images/signature-pistachio.jpg",
    tone: "bg-[#9eae89]",
  },
  {
    name: "Matcha Pour",
    detail: "Clean energy · Earthy goodness",
    image: "/images/signature-matcha-pour.jpg",
    tone: "bg-[#f4f3f0]",
  },
  {
    name: "Green Glow",
    detail: "Fresh greens · Made to order",
    image: "/images/signature-green-pour.jpg",
    tone: "bg-[#e7eee3]",
  },
]

const values = [
  { icon: Leaf, title: "Fresh by choice.", body: "Real fruit, honest ingredients, and blends made fresh when you order." },
  { icon: Heart, title: "Family by nature.", body: "Frydays began around a family kitchen counter — and that warmth is still in every cup." },
  { icon: Users, title: "Community at heart.", body: "A welcoming place for neighbours, friends, families, and everyone in between." },
]

export function HomepageSections() {
  return (
    <>
      <section className="bg-[#F2DBB2] py-20 md:py-28">
        <div className="mx-auto grid max-w-6xl gap-12 px-6 lg:grid-cols-[0.8fr_1.2fr] lg:items-center">
          <motion.div initial={{ opacity: 0, x: -24 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}>
            <p className="text-xs font-bold uppercase tracking-[0.28em] text-[#09403B]/55">A little something good</p>
            <h2 className="mt-4 max-w-md text-4xl font-black leading-[0.95] tracking-tight text-[#09403B] md:text-6xl">
              Made Fresh.
              <br />
              <span className="text-[#09403B]/60">Served With Heart.</span>
            </h2>
          </motion.div>
          <motion.div className="max-w-xl" initial={{ opacity: 0, x: 24 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}>
            <p className="text-lg font-medium leading-relaxed text-[#09403B]/75">
              At Frydays, we believe good food and good drinks have a way of bringing people closer.
            </p>
            <p className="mt-5 text-base font-medium leading-relaxed text-[#09403B]/60">
              From fresh fruit smoothies to colourful bubble teas, everything is prepared with care and served with a smile. Whether you are grabbing a quick drink, meeting a friend, or spending time with family, there is always a place for you here.
            </p>
            <p className="mt-6 font-black text-[#09403B]">Come as you are. Stay a little longer.</p>
          </motion.div>
        </div>
      </section>

      <section id="signature" className="bg-[#f8efd9] py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-6">
          <div className="mb-10 flex flex-col justify-between gap-5 md:flex-row md:items-end">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.28em] text-[#09403B]/55">Our signature</p>
              <h2 className="mt-3 text-4xl font-black tracking-tight text-[#09403B] md:text-6xl">Blend. Sip. Smile. Repeat.</h2>
            </div>
            <Link href="/order" className="inline-flex items-center gap-2 self-start rounded-full bg-[#09403B] px-5 py-3 text-sm font-black text-[#F2DBB2] transition-transform hover:-translate-y-1 md:self-auto">
              View the full menu <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {signatureDrinks.map((drink, index) => (
              <motion.div
                key={drink.name}
                className={`group overflow-hidden rounded-2xl ${drink.tone}`}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.08 }}
                whileHover={{ y: -6 }}
              >
                <Link href="/order" className="block">
                  <div className="relative aspect-[4/5] overflow-hidden">
                    <Image src={drink.image} alt={drink.name} fill className="object-cover transition-transform duration-700 group-hover:scale-105" />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#09403B]/80 via-transparent to-transparent" />
                    <div className="absolute bottom-0 p-5 text-[#F2DBB2]">
                      <p className="text-lg font-black">{drink.name}</p>
                      <p className="mt-1 text-xs font-semibold text-[#F2DBB2]/70">{drink.detail}</p>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>

          <div className="mt-12 grid gap-5 md:grid-cols-2">
            <motion.div className="rounded-3xl bg-[#09403B] p-8 text-[#F2DBB2]" initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <p className="text-3xl">🍓</p>
              <h3 className="mt-5 text-2xl font-black">Smoothies</h3>
              <p className="mt-2 max-w-md text-sm font-medium leading-relaxed text-[#F2DBB2]/65">Fresh fruits. Real blends. No fuss. From classic favourites to bold new combinations, our smoothies are made for every kind of day.</p>
              <Link href="/order" className="mt-6 inline-flex items-center gap-2 text-sm font-black">View Smoothies <ArrowRight className="h-4 w-4" /></Link>
            </motion.div>
            <motion.div className="rounded-3xl border-2 border-[#09403B]/15 p-8 text-[#09403B]" initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <p className="text-3xl">🧋</p>
              <h3 className="mt-5 text-2xl font-black">Bubble Tea</h3>
              <p className="mt-2 max-w-md text-sm font-medium leading-relaxed text-[#09403B]/65">A little fun in every cup. Pick your tea, choose your flavour, add your favourite pearls, and make it yours.</p>
              <Link href="/order" className="mt-6 inline-flex items-center gap-2 text-sm font-black">Explore Bubble Tea <ArrowRight className="h-4 w-4" /></Link>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="bg-[#09403B] py-20 text-[#F2DBB2] md:py-28">
        <div className="mx-auto grid max-w-6xl gap-12 px-6 lg:grid-cols-2 lg:items-center">
          <motion.div initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <p className="text-xs font-bold uppercase tracking-[0.28em] text-[#F2DBB2]/55">More than a shop</p>
            <h2 className="mt-4 text-4xl font-black leading-[0.95] tracking-tight md:text-6xl">A Place To Gather.</h2>
            <p className="mt-6 max-w-xl text-base font-medium leading-relaxed text-[#F2DBB2]/70">
              Frydays started around a family kitchen counter. Today, we are building a space for the wider community — a place for neighbours to meet, friends to catch up, families to celebrate, and everyone to enjoy something good.
            </p>
            <p className="mt-6 text-xl font-black">Good food fills the table.<br />Good people fill the heart.</p>
            <Link href="/about" className="mt-8 inline-flex items-center gap-2 rounded-full bg-[#F2DBB2] px-6 py-3 text-sm font-black text-[#09403B]">Read Our Story <ArrowRight className="h-4 w-4" /></Link>
          </motion.div>
          <motion.div className="grid grid-cols-2 gap-3" initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }}>
            <div className="relative col-span-2 aspect-[2/1] overflow-hidden rounded-3xl">
              <Image src="/images/signature-matcha.jpg" alt="A fresh Frydays smoothie" fill className="object-cover" />
              <div className="absolute inset-0 bg-[#09403B]/20" />
            </div>
            <div className="relative aspect-square overflow-hidden rounded-3xl">
              <Image src="/images/signature-blueberry.jpg" alt="Blueberry smoothie" fill className="object-cover" />
            </div>
            <div className="flex aspect-square items-center justify-center rounded-3xl bg-[#F2DBB2] p-6 text-center text-[#09403B]">
              <p className="text-xl font-black md:text-2xl">Every day deserves a little Friday.</p>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="bg-[#F2DBB2] py-20 md:py-28">
        <div className="mx-auto max-w-6xl px-6">
          <div className="mb-10">
            <p className="text-xs font-bold uppercase tracking-[0.28em] text-[#09403B]/55">Why Frydays?</p>
            <h2 className="mt-3 max-w-2xl text-4xl font-black leading-[0.95] tracking-tight text-[#09403B] md:text-6xl">Fresh by choice.<br />Family by nature.<br />Community at heart.</h2>
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            {values.map((value, index) => (
              <motion.div key={value.title} className="rounded-2xl bg-[#09403B]/[0.06] p-6" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.1 }}>
                <value.icon className="h-7 w-7 text-[#09403B]" />
                <h3 className="mt-6 text-2xl font-black text-[#09403B]">{value.title}</h3>
                <p className="mt-3 text-sm font-medium leading-relaxed text-[#09403B]/60">{value.body}</p>
              </motion.div>
            ))}
          </div>
          <p className="mt-10 max-w-2xl text-base font-medium leading-relaxed text-[#09403B]/70">We care about what goes into your cup, who we serve, and the kind of place we are building. Our journey is about more than selling drinks. It is about creating something that can grow, create opportunities, support communities, and leave a positive mark.</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link href="/about" className="inline-flex items-center gap-2 rounded-full bg-[#09403B] px-5 py-3 text-sm font-black text-[#F2DBB2]">Our Journey <ArrowRight className="h-4 w-4" /></Link>
            <Link href="/esg" className="inline-flex items-center gap-2 rounded-full border-2 border-[#09403B] px-5 py-3 text-sm font-black text-[#09403B]">Our ESG Commitment <ArrowRight className="h-4 w-4" /></Link>
          </div>
        </div>
      </section>

      <section className="bg-[#F2DBB2] py-20">
        <div className="mx-auto max-w-6xl px-6">
          <div className="mb-10 flex flex-col justify-between gap-6 md:flex-row md:items-end">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.28em] text-[#09403B]/55">From the Frydays journal</p>
              <h2 className="mt-3 max-w-2xl text-4xl font-black tracking-tight text-[#09403B] md:text-5xl">Stories, People & Good Things</h2>
            </div>
            <p className="max-w-sm text-sm font-medium leading-relaxed text-[#09403B]/60 md:text-right">Three little stories from the people, pours, and places that make every day feel like Friday.</p>
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            {journalStories.map((story, index) => (
              <motion.article
                key={story.slug}
                className="group overflow-hidden rounded-3xl bg-[#09403B] text-[#F2DBB2]"
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -5 }}
              >
                <Link href={`/blog/${story.slug}`} className="block">
                  <div className="relative aspect-[4/3] overflow-hidden">
                    <Image src={story.image} alt={story.title} fill className="object-cover transition-transform duration-700 group-hover:scale-105" />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#09403B]/85 via-[#09403B]/10 to-transparent" />
                    <div className="absolute bottom-4 left-5 right-5 flex items-center justify-between text-xs font-bold uppercase tracking-[0.16em] text-[#F2DBB2]/65">
                      <span>{String(index + 1).padStart(2, "0")} · {story.category}</span>
                      <ArrowUpRight className="h-4 w-4 text-[#F2DBB2]" />
                    </div>
                  </div>
                  <div className="p-5">
                    <h3 className="text-2xl font-black leading-tight">{story.title}</h3>
                    <p className="mt-3 text-sm font-medium leading-relaxed text-[#F2DBB2]/65">{story.excerpt}</p>
                    <span className="mt-6 inline-flex items-center gap-2 text-sm font-black">Read the Journal <ArrowRight className="h-4 w-4" /></span>
                  </div>
                </Link>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-[#09403B] py-24 text-center text-[#F2DBB2]">
        <div className="mx-auto max-w-3xl px-6">
          <h2 className="text-5xl font-black tracking-tight md:text-7xl">Pull Up A Chair.</h2>
          <p className="mt-4 text-lg font-medium text-[#F2DBB2]/65">There is always room for one more.</p>
          <p className="mt-6 text-sm font-semibold text-[#F2DBB2]/55">Frydays Smoothie & Bubble Tea Shop<br />Fresh drinks. Good people. Everyday Friday.</p>
          <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
            <Link href="/contact" className="rounded-full bg-[#F2DBB2] px-7 py-4 text-sm font-black text-[#09403B]">Find Us</Link>
            <Link href="/order" className="rounded-full border-2 border-[#F2DBB2]/35 px-7 py-4 text-sm font-black text-[#F2DBB2]">View Menu</Link>
          </div>
        </div>
      </section>
    </>
  )
}
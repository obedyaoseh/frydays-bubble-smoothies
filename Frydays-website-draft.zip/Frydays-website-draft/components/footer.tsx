"use client"

import { motion, useInView } from "framer-motion"
import { useState, useRef, type FormEvent } from "react"
import Link from "next/link"
import Image from "next/image"
import { Facebook, Instagram, Linkedin, Mail, Music2, Phone } from "lucide-react"
import { SocialSection } from "@/components/social-section"

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08, delayChildren: 0.15 },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 15 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { type: "spring", stiffness: 100, damping: 20 },
  },
}

export function Footer() {
  const [email, setEmail] = useState("")
  const [consent, setConsent] = useState(false)
  const [website, setWebsite] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [newsletterStatus, setNewsletterStatus] = useState<"idle" | "subscribed" | "already-subscribed">("idle")
  const [newsletterError, setNewsletterError] = useState("")
  const footerRef = useRef(null)
  const isInView = useInView(footerRef, { once: true, margin: "-100px" })

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (isSubmitting) return

    setIsSubmitting(true)
    setNewsletterStatus("idle")
    setNewsletterError("")

    try {
      const response = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, consent, website }),
      })
      const result = await response.json().catch(() => null)
      if (!response.ok) {
        throw new Error(result?.error ?? "We couldn't add you to the list right now. Please try again later.")
      }

      setNewsletterStatus(result?.alreadySubscribed ? "already-subscribed" : "subscribed")
      setEmail("")
      setConsent(false)
      setWebsite("")
    } catch (error) {
      setNewsletterError(error instanceof Error ? error.message : "We couldn't add you to the list right now. Please try again later.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const footerLinks = [
    {
      title: "Menu",
      href: "/order",
      links: [
        { label: "Smoothies", href: "/order#drinks" },
        { label: "Bubble Tea", href: "/order#drinks" },
        { label: "Pastries", href: "/order#pastries" },
        { label: "Desserts", href: "/order#pastries" },
      ],
    },
    {
      title: "Pages",
      links: [
        { label: "Home", href: "/" },
        { label: "About Us", href: "/about" },
        { label: "ESG", href: "/esg" },
        { label: "Franchise", href: "/franchise" },
        { label: "Contact", href: "/contact" },
      ],
    },
    {
      title: "Services",
      links: [
        { label: "Event Catering", href: "#" },
        { label: "Corporate Wellness", href: "#" },
        { label: "Gift Packages", href: "#" },
        { label: "Group Orders", href: "#" },
      ],
    },
    {
      title: "Legal",
      links: [
        { label: "Privacy Policy", href: "/privacy" },
        { label: "Terms of Service", href: "/terms" },
      ],
    },
  ]

  return (
    <footer ref={footerRef} id="contact-footer" className="relative bg-[#09403B] pt-16 pb-6 overflow-hidden">
      <SocialSection />
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 60 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: [0.25, 0.4, 0.25, 1] }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-6xl font-black text-[#F2DBB2] tracking-tight leading-[0.9] overflow-hidden">
            <motion.span
              className="block"
              initial={{ y: 100 }}
              whileInView={{ y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1] }}
            >
              Ready for a
            </motion.span>
            <motion.span
              className="block text-[#F2DBB2]/70"
              initial={{ y: 100 }}
              whileInView={{ y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1], delay: 0.1 }}
            >
              Fresh Sip?
            </motion.span>
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="max-w-xl mx-auto mb-12"
        >
          <form onSubmit={handleSubmit} className="space-y-3">
            <div className="hidden" aria-hidden="true">
              <label htmlFor="newsletter-website">Leave this field blank</label>
              <input
                id="newsletter-website"
                name="website"
                value={website}
                onChange={(event) => setWebsite(event.target.value)}
                tabIndex={-1}
                autoComplete="off"
              />
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <motion.div className="flex-1 relative" whileFocus={{ scale: 1.02 }}>
                <label htmlFor="newsletter-email" className="sr-only">Email address</label>
                <input
                  id="newsletter-email"
                  name="email"
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(event) => {
                    setEmail(event.target.value)
                    setNewsletterStatus("idle")
                    setNewsletterError("")
                  }}
                  placeholder="your@email.com"
                  className="w-full bg-[#F2DBB2]/5 border-2 border-[#F2DBB2]/20 rounded-xl px-4 py-3 text-[#F2DBB2] placeholder:text-[#F2DBB2]/40 text-sm focus:outline-none focus:border-[#F2DBB2] transition-all duration-300"
                />
              </motion.div>
              <motion.button
                type="submit"
                disabled={isSubmitting}
                className="bg-[#F2DBB2] text-[#09403B] px-6 py-3 rounded-xl font-bold text-sm tracking-wide whitespace-nowrap relative overflow-hidden disabled:cursor-not-allowed disabled:opacity-70"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                transition={{ type: "spring", stiffness: 400, damping: 17 }}
              >
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                  initial={{ x: "-100%" }}
                  whileHover={{ x: "100%" }}
                  transition={{ duration: 0.5 }}
                />
                <motion.span
                  className="relative z-10"
                  animate={isSubmitting ? { opacity: [1, 0.5, 1] } : {}}
                  transition={{ duration: 0.5, repeat: isSubmitting ? Infinity : 0 }}
                >
                  {isSubmitting ? "Joining..." : "Get Updates"}
                </motion.span>
              </motion.button>
            </div>
            <label className="flex items-start justify-center gap-2 text-left text-xs leading-relaxed text-[#F2DBB2]/65 cursor-pointer">
              <input
                type="checkbox"
                required
                checked={consent}
                onChange={(event) => {
                  setConsent(event.target.checked)
                  setNewsletterStatus("idle")
                  setNewsletterError("")
                }}
                className="mt-0.5 accent-[#F2DBB2]"
              />
              <span>I agree to receive Frydays menu, offer, and event emails. I can unsubscribe anytime.</span>
            </label>
            {newsletterStatus === "subscribed" && (
              <p role="status" className="text-sm text-center font-semibold text-[#F2DBB2]">
                You’re on the Frydays updates list. Thanks for signing up!
              </p>
            )}
            {newsletterStatus === "already-subscribed" && (
              <p role="status" className="text-sm text-center font-semibold text-[#F2DBB2]">
                This email is already on the Frydays updates list.
              </p>
            )}
            {newsletterError && (
              <p role="alert" className="text-sm text-center font-semibold text-red-200">
                {newsletterError}
              </p>
            )}
          </form>
          <p className="text-[#F2DBB2]/40 text-xs mt-2 text-center font-medium">
            New menu drops, offers, and Teshie events. No spam.{" "}
            <Link href="/privacy" className="underline underline-offset-2 hover:text-[#F2DBB2]/70">
              Privacy policy
            </Link>
          </p>
        </motion.div>

        <motion.div
          className="text-center mb-10"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
        >
          <p className="text-[#F2DBB2]/50 text-xs max-w-xl mx-auto leading-relaxed font-medium">
            Frydays Bubble & Smoothies Bar is Teshie's go-to spot for handcrafted bubble teas, fresh-blended smoothies,
            and 100% natural drinks. Come sip with us.
          </p>
        </motion.div>

        <motion.div
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6 py-8 border-t border-[#F2DBB2]/10"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {footerLinks.map((section) => (
            <motion.div key={section.title} variants={itemVariants}>
              {section.href ? (
                <Link href={section.href} className="font-bold text-[#F2DBB2] text-sm mb-3 inline-block hover:text-white transition-colors">
                  {section.title}
                </Link>
              ) : (
                <h4 className="font-bold text-[#F2DBB2] text-sm mb-3">{section.title}</h4>
              )}
              <ul className="space-y-2">
                {section.links.map((item) => (
                  <li key={item.label}>
                    <motion.div whileHover={{ x: 4 }} transition={{ type: "spring", stiffness: 400, damping: 17 }}>
                      <Link
                        href={item.href}
                        className="text-[#F2DBB2]/50 hover:text-[#F2DBB2] text-xs transition-colors inline-block font-medium"
                      >
                        {item.label}
                      </Link>
                    </motion.div>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
          <motion.div variants={itemVariants}>
            <h4 className="font-bold text-[#F2DBB2] text-sm mb-3">Contact</h4>
            <ul className="space-y-3">
              <li>
                <a href="tel:+233596198209" className="inline-flex items-center gap-2 text-[#F2DBB2]/50 hover:text-[#F2DBB2] text-xs transition-colors font-medium">
                  <Phone className="h-3.5 w-3.5" aria-hidden="true" />
                  059 619 8209
                </a>
              </li>
              <li>
                <a href="mailto:frydaysghana@gmail.com" className="inline-flex items-center gap-2 text-[#F2DBB2]/50 hover:text-[#F2DBB2] text-xs transition-colors font-medium">
                  <Mail className="h-3.5 w-3.5" aria-hidden="true" />
                  frydaysghana@gmail.com
                </a>
              </li>
            </ul>
            <div className="mt-4 flex items-center gap-3">
              <a href="https://www.instagram.com/frydaysghana?mdxt=eXRvZTRuZTZuczJt&utm_source=qr" target="_blank" rel="noopener noreferrer" aria-label="Instagram" title="Instagram" className="text-[#F2DBB2]/55 hover:text-[#F2DBB2] transition-colors">
                <Instagram className="h-4 w-4" aria-hidden="true" />
              </a>
              <a href="https://www.tiktok.com/@frydaysghana" target="_blank" rel="noopener noreferrer" aria-label="TikTok" title="TikTok" className="text-[#F2DBB2]/55 hover:text-[#F2DBB2] transition-colors">
                <Music2 className="h-4 w-4" aria-hidden="true" />
              </a>
              <a href="https://www.linkedin.com/company/frydays-bubble-smoothies-bar/home/?viewAsMember=true" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn" title="LinkedIn" className="text-[#F2DBB2]/55 hover:text-[#F2DBB2] transition-colors">
                <Linkedin className="h-4 w-4" aria-hidden="true" />
              </a>
              <a href="https://www.facebook.com/share/1C78bDbC2J/?mibextid=wwXIfr" target="_blank" rel="noopener noreferrer" aria-label="Facebook" title="Facebook" className="text-[#F2DBB2]/55 hover:text-[#F2DBB2] transition-colors">
                <Facebook className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </motion.div>
        </motion.div>

        <motion.div
          className="flex flex-col md:flex-row justify-between items-center pt-6 border-t border-[#F2DBB2]/10 gap-3"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
        >
          <motion.div
            className="relative w-28 h-8"
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 400, damping: 17 }}
          >
            <Image src="/images/frydays-cream.png" alt="Frydays" fill className="object-contain" />
          </motion.div>

          <p className="text-[#F2DBB2]/40 text-xs font-medium">© 2026 Frydays Bubble & Smoothies Bar. Teshie, Accra.</p>

          <p className="text-[#F2DBB2]/30 text-xs font-medium">
            Made with 🍃 in Teshie
          </p>
        </motion.div>
      </div>

      <motion.div
        className="absolute bottom-0 left-1/2 -translate-x-1/2 text-[10rem] md:text-[20rem] font-black text-[#F2DBB2]/[0.02] pointer-events-none select-none leading-none"
        initial={{ y: 100, opacity: 0 }}
        whileInView={{ y: 0, opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1, ease: "easeOut" }}
      >
        FRYDAYS
      </motion.div>
    </footer>
  )
}

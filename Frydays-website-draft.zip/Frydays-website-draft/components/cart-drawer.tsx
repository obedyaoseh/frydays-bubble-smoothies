"use client"

import { useState } from "react"
import { ArrowRight, Bike, CheckCircle2, CreditCard, Landmark, MapPin, Minus, Plus, ShoppingBag, Smartphone, Sparkles, Store, Tag, Trash2, X } from "lucide-react"
import { useCart } from "@/components/cart-provider"

const deliveryZones = [
  { id: "teshie", label: "Teshie / Nungua", price: 15 },
  { id: "spintex", label: "Spintex Road", price: 15 },
  { id: "labadi", label: "Labadi & Trade Fair", price: 18 },
  { id: "osu", label: "Osu & Oxford Street", price: 20 },
  { id: "cantonments", label: "Cantonments & Labone", price: 20 },
  { id: "airport", label: "Airport Residential", price: 25 },
  { id: "east-legon", label: "East Legon", price: 25 },
  { id: "tema", label: "Sakumono / Tema West", price: 25 },
] as const

export function CartDrawer() {
  const { cart, cartOpen, closeCart, clearCart, updateQuantity, removeFromCart, total } = useCart()
  const [orderType, setOrderType] = useState<"pickup" | "delivery">("pickup")
  const [selectedZone, setSelectedZone] = useState<string>(deliveryZones[0].id)
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [address, setAddress] = useState("")
  const [paymentMethod, setPaymentMethod] = useState<"momo" | "telecel" | "bank" | "card" | "cash">("momo")
  const [paymentAccountName, setPaymentAccountName] = useState("")
  const [mobileMoneyNumber, setMobileMoneyNumber] = useState("")
  const [bankName, setBankName] = useState("GCB Bank")
  const [transferReference, setTransferReference] = useState("")
  const [promoInput, setPromoInput] = useState("")
  const [appliedPromo, setAppliedPromo] = useState("")
  const [promoError, setPromoError] = useState("")
  const [error, setError] = useState("")
  const [submitted, setSubmitted] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [orderReference, setOrderReference] = useState("")
  const [receiptSent, setReceiptSent] = useState(false)

  if (!cartOpen) return null

  const subtotal = total
  const selectedDeliveryZone = deliveryZones.find((zone) => zone.id === selectedZone) ?? deliveryZones[0]
  const deliveryFee = orderType === "delivery" ? selectedDeliveryZone.price : 0
  const discount = appliedPromo === "FRYDAYS25" ? Math.min(subtotal, 25) : appliedPromo === "WELCOME15" ? subtotal * 0.15 : 0
  const checkoutTotal = Math.max(0, subtotal - discount) + deliveryFee
  const pointsToEarn = Math.floor(checkoutTotal * 2)

  const applyPromo = (event: React.FormEvent) => {
    event.preventDefault()
    const code = promoInput.trim().toUpperCase()
    if (code === "FRYDAYS25" || code === "WELCOME15") {
      setAppliedPromo(code)
      setPromoInput("")
      setPromoError("")
    } else {
      setAppliedPromo("")
      setPromoError("Try FRYDAYS25 or WELCOME15.")
    }
  }

  const submitOrder = async (event: React.FormEvent) => {
    event.preventDefault()
    const needsMobileMoneyDetails = paymentMethod === "momo" || paymentMethod === "telecel"
    const needsBankDetails = paymentMethod === "bank"
    const missingPaymentDetails =
      (needsMobileMoneyDetails && (!paymentAccountName.trim() || !mobileMoneyNumber.trim())) ||
      (needsBankDetails && (!paymentAccountName.trim() || !transferReference.trim()))

    if (!name.trim() || !email.trim() || !phone.trim() || (orderType === "delivery" && !address.trim())) {
      setError(orderType === "delivery" ? "Add your name, email, phone, and delivery address to continue." : "Add your name, email, and phone number to continue.")
      return
    }
    if (missingPaymentDetails) {
      setError(
        needsBankDetails
          ? "Add the payer name and bank transfer reference to continue."
          : "Add the mobile-money account name and number to continue.",
      )
      return
    }
    setError("")
    setIsSubmitting(true)

    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customer: { name, email, phone },
          orderType,
          deliveryZone: orderType === "delivery" ? selectedZone : null,
          address: orderType === "delivery" ? address : "",
          paymentMethod,
          promoCode: appliedPromo || null,
          items: cart.map((line) => ({
            itemId: line.item.id,
            quantity: line.quantity,
            customization: line.customization,
          })),
        }),
      })
      const result = await response.json().catch(() => null)

      if (!response.ok || !result?.ok) {
        setError(result?.error ?? "We couldn’t send your order. Your bag is unchanged; please try again or contact Frydays.")
        return
      }

      setOrderReference(result.orderReference)
      setReceiptSent(result.receiptSent === true)
      setSubmitted(true)
      clearCart()
    } catch {
      setError("We couldn’t confirm that Frydays received your order. Your bag is unchanged; please contact Frydays before retrying to avoid a duplicate order.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="fixed inset-0 z-[60] bg-[#09403B]/70 backdrop-blur-sm">
      <button aria-label="Close order bag" onClick={closeCart} className="absolute inset-0 cursor-default" />
      <aside className="absolute right-0 top-0 flex h-full w-full max-w-lg flex-col bg-[#f8efd9] text-[#09403B] shadow-2xl">
        <div className="flex items-center justify-between bg-[#09403B] p-5 text-[#F2DBB2]">
          <div className="flex items-center gap-3">
            <ShoppingBag className="h-5 w-5" />
            <div>
              <h2 className="text-xl font-black">Your order bag</h2>
              <p className="text-xs font-medium text-[#F2DBB2]/60">{cart.reduce((sum, line) => sum + line.quantity, 0)} items · Frydays Teshie</p>
            </div>
          </div>
          <button onClick={closeCart} aria-label="Close order bag" className="rounded-full p-2 transition-colors hover:bg-[#F2DBB2]/10"><X className="h-5 w-5" /></button>
        </div>

        {submitted ? (
          <div className="flex flex-1 flex-col items-center justify-center px-8 text-center">
            <CheckCircle2 className="h-14 w-14 text-[#2d8c5a]" />
            <h3 className="mt-5 text-3xl font-black">Order request received.</h3>
            <p className="mt-3 max-w-sm text-sm font-medium leading-relaxed text-[#09403B]/60">
              {orderReference && <>Reference: <strong>{orderReference}</strong>. </>}
              {receiptSent
                ? `A confirmation was sent to ${email}. We’ll also reach out on WhatsApp or phone to confirm your order.`
                : "Frydays received your order. We couldn’t send the email receipt, but the team will reach out on WhatsApp or phone to confirm your order."}
            </p>
            <button onClick={() => { setSubmitted(false); closeCart() }} className="mt-7 rounded-full bg-[#09403B] px-6 py-3 text-sm font-black text-[#F2DBB2]">Back to Frydays</button>
          </div>
        ) : cart.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center px-8 text-center">
            <ShoppingBag className="h-14 w-14 text-[#09403B]/20" />
            <h3 className="mt-5 text-2xl font-black">Your bag is empty.</h3>
            <p className="mt-2 text-sm font-medium text-[#09403B]/55">Add a smoothie or pastry to get started.</p>
            <button onClick={closeCart} className="mt-7 inline-flex items-center gap-2 rounded-full bg-[#09403B] px-6 py-3 text-sm font-black text-[#F2DBB2]">Explore the menu <ArrowRight className="h-4 w-4" /></button>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto p-5">
              <div className="grid grid-cols-2 gap-1 rounded-2xl border border-[#09403B]/10 bg-[#09403B]/[0.05] p-1">
                <button onClick={() => setOrderType("pickup")} className={`flex min-h-11 items-center justify-center gap-2 rounded-xl text-xs font-black uppercase tracking-wider ${orderType === "pickup" ? "bg-[#09403B] text-[#F2DBB2]" : "text-[#09403B]/55"}`}><Store className="h-4 w-4" /> Pickup</button>
                <button onClick={() => setOrderType("delivery")} className={`flex min-h-11 items-center justify-center gap-2 rounded-xl text-xs font-black uppercase tracking-wider ${orderType === "delivery" ? "bg-[#09403B] text-[#F2DBB2]" : "text-[#09403B]/55"}`}><Bike className="h-4 w-4" /> Delivery</button>
              </div>
              <div className="mt-3 rounded-2xl bg-[#09403B]/[0.05] p-3 text-xs font-medium text-[#09403B]/70">
                <MapPin className="mr-2 inline h-4 w-4 text-[#09403B]" />
                {orderType === "pickup" ? "Ready in about 12 minutes at Frydays Teshie Bar. Pickup is free." : "Choose your Accra delivery area below. The fee is added to your total."}
              </div>
              {orderType === "delivery" && (
                <div className="mt-2 space-y-2">
                  <label htmlFor="delivery-zone" className="sr-only">Choose delivery area</label>
                  <select id="delivery-zone" value={selectedZone} onChange={(event) => setSelectedZone(event.target.value)} className="min-h-12 w-full rounded-2xl border border-[#09403B]/10 bg-white/60 px-4 text-sm font-bold text-[#09403B] outline-none focus:border-[#09403B]">
                    {deliveryZones.map((zone) => <option key={zone.id} value={zone.id}>{zone.label} (GH₵ {zone.price.toFixed(2)})</option>)}
                  </select>
                  <input required value={address} onChange={(event) => setAddress(event.target.value)} placeholder="Street name, house / landmark number" className="min-h-12 w-full rounded-2xl border border-[#09403B]/10 bg-white/55 px-4 text-sm font-medium outline-none placeholder:text-[#09403B]/35 focus:border-[#09403B]" />
                </div>
              )}

              <div className="mt-7 space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-bold uppercase tracking-[0.22em] text-[#09403B]/55">Your items</p>
                  <button onClick={clearCart} className="text-xs font-bold text-[#09403B]/45 hover:text-red-700">Clear bag</button>
                </div>
                {cart.map((line) => (
                  <div key={line.lineId} className="rounded-2xl border border-[#09403B]/10 bg-white/55 p-3">
                    <div className="flex gap-3">
                      {"image" in line.item ? (
                        <img src={line.item.image} alt={line.item.name} className="h-16 w-16 shrink-0 rounded-xl object-cover" />
                      ) : (
                        <div aria-hidden="true" className="flex h-16 w-16 shrink-0 items-center justify-center rounded-xl bg-[#09403B]/[0.06] text-[#09403B]/55">
                          <ShoppingBag className="h-6 w-6" />
                        </div>
                      )}
                      <div className="min-w-0 flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <h3 className="font-black">{line.item.name}</h3>
                            {line.customization ? (
                              <>
                                <p className="mt-1 text-[11px] font-medium leading-relaxed text-[#09403B]/55">{line.customization.size === "Regular" ? "Regular · 500 ml" : line.customization.size} · {line.customization.sweetness} sugar · {line.customization.ice} ice</p>
                                {line.customization.toppings.length > 0 && <p className="text-[11px] font-bold text-[#09403B]">+ {line.customization.toppings.join(", ")}</p>}
                              </>
                            ) : (
                              <p className="mt-1 text-[11px] font-medium text-[#09403B]/55">Pastry</p>
                            )}
                          </div>
                          <button onClick={() => removeFromCart(line.lineId)} aria-label={`Remove ${line.item.name}`} className="text-[#09403B]/35 hover:text-red-700"><Trash2 className="h-4 w-4" /></button>
                        </div>
                        <div className="mt-3 flex items-center justify-between">
                          <div className="flex items-center gap-2 rounded-full border border-[#09403B]/10 bg-[#f8efd9] p-1">
                            <button onClick={() => updateQuantity(line.lineId, line.quantity - 1)} aria-label="Decrease quantity" className="flex h-6 w-6 items-center justify-center rounded-full bg-[#09403B] text-[#F2DBB2]"><Minus className="h-3 w-3" /></button>
                            <span className="w-4 text-center text-xs font-black">{line.quantity}</span>
                            <button onClick={() => updateQuantity(line.lineId, line.quantity + 1)} aria-label="Increase quantity" className="flex h-6 w-6 items-center justify-center rounded-full bg-[#09403B] text-[#F2DBB2]"><Plus className="h-3 w-3" /></button>
                          </div>
                          <span className="font-black">GH₵ {(line.unitPrice * line.quantity).toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <form id="cart-order-form" onSubmit={submitOrder} className="mt-7 space-y-3">
                <p className="text-xs font-bold uppercase tracking-[0.22em] text-[#09403B]/55">Send your request</p>
                <div className="grid gap-2 sm:grid-cols-2">
                  <input required value={name} onChange={(event) => setName(event.target.value)} placeholder="Your name" className="min-h-12 rounded-2xl border border-[#09403B]/10 bg-white/55 px-4 text-sm font-medium outline-none placeholder:text-[#09403B]/35 focus:border-[#09403B]" />
                  <input required type="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="Email for your receipt" className="min-h-12 rounded-2xl border border-[#09403B]/10 bg-white/55 px-4 text-sm font-medium outline-none placeholder:text-[#09403B]/35 focus:border-[#09403B]" />
                  <input required type="tel" value={phone} onChange={(event) => setPhone(event.target.value)} placeholder="Phone / WhatsApp" className="min-h-12 rounded-2xl border border-[#09403B]/10 bg-white/55 px-4 text-sm font-medium outline-none placeholder:text-[#09403B]/35 focus:border-[#09403B]" />
                </div>
                {error && <p className="text-xs font-bold text-red-700">{error}</p>}
              </form>

              <section className="mt-7" aria-labelledby="payment-heading">
                <p id="payment-heading" className="text-xs font-bold uppercase tracking-[0.22em] text-[#09403B]/55">Payment option</p>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  {[
                    { id: "momo", label: "MTN MoMo", icon: Smartphone },
                    { id: "telecel", label: "Telecel Cash", icon: Smartphone },
                    { id: "bank", label: "Bank Transfer", icon: Landmark },
                    { id: "card", label: "Debit / Visa", icon: CreditCard },
                    { id: "cash", label: "Pay on Pickup", icon: Store },
                  ].map(({ id, label, icon: Icon }) => (
                    <button key={id} type="button" onClick={() => setPaymentMethod(id as typeof paymentMethod)} className={`flex min-h-12 items-center gap-2 rounded-2xl border px-3 text-sm font-bold transition-colors focus:outline-none focus:ring-2 focus:ring-[#09403B] ${paymentMethod === id ? "border-[#09403B] bg-[#09403B] text-[#F2DBB2]" : "border-[#09403B]/10 bg-white/55 text-[#09403B] hover:border-[#09403B]/35"}`}>
                      <Icon className="h-4 w-4" /> {label}
                    </button>
                  ))}
                </div>
                {(paymentMethod === "momo" || paymentMethod === "telecel") && (
                  <div className="mt-3 space-y-2 rounded-2xl border border-[#09403B]/10 bg-white/45 p-3">
                    <p className="text-xs font-bold text-[#09403B]/65">
                      {paymentMethod === "momo" ? "MTN MoMo" : "Telecel Cash"} details
                    </p>
                    <div className="grid gap-2 sm:grid-cols-2">
                      <input
                        required
                        value={paymentAccountName}
                        onChange={(event) => setPaymentAccountName(event.target.value)}
                        placeholder="Account name"
                        aria-label={`${paymentMethod === "momo" ? "MTN MoMo" : "Telecel Cash"} account name`}
                        className="min-h-11 rounded-xl border border-[#09403B]/10 bg-white/65 px-3 text-sm font-medium outline-none placeholder:text-[#09403B]/35 focus:border-[#09403B]"
                      />
                      <input
                        required
                        type="tel"
                        value={mobileMoneyNumber}
                        onChange={(event) => setMobileMoneyNumber(event.target.value)}
                        placeholder="Mobile money number"
                        aria-label={`${paymentMethod === "momo" ? "MTN MoMo" : "Telecel Cash"} number`}
                        className="min-h-11 rounded-xl border border-[#09403B]/10 bg-white/65 px-3 text-sm font-medium outline-none placeholder:text-[#09403B]/35 focus:border-[#09403B]"
                      />
                    </div>
                    <p className="text-[11px] font-medium leading-relaxed text-[#09403B]/45">We&apos;ll use these details to confirm the payment request with you. No PIN is required.</p>
                  </div>
                )}
                {paymentMethod === "bank" && (
                  <div className="mt-3 space-y-2 rounded-2xl border border-[#09403B]/10 bg-white/45 p-3">
                    <p className="text-xs font-bold text-[#09403B]/65">Bank transfer details</p>
                    <div className="grid gap-2 sm:grid-cols-2">
                      <select value={bankName} onChange={(event) => setBankName(event.target.value)} aria-label="Bank name" className="min-h-11 rounded-xl border border-[#09403B]/10 bg-white/65 px-3 text-sm font-medium outline-none focus:border-[#09403B]">
                        <option>GCB Bank</option>
                        <option>Ecobank Ghana</option>
                        <option>Absa Bank Ghana</option>
                        <option>Fidelity Bank Ghana</option>
                        <option>CalBank</option>
                      </select>
                      <input
                        required
                        value={paymentAccountName}
                        onChange={(event) => setPaymentAccountName(event.target.value)}
                        placeholder="Payer name"
                        aria-label="Bank transfer payer name"
                        className="min-h-11 rounded-xl border border-[#09403B]/10 bg-white/65 px-3 text-sm font-medium outline-none placeholder:text-[#09403B]/35 focus:border-[#09403B]"
                      />
                    </div>
                    <input
                      required
                      value={transferReference}
                      onChange={(event) => setTransferReference(event.target.value)}
                      placeholder="Transfer reference"
                      aria-label="Bank transfer reference"
                      className="min-h-11 w-full rounded-xl border border-[#09403B]/10 bg-white/65 px-3 text-sm font-medium outline-none placeholder:text-[#09403B]/35 focus:border-[#09403B]"
                    />
                    <p className="text-[11px] font-medium leading-relaxed text-[#09403B]/45">Use the reference from your bank transfer receipt. Do not enter your PIN or online-banking password.</p>
                  </div>
                )}
                {paymentMethod === "card" && (
                  <div className="mt-3 rounded-2xl border border-[#09403B]/10 bg-white/45 p-3 text-xs font-medium leading-relaxed text-[#09403B]/60">
                    Debit and Visa payments are confirmed securely with the Frydays team. We do not collect card numbers or CVV details in this order-request form.
                  </div>
                )}
                {paymentMethod === "cash" && (
                  <div className="mt-3 rounded-2xl border border-[#09403B]/10 bg-white/45 p-3 text-xs font-medium leading-relaxed text-[#09403B]/60">
                    Pay when you collect your order at the Frydays Teshie Bar.
                  </div>
                )}
              </section>

              <section className="mt-7" aria-labelledby="promo-heading">
                <p id="promo-heading" className="text-xs font-bold uppercase tracking-[0.22em] text-[#09403B]/55">Promo code</p>
                {appliedPromo ? (
                  <div className="mt-3 flex items-center justify-between rounded-2xl border border-[#09403B]/15 bg-[#09403B]/[0.05] px-4 py-3 text-sm font-bold">
                    <span className="flex items-center gap-2"><Tag className="h-4 w-4" /> {appliedPromo} applied</span>
                    <button type="button" onClick={() => setAppliedPromo("")} className="text-xs text-[#09403B]/55 hover:text-red-700">Remove</button>
                  </div>
                ) : (
                  <form onSubmit={applyPromo} className="mt-3 flex gap-2">
                    <input value={promoInput} onChange={(event) => setPromoInput(event.target.value)} placeholder="Enter FRYDAYS25, WELCOME15" className="min-h-12 min-w-0 flex-1 rounded-2xl border border-[#09403B]/10 bg-white/55 px-4 text-sm font-medium uppercase outline-none placeholder:text-[#09403B]/35 focus:border-[#09403B]" />
                    <button type="submit" className="rounded-2xl bg-[#09403B] px-4 text-xs font-black uppercase tracking-wider text-[#F2DBB2]">Apply</button>
                  </form>
                )}
                {promoError && <p className="mt-2 text-xs font-bold text-red-700">{promoError}</p>}
              </section>
            </div>
            <div className="border-t border-[#09403B]/10 bg-[#F2DBB2] p-5">
              <div className="space-y-2 text-sm font-medium text-[#09403B]/65">
                <div className="flex items-center justify-between"><span>Subtotal</span><span>GH₵ {subtotal.toFixed(2)}</span></div>
                {discount > 0 && <div className="flex items-center justify-between font-bold text-[#09403B]"><span>Promo savings</span><span>- GH₵ {discount.toFixed(2)}</span></div>}
                {orderType === "delivery" && <div className="flex items-center justify-between"><span>Accra courier · {selectedDeliveryZone.label}</span><span>GH₵ {deliveryFee.toFixed(2)}</span></div>}
                <div className="flex items-center justify-between border-t border-[#09403B]/15 pt-3 text-lg font-black text-[#09403B]"><span>Total amount</span><span>GH₵ {checkoutTotal.toFixed(2)}</span></div>
              </div>
              <div className="my-4 flex items-center justify-center gap-2 rounded-2xl border border-[#09403B]/10 bg-[#f8efd9] px-3 py-3 text-center text-xs font-bold text-[#09403B]"><Sparkles className="h-4 w-4" /> You will earn +{pointsToEarn} SipRewards points</div>
              <button form="cart-order-form" type="submit" disabled={isSubmitting} className="flex min-h-14 w-full items-center justify-between rounded-full bg-[#09403B] px-5 text-sm font-black text-[#F2DBB2] transition-transform hover:-translate-y-0.5 disabled:cursor-wait disabled:opacity-60"><span>{isSubmitting ? "Sending order…" : "Place order & send to barista"}</span><span>GH₵ {checkoutTotal.toFixed(2)} <ArrowRight className="ml-1 inline h-4 w-4" /></span></button>
              <p className="mt-3 text-center text-[11px] font-medium text-[#09403B]/45">Payment is confirmed with our team by phone or WhatsApp.</p>
            </div>
          </>
        )}
      </aside>
    </div>
  )
}
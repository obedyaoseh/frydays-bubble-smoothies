"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import Image from "next/image"
import { useLenis } from "lenis/react"
import { Menu, X, ShoppingBag } from "lucide-react"
import { useCart } from "@/components/cart-provider"
import { CartDrawer } from "@/components/cart-drawer"

const mobileMenuVariants = {
  hidden: { opacity: 0, height: 0 },
  visible: {
    opacity: 1,
    height: "auto",
    transition: { duration: 0.3, ease: [0.25, 0.4, 0.25, 1] },
  },
  exit: {
    opacity: 0,
    height: 0,
    transition: { duration: 0.2, ease: [0.25, 0.4, 0.25, 1] },
  },
}

export function Navigation() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const lenis = useLenis()
  const { itemCount, openCart } = useCart()

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToSection = (id: string) => {
    const element = document.querySelector(id)
    if (element && lenis) lenis.scrollTo(element, { offset: -100 })
    setMobileMenuOpen(false)
  }

  const navLinks = [
    { label: "Home", href: "#hero", isAnchor: true },
    { label: "About", href: "/about", isAnchor: false },
    { label: "Contact", href: "/contact", isAnchor: false },
  ]

  return (
    <>
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ type: "spring", stiffness: 100, damping: 20 }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled
            ? "bg-[#09403B]/95 backdrop-blur-md border-b border-[#F2DBB2]/10"
            : "bg-transparent"
        }`}
      >
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2">
          <motion.div
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 400, damping: 17 }}
            className="relative w-32 h-10"
          >
            <Image
              src={scrolled ? "/images/frydays-cream.png" : "/images/frydays-black.png"}
              alt="Frydays Bubble & Smoothies Bar"
              fill
              className="object-contain"
              priority
            />
          </motion.div>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((item, i) =>
            item.isAnchor ? (
              <motion.button
                key={item.label}
                onClick={() => scrollToSection(item.href)}
                className={`text-sm font-semibold tracking-wide transition-colors relative ${
                  scrolled
                    ? "text-[#F2DBB2]/80 hover:text-[#F2DBB2]"
                    : "text-[#09403B]/80 hover:text-[#09403B]"
                }`}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1, duration: 0.4 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {item.label}
                <motion.span
                  className={`absolute -bottom-1 left-0 w-full h-0.5 origin-left ${
                    scrolled ? "bg-[#F2DBB2]" : "bg-[#09403B]"
                  }`}
                  initial={{ scaleX: 0 }}
                  whileHover={{ scaleX: 1 }}
                  transition={{ duration: 0.2 }}
                />
              </motion.button>
            ) : (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1, duration: 0.4 }}
              >
                <Link
                  href={item.href}
                  className={`text-sm font-semibold tracking-wide transition-colors relative group ${
                    scrolled
                      ? "text-[#F2DBB2]/80 hover:text-[#F2DBB2]"
                      : "text-[#09403B]/80 hover:text-[#09403B]"
                  }`}
                >
                  {item.label}
                  <span
                    className={`absolute -bottom-1 left-0 w-full h-0.5 origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-200 ${
                      scrolled ? "bg-[#F2DBB2]" : "bg-[#09403B]"
                    }`}
                  />
                </Link>
              </motion.div>
            )
          )}

          <motion.a
            href="/order"
            className="px-5 py-2 rounded-full text-sm font-bold tracking-wide bg-[#09403B] text-[#F2DBB2] hover:bg-[#0f5c54] transition-colors"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Order Now
          </motion.a>
          <button onClick={openCart} aria-label={`Open order basket${itemCount ? `, ${itemCount} items` : ""}`} className={`relative ${scrolled ? "text-[#F2DBB2]" : "text-[#09403B]"}`}>
            <ShoppingBag className="w-5 h-5" />
            {itemCount > 0 && <span className="absolute -right-2 -top-2 min-w-4 h-4 px-1 rounded-full bg-[#F2DBB2] text-[#09403B] text-[10px] font-black flex items-center justify-center">{itemCount}</span>}
          </button>
        </div>

        {/* Mobile menu button */}
        <motion.button
          className={`md:hidden ${scrolled ? "text-[#F2DBB2]" : "text-[#09403B]"}`}
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          whileTap={{ scale: 0.9 }}
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </motion.button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            variants={mobileMenuVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            className="md:hidden bg-[#09403B] border-t border-[#F2DBB2]/10 overflow-hidden"
          >
            <div className="px-6 py-4 flex flex-col gap-4">
              {navLinks.map((item) =>
                item.isAnchor ? (
                  <button
                    key={item.label}
                    onClick={() => scrollToSection(item.href)}
                    className="text-[#F2DBB2]/80 hover:text-[#F2DBB2] text-sm font-semibold text-left transition-colors"
                  >
                    {item.label}
                  </button>
                ) : (
                  <Link
                    key={item.label}
                    href={item.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className="text-[#F2DBB2]/80 hover:text-[#F2DBB2] text-sm font-semibold transition-colors"
                  >
                    {item.label}
                  </Link>
                )
              )}
              <Link
                href="/order"
                onClick={() => setMobileMenuOpen(false)}
                className="px-5 py-2 rounded-full text-sm font-bold bg-[#F2DBB2] text-[#09403B] text-center"
              >
                Order Now
              </Link>
              <button
                onClick={() => { setMobileMenuOpen(false); openCart() }}
                className="flex items-center justify-center gap-2 rounded-full border border-[#F2DBB2]/30 px-5 py-2 text-sm font-bold text-[#F2DBB2]"
              >
                <ShoppingBag className="h-4 w-4" />
                Order Bag{itemCount > 0 ? ` (${itemCount})` : ""}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      </motion.nav>
      <CartDrawer />
    </>
  )
}

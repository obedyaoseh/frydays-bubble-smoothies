"use client"

import { motion, useInView } from "framer-motion"
import { useRef } from "react"
import { PartyPopper, Building2, Gift, Users } from "lucide-react"

const offerings = [
  {
    icon: PartyPopper,
    title: "Events & Catering",
    description: "Let Frydays set up a live smoothie & bubble tea bar at your next event.",
    cta: "Book Us",
  },
  {
    icon: Building2,
    title: "Corporate Wellness",
    description: "Fresh daily smoothie deliveries to power up your office or workplace.",
    cta: "Get a Quote",
  },
  {
    icon: Gift,
    title: "Gift Packages",
    description: "Send a bundle of Frydays favourites to someone who deserves a treat.",
    cta: "Order Gifts",
  },
  {
    icon: Users,
    title: "Group Orders",
    description: "Ordering for a squad? We love big orders — get in touch for deals.",
    cta: "Contact Us",
  },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08, delayChildren: 0.15 },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 30, scale: 0.95 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { type: "spring", stiffness: 100, damping: 20 },
  },
}

export function ActivationsSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section id="offerings" className="relative py-16 bg-[#F2DBB2] overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: [0.25, 0.4, 0.25, 1] }}
          className="text-center mb-10"
        >
          <motion.span
            className="text-[#09403B]/60 text-xs font-semibold tracking-widest uppercase inline-block"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            What We Offer
          </motion.span>
          <h2 className="text-3xl md:text-5xl font-black text-[#09403B] tracking-tight mt-2 overflow-hidden">
            <motion.span
              className="inline-block"
              initial={{ y: 100 }}
              whileInView={{ y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1], delay: 0.2 }}
            >
              Beyond the{" "}
            </motion.span>
            <motion.span
              className="text-[#09403B] underline decoration-[#F2DBB2]/0 inline-block"
              initial={{ y: 100 }}
              whileInView={{ y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1], delay: 0.3 }}
            >
              Bar
            </motion.span>
          </h2>
          <motion.p
            className="text-sm text-[#09403B]/60 mt-2 max-w-xl mx-auto font-medium"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
          >
            From walk-in sips to full event packages — Frydays brings the freshness to you.
          </motion.p>
        </motion.div>

        <motion.div
          ref={ref}
          className="grid md:grid-cols-2 lg:grid-cols-4 gap-4"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {offerings.map((item) => (
            <motion.div
              key={item.title}
              variants={itemVariants}
              whileHover={{
                y: -8,
                scale: 1.02,
                transition: { type: "spring", stiffness: 400, damping: 17 },
              }}
              className="group bg-[#09403B] rounded-2xl p-6 cursor-pointer relative overflow-hidden"
            >
              <motion.div
                className="absolute inset-0 bg-[#F2DBB2]/0 group-hover:bg-[#F2DBB2]"
                transition={{ duration: 0.4 }}
              />

              <div className="relative z-10">
                <motion.div
                  className="w-11 h-11 rounded-xl bg-[#F2DBB2]/20 flex items-center justify-center mb-4 group-hover:bg-[#09403B] transition-colors duration-300"
                  whileHover={{ rotate: 10, scale: 1.1 }}
                  transition={{ type: "spring", stiffness: 400, damping: 17 }}
                >
                  <item.icon className="w-5 h-5 text-[#F2DBB2] group-hover:text-[#F2DBB2] transition-colors duration-300" />
                </motion.div>

                <h3 className="text-lg font-black text-[#F2DBB2] group-hover:text-[#09403B] tracking-tight mb-2 transition-colors duration-300">
                  {item.title}
                </h3>
                <p className="text-[#F2DBB2]/60 group-hover:text-[#09403B]/60 text-xs leading-relaxed mb-4 transition-colors duration-300 font-medium">
                  {item.description}
                </p>

                <motion.a
                  href="/contact"
                  className="flex items-center gap-2 text-[#F2DBB2] group-hover:text-[#09403B] font-bold text-xs tracking-wide transition-colors duration-300"
                  whileHover={{ x: 4 }}
                  transition={{ type: "spring", stiffness: 400, damping: 17 }}
                >
                  {item.cta}
                  <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </motion.a>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

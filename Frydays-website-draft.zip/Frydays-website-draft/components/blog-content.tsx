"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import { ArrowRight, BookOpen } from "lucide-react"

const journalSections = [
  {
    title: "Frydays Stories",
    description: "The people and moments that make our journey.",
  },
  {
    title: "Fresh Thoughts",
    description: "Simple ideas on food, wellness, business, and everyday living.",
  },
  {
    title: "From Our Community",
    description: "Local stories, events, collaborations, and the people we meet along the way.",
  },
  {
    title: "Behind the Cup",
    description: "A closer look at our ingredients, flavours, recipes, and the craft behind every drink.",
  },
  {
    title: "Frydays Finds",
    description: "Things we love, places we discover, and good things worth sharing.",
  },
]

export function BlogContent() {
  return (
    <>
      <section className="relative overflow-hidden bg-[#09403B] pb-20 pt-36 text-[#F2DBB2]">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "radial-gradient(circle at 70% 35%, #F2DBB2 0%, transparent 58%)" }} />
        <div className="relative z-10 mx-auto max-w-5xl px-6">
          <motion.span className="text-xs font-semibold uppercase tracking-[0.3em] text-[#F2DBB2]/60" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            Frydays Journal
          </motion.span>
          <motion.h1 className="mt-3 max-w-3xl text-5xl font-black leading-[0.95] tracking-tight md:text-7xl" initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
            Frydays stories from
            <br />
            <span className="text-[#F2DBB2]/60">Teshie, Accra.</span>
          </motion.h1>
          <motion.p className="mt-6 max-w-xl text-lg font-medium leading-relaxed text-[#F2DBB2]/70" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
            The Frydays Journal is where we share the people, ideas, flavours, and little moments behind the brand.
          </motion.p>
        </div>
      </section>

      <section id="journal" className="bg-[#F2DBB2] py-20 md:py-28">
        <div className="mx-auto max-w-5xl px-6">
          <div className="mb-10 flex items-end justify-between gap-6">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.28em] text-[#09403B]/55">The Journal</p>
              <h2 className="mt-3 text-4xl font-black tracking-tight text-[#09403B] md:text-5xl">What&apos;s on the menu?</h2>
            </div>
            <BookOpen className="hidden h-8 w-8 text-[#09403B]/35 sm:block" />
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {journalSections.map((section, index) => (
              <motion.article
                key={section.title}
                className={`rounded-2xl p-6 ${index === 0 ? "bg-[#09403B] text-[#F2DBB2] md:col-span-2" : "bg-[#09403B]/[0.06] text-[#09403B]"}`}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.08 }}
                whileHover={{ y: -4 }}
              >
                <p className={`text-xs font-bold uppercase tracking-[0.2em] ${index === 0 ? "text-[#F2DBB2]/55" : "text-[#09403B]/45"}`}>01 · Frydays Journal</p>
                <h3 className="mt-5 text-2xl font-black">{section.title}</h3>
                <p className={`mt-2 max-w-xl text-sm font-medium leading-relaxed ${index === 0 ? "text-[#F2DBB2]/65" : "text-[#09403B]/60"}`}>{section.description}</p>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-[#f8efd9] py-20 text-center">
        <div className="mx-auto max-w-2xl px-6">
          <h2 className="text-4xl font-black tracking-tight text-[#09403B] md:text-5xl">Good stories are better shared.</h2>
          <p className="mt-4 text-[#09403B]/60">Follow the journey and find the good things we&apos;re sharing.</p>
          <Link href="/contact" className="mt-8 inline-flex items-center gap-2 rounded-full bg-[#09403B] px-6 py-4 text-sm font-black text-[#F2DBB2]">
            Read the Journal <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </>
  )
}
"use client"

import { createContext, useContext, useEffect, useMemo, useState } from "react"
import { menuItems, type MenuItem } from "@/lib/menu-data"
import { pastryItems, type PastryItem } from "@/lib/pastry-data"

export type CartItem = MenuItem | PastryItem

export type CustomizationOptions = {
  size: "Regular" | "Large"
  sweetness: "No sugar" | "Light" | "Half" | "Standard"
  ice: "No ice" | "Light" | "Regular" | "Extra"
  milk: "Oat milk" | "Whole milk" | "Coconut milk" | "No milk"
  toppings: string[]
  notes?: string
}

export type CartLine = {
  lineId: string
  item: CartItem
  quantity: number
  customization: CustomizationOptions | null
  unitPrice: number
}

export const defaultCustomization: CustomizationOptions = {
  size: "Regular",
  sweetness: "Standard",
  ice: "Regular",
  milk: "Oat milk",
  toppings: [],
}

type CartContextValue = {
  cart: CartLine[]
  addToCart: (item: CartItem, customization?: CustomizationOptions, quantity?: number) => void
  updateQuantity: (lineId: string, quantity: number) => void
  removeFromCart: (lineId: string) => void
  clearCart: () => void
  cartOpen: boolean
  openCart: () => void
  closeCart: () => void
  itemCount: number
  total: number
}

const CartContext = createContext<CartContextValue | null>(null)

function isPastryItem(item: CartItem): item is PastryItem {
  return "type" in item && item.type === "pastry"
}

function getCurrentItem(item: CartItem): CartItem {
  if (isPastryItem(item)) return pastryItems.find((pastry) => pastry.id === item.id) ?? item
  return menuItems.find((drink) => drink.id === item.id) ?? item
}

function calculateUnitPrice(item: CartItem, customization: CustomizationOptions | null) {
  const toppingSurcharge = (customization?.toppings.length ?? 0) * 3
  const sizeSurcharge = customization?.size === "Large" ? 10 : 0
  return item.price + toppingSurcharge + sizeSurcharge
}

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [cart, setCart] = useState<CartLine[]>([])
  const [cartOpen, setCartOpen] = useState(false)

  useEffect(() => {
    const saved = window.localStorage.getItem("frydays-cart")
    if (saved) {
      try {
        const parsed = JSON.parse(saved)
        setCart(
          Array.isArray(parsed)
            ? parsed.map((line) => {
                if (line.lineId && line.item) {
                  const item = getCurrentItem(line.item as CartItem)
                  const customization = line.customization ?? (isPastryItem(item) ? null : defaultCustomization)
                  return {
                    ...line,
                    item,
                    customization,
                    unitPrice: calculateUnitPrice(item, customization),
                  } as CartLine
                }
                const item = getCurrentItem(line as CartItem)
                const customization = isPastryItem(item) ? null : defaultCustomization
                return {
                  lineId: `legacy-${item.id}`,
                  item,
                  quantity: line.quantity || 1,
                  customization,
                  unitPrice: calculateUnitPrice(item, customization),
                }
              })
            : [],
        )
      } catch {
        window.localStorage.removeItem("frydays-cart")
      }
    }
  }, [])

  useEffect(() => {
    window.localStorage.setItem("frydays-cart", JSON.stringify(cart))
  }, [cart])

  const value = useMemo(
    () => ({
      cart,
      addToCart: (item: CartItem, customization: CustomizationOptions | undefined, quantity = 1) =>
        setCart((current) => {
          const currentItem = getCurrentItem(item)
          const selectedCustomization = isPastryItem(currentItem) ? null : customization ?? defaultCustomization
          const existing = current.find(
            (line) => line.item.id === currentItem.id && JSON.stringify(line.customization) === JSON.stringify(selectedCustomization),
          )
          if (existing) {
            return current.map((line) =>
              line.lineId === existing.lineId ? { ...line, quantity: line.quantity + quantity } : line,
            )
          }
          return [
            ...current,
            {
              lineId: `${currentItem.id}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
              item: currentItem,
              quantity,
              customization: selectedCustomization,
              unitPrice: calculateUnitPrice(currentItem, selectedCustomization),
            },
          ]
        }),
      updateQuantity: (lineId: string, quantity: number) =>
        setCart((current) =>
          quantity <= 0
            ? current.filter((line) => line.lineId !== lineId)
            : current.map((line) => (line.lineId === lineId ? { ...line, quantity } : line)),
        ),
      removeFromCart: (lineId: string) => setCart((current) => current.filter((line) => line.lineId !== lineId)),
      clearCart: () => setCart([]),
      cartOpen,
      openCart: () => setCartOpen(true),
      closeCart: () => setCartOpen(false),
      itemCount: cart.reduce((sum, line) => sum + line.quantity, 0),
      total: cart.reduce((sum, line) => sum + line.unitPrice * line.quantity, 0),
    }),
    [cart, cartOpen],
  )

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}

export function useCart() {
  const context = useContext(CartContext)
  if (!context) throw new Error("useCart must be used within CartProvider")
  return context
}
"use client"

import { useEffect, useState } from "react"
import { Check, Leaf, Minus, Plus, X } from "lucide-react"
import type { MenuItem } from "@/lib/menu-data"
import { type CustomizationOptions, defaultCustomization } from "@/components/cart-provider"

const toppingOptions = [
  { name: "Brown sugar pearls", price: 3 },
  { name: "Coconut jelly", price: 3 },
  { name: "Whipped cream", price: 3 },
  { name: "Chia & granola", price: 3 },
]

const sweetnessOptions: CustomizationOptions["sweetness"][] = ["No sugar", "Light", "Half", "Standard"]
const iceOptions: CustomizationOptions["ice"][] = ["No ice", "Light", "Regular", "Extra"]
const milkOptions: CustomizationOptions["milk"][] = ["Oat milk", "Whole milk", "Coconut milk", "No milk"]

export function ProductCustomizationModal({
  item,
  onClose,
  onAddToCart,
}: {
  item: MenuItem | null
  onClose: () => void
  onAddToCart: (item: MenuItem, customization: CustomizationOptions, quantity: number) => void
}) {
  const [customization, setCustomization] = useState<CustomizationOptions>(defaultCustomization)
  const [quantity, setQuantity] = useState(1)

  useEffect(() => {
    if (item) {
      setCustomization(defaultCustomization)
      setQuantity(1)
    }
  }, [item])

  if (!item) return null

  const toppingTotal = customization.toppings.length * 3
  const sizeTotal = customization.size === "Large" ? 10 : 0
  const total = (item.price + toppingTotal + sizeTotal) * quantity

  const toggleTopping = (name: string) => {
    setCustomization((current) => ({
      ...current,
      toppings: current.toppings.includes(name)
        ? current.toppings.filter((topping) => topping !== name)
        : [...current.toppings, name],
    }))
  }

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center overflow-y-auto bg-[#09403B]/75 p-4 backdrop-blur-sm">
      <div role="dialog" aria-modal="true" aria-labelledby="customize-title" className="my-4 flex max-h-[92vh] w-full max-w-2xl flex-col overflow-hidden rounded-3xl bg-[#f8efd9] shadow-2xl">
        <div className="relative h-48 shrink-0 overflow-hidden bg-[#09403B] sm:h-56">
          <img src={item.image} alt={item.name} className="h-full w-full object-cover opacity-90" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#09403B] via-[#09403B]/20 to-transparent" />
          <button onClick={onClose} aria-label="Close customization" className="absolute right-4 top-4 rounded-full bg-[#09403B]/70 p-2 text-[#F2DBB2] transition-colors hover:bg-[#09403B] focus:outline-none focus:ring-2 focus:ring-[#F2DBB2]">
            <X className="h-5 w-5" />
          </button>
          <div className="absolute bottom-5 left-5 right-5 text-[#F2DBB2]">
            <p className="text-xs font-bold uppercase tracking-[0.22em] text-[#F2DBB2]/65">{item.tagline}</p>
            <h2 id="customize-title" className="mt-1 text-3xl font-black">{item.name}</h2>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-5 sm:p-7">
          <p className="text-sm font-medium leading-relaxed text-[#09403B]/65">{item.description}</p>
          <div className="mt-5 flex items-center gap-2 rounded-2xl border border-[#09403B]/10 bg-[#09403B]/[0.05] p-3 text-xs font-semibold text-[#09403B]">
            <Leaf className="h-4 w-4 shrink-0" />
            Freshly prepared at the Frydays Teshie bar.
          </div>

          <div className="mt-7 space-y-7">
            <OptionGroup label="Choose your size">
              <div className="grid grid-cols-2 gap-2">
                {(["Regular", "Large"] as const).map((size) => (
                  <ChoiceButton key={size} selected={customization.size === size} onClick={() => setCustomization((current) => ({ ...current, size }))}>
                    <span>{size}</span>
                    <span className="text-xs opacity-65">{size === "Large" ? "+ GH₵ 10" : "500 ml"}</span>
                  </ChoiceButton>
                ))}
              </div>
            </OptionGroup>

            <OptionGroup label="Sweetness">
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                {sweetnessOptions.map((sweetness) => (
                  <ChoiceButton key={sweetness} selected={customization.sweetness === sweetness} onClick={() => setCustomization((current) => ({ ...current, sweetness }))}>
                    {sweetness}
                  </ChoiceButton>
                ))}
              </div>
            </OptionGroup>

            <OptionGroup label="Ice level">
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                {iceOptions.map((ice) => (
                  <ChoiceButton key={ice} selected={customization.ice === ice} onClick={() => setCustomization((current) => ({ ...current, ice }))}>
                    {ice}
                  </ChoiceButton>
                ))}
              </div>
            </OptionGroup>

            <OptionGroup label="Milk base">
              <div className="grid grid-cols-2 gap-2">
                {milkOptions.map((milk) => (
                  <ChoiceButton key={milk} selected={customization.milk === milk} onClick={() => setCustomization((current) => ({ ...current, milk }))}>
                    {milk}
                  </ChoiceButton>
                ))}
              </div>
            </OptionGroup>

            <OptionGroup label="Add a little extra">
              <div className="grid gap-2 sm:grid-cols-2">
                {toppingOptions.map((topping) => {
                  const selected = customization.toppings.includes(topping.name)
                  return (
                    <button key={topping.name} type="button" onClick={() => toggleTopping(topping.name)} className={`flex items-center justify-between rounded-2xl border p-3 text-left text-sm font-bold transition-colors focus:outline-none focus:ring-2 focus:ring-[#09403B] ${selected ? "border-[#09403B] bg-[#09403B] text-[#F2DBB2]" : "border-[#09403B]/10 bg-white/55 text-[#09403B] hover:border-[#09403B]/35"}`}>
                      <span className="flex items-center gap-2"><span className={`flex h-5 w-5 items-center justify-center rounded-md border ${selected ? "border-[#F2DBB2] bg-[#F2DBB2] text-[#09403B]" : "border-[#09403B]/20"}`}>{selected && <Check className="h-3 w-3" />}</span>{topping.name}</span>
                      <span className="text-xs opacity-70">+ GH₵ {topping.price}</span>
                    </button>
                  )
                })}
              </div>
            </OptionGroup>

            <OptionGroup label="Special note">
              <textarea value={customization.notes || ""} onChange={(event) => setCustomization((current) => ({ ...current, notes: event.target.value }))} placeholder="Extra cold, allergy note, or a little something for the barista..." rows={3} className="w-full resize-none rounded-2xl border border-[#09403B]/10 bg-white/55 px-4 py-3 text-sm font-medium text-[#09403B] outline-none placeholder:text-[#09403B]/35 focus:border-[#09403B]" />
            </OptionGroup>
          </div>
        </div>

        <div className="flex items-center gap-3 border-t border-[#09403B]/10 bg-[#F2DBB2] p-4 sm:p-5">
          <div className="flex items-center gap-2 rounded-full border border-[#09403B]/10 bg-[#f8efd9] p-1">
            <button onClick={() => setQuantity((current) => Math.max(1, current - 1))} disabled={quantity === 1} aria-label="Decrease quantity" className="flex h-8 w-8 items-center justify-center rounded-full bg-[#09403B] text-[#F2DBB2] disabled:opacity-30"><Minus className="h-3 w-3" /></button>
            <span className="w-5 text-center text-sm font-black text-[#09403B]">{quantity}</span>
            <button onClick={() => setQuantity((current) => current + 1)} aria-label="Increase quantity" className="flex h-8 w-8 items-center justify-center rounded-full bg-[#09403B] text-[#F2DBB2]"><Plus className="h-3 w-3" /></button>
          </div>
          <button onClick={() => { onAddToCart(item, customization, quantity); onClose() }} className="flex min-h-12 flex-1 items-center justify-between rounded-full bg-[#09403B] px-5 text-sm font-black text-[#F2DBB2] transition-transform hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-[#09403B] focus:ring-offset-2 focus:ring-offset-[#F2DBB2]">
            <span>Add to order</span>
            <span>GH₵ {total.toFixed(2)}</span>
          </button>
        </div>
      </div>
    </div>
  )
}

function OptionGroup({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="mb-3 text-xs font-bold uppercase tracking-[0.22em] text-[#09403B]/55">{label}</p>
      {children}
    </div>
  )
}

function ChoiceButton({ selected, onClick, children }: { selected: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button type="button" onClick={onClick} className={`flex min-h-12 items-center justify-between rounded-2xl border px-3 py-2 text-left text-sm font-bold transition-colors focus:outline-none focus:ring-2 focus:ring-[#09403B] ${selected ? "border-[#09403B] bg-[#09403B] text-[#F2DBB2]" : "border-[#09403B]/10 bg-white/55 text-[#09403B] hover:border-[#09403B]/35"}`}>
      {children}
      {selected && <Check className="h-4 w-4 shrink-0" />}
    </button>
  )
}
"use client"

import { motion, useInView } from "framer-motion"
import { useRef } from "react"
import { Leaf, Droplets, Sun, Recycle, Apple, Users, ShieldCheck, Sprout } from "lucide-react"

const environmentPillars = [
  {
    icon: Leaf,
    title: "Natural Ingredients Only",
    description:
      "We source fresh, seasonal, and locally grown fruits and vegetables. No imported concentrates, no synthetic additives — just nature.",
  },
  {
    icon: Recycle,
    title: "Minimal Waste",
    description:
      "Fruit peels become compost. We work with zero-waste principles in our kitchen and minimize single-use plastics in packaging.",
  },
  {
    icon: Sprout,
    title: "Local Farming Support",
    description:
      "We buy direct from Ghanaian farmers in communities near Accra. Your sip supports smallholder agriculture and rural livelihoods.",
  },
  {
    icon: Sun,
    title: "Clean Operations",
    description:
      "We're working toward solar-powered blending and refrigeration at our Teshie bar — clean energy for clean drinks.",
  },
]

const healthPillars = [
  {
    icon: Apple,
    title: "Whole Fruit Blending",
    description:
      "We blend the whole fruit, not just the juice. That means you get the fibre, vitamins, and all the goodness intact.",
  },
  {
    icon: Droplets,
    title: "Hydration & Electrolytes",
    description:
      "Our drinks are designed to hydrate naturally. Coconut water bases, cucumber blends, and high-water-content fruits keep you replenished.",
  },
  {
    icon: ShieldCheck,
    title: "No Hidden Sugars",
    description:
      "We never add refined sugar. Where sweetness is needed, we use natural sources — ripe bananas, dates, or honey.",
  },
  {
    icon: Users,
    title: "Community Nutrition Access",
    description:
      "Frydays aims to make nutritious drinks affordable and accessible in Teshie — not a luxury, a daily habit.",
  },
]

const impactStats = [
  { number: "5+", label: "Local farms partnered" },
  { number: "100%", label: "Natural ingredients" },
  { number: "0", label: "Artificial preservatives" },
  { number: "1000s", label: "Healthy sips served" },
]

function PillarCard({ item, index, theme }: { item: typeof environmentPillars[0]; index: number; theme: "dark" | "light" }) {
  return (
    <motion.div
      className={`rounded-2xl p-6 border ${
        theme === "dark"
          ? "bg-[#F2DBB2]/10 border-[#F2DBB2]/10 hover:bg-[#F2DBB2]/15"
          : "bg-[#09403B]/5 border-[#09403B]/10 hover:bg-[#09403B]/10"
      } transition-colors`}
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1 }}
      whileHover={{ y: -4 }}
    >
      <div
        className={`w-10 h-10 rounded-xl flex items-center justify-center mb-4 ${
          theme === "dark" ? "bg-[#F2DBB2]/20" : "bg-[#09403B]/10"
        }`}
      >
        <item.icon className={`w-5 h-5 ${theme === "dark" ? "text-[#F2DBB2]" : "text-[#09403B]"}`} />
      </div>
      <h3 className={`font-black text-lg mb-2 ${theme === "dark" ? "text-[#F2DBB2]" : "text-[#09403B]"}`}>
        {item.title}
      </h3>
      <p className={`text-sm leading-relaxed font-medium ${theme === "dark" ? "text-[#F2DBB2]/60" : "text-[#09403B]/60"}`}>
        {item.description}
      </p>
    </motion.div>
  )
}

export function EsgContent() {
  const statsRef = useRef(null)
  const isInView = useInView(statsRef, { once: true })

  return (
    <>
      {/* Hero */}
      <section className="relative pt-36 pb-20 bg-[#09403B] overflow-hidden">
        <motion.div
          className="absolute inset-0 opacity-10"
          style={{ backgroundImage: "radial-gradient(circle at 50% 70%, #F2DBB2 0%, transparent 60%)" }}
        />
        <div className="max-w-5xl mx-auto px-6 relative z-10 text-center">
          <motion.span
            className="text-[#F2DBB2]/60 text-xs font-semibold tracking-[0.3em] uppercase"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            ESG — Our Contribution
          </motion.span>
          <motion.h1
            className="text-5xl md:text-7xl font-black text-[#F2DBB2] tracking-tight mt-3 leading-[0.95]"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.7 }}
          >
            Good for You.
            <br />
            <span className="text-[#F2DBB2]/60">Good for the Planet.</span>
          </motion.h1>
          <motion.p
            className="text-[#F2DBB2]/70 text-lg max-w-2xl mx-auto mt-6 leading-relaxed font-medium"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            At Frydays, sustainability and health aren't afterthoughts — they're at the heart of every drink we make.
            Here's how we're doing our part for the environment and for the people of Teshie.
          </motion.p>
        </div>
      </section>

      {/* Impact Stats */}
      <section ref={statsRef} className="py-14 bg-[#F2DBB2]">
        <div className="max-w-4xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {impactStats.map((stat, i) => (
              <motion.div
                key={stat.label}
                className="text-center"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ delay: i * 0.1, type: "spring", stiffness: 200 }}
              >
                <p className="text-4xl md:text-5xl font-black text-[#09403B]">{stat.number}</p>
                <p className="text-xs text-[#09403B]/50 font-semibold uppercase tracking-wide mt-1">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Environment Section */}
      <section className="py-20 bg-[#09403B]">
        <div className="max-w-5xl mx-auto px-6">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <span className="text-[#F2DBB2]/60 text-xs font-semibold tracking-[0.3em] uppercase">Environment</span>
            <h2 className="text-4xl font-black text-[#F2DBB2] tracking-tight mt-2">
              Brewing Responsibly
            </h2>
            <p className="text-[#F2DBB2]/60 mt-3 max-w-xl mx-auto font-medium">
              From farm to cup, we're committed to minimising our environmental footprint.
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {environmentPillars.map((item, i) => (
              <PillarCard key={item.title} item={item} index={i} theme="dark" />
            ))}
          </div>
        </div>
      </section>

      {/* Health Section */}
      <section className="py-20 bg-[#F2DBB2]">
        <div className="max-w-5xl mx-auto px-6">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <span className="text-[#09403B]/60 text-xs font-semibold tracking-[0.3em] uppercase">Health Benefits</span>
            <h2 className="text-4xl font-black text-[#09403B] tracking-tight mt-2">
              Drinks That Do Good
            </h2>
            <p className="text-[#09403B]/60 mt-3 max-w-xl mx-auto font-medium">
              Every item on our menu is designed with your wellbeing in mind — not just your taste buds.
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {healthPillars.map((item, i) => (
              <PillarCard key={item.title} item={item} index={i} theme="light" />
            ))}
          </div>
        </div>
      </section>

      {/* Social Commitment */}
      <section className="py-20 bg-[#09403B]">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <span className="text-[#F2DBB2]/60 text-xs font-semibold tracking-[0.3em] uppercase">Social</span>
            <h2 className="text-4xl font-black text-[#F2DBB2] tracking-tight mt-2 mb-6">
              Our Pledge to Teshie
            </h2>
            <p className="text-[#F2DBB2]/70 text-lg leading-relaxed font-medium max-w-2xl mx-auto mb-8">
              Frydays is committed to being a positive force in the Teshie community. We hire locally, support local
              farmers, and actively participate in neighbourhood health and wellness initiatives.
            </p>
            <div className="grid sm:grid-cols-3 gap-4">
              {[
                { title: "Local Hiring", body: "100% of our staff are hired from within Teshie and surrounding communities." },
                { title: "School Outreach", body: "We host free nutrition workshops at local schools to promote healthy eating habits." },
                { title: "Market Partnerships", body: "We buy fresh produce directly from Teshie and La market vendors." },
              ].map((pledge, i) => (
                <motion.div
                  key={pledge.title}
                  className="bg-[#F2DBB2]/10 border border-[#F2DBB2]/10 rounded-2xl p-6 text-left"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                >
                  <h3 className="font-black text-[#F2DBB2] mb-2">{pledge.title}</h3>
                  <p className="text-[#F2DBB2]/60 text-sm font-medium leading-relaxed">{pledge.body}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>
    </>
  )
}

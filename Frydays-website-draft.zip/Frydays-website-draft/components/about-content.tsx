"use client"

import { motion, useInView } from "framer-motion"
import { useRef } from "react"
import Image from "next/image"
import { Heart, Leaf, TrendingUp, Users } from "lucide-react"

const values = [
  {
    icon: Leaf,
    title: "Keep it fresh.",
    description: "Use good ingredients and serve them with care. We keep our blends fresh, source thoughtfully, and make each drink to order.",
  },
  {
    icon: TrendingUp,
    title: "Keep it simple.",
    description: "Good drinks do not need to be complicated. Clear flavours, honest ingredients, and a menu that is easy to make your own.",
  },
  {
    icon: Users,
    title: "Keep people close.",
    description: "The best moments are better when shared. Frydays is a place for neighbours, friends, families, and the wider community.",
  },
  {
    icon: Heart,
    title: "Keep growing.",
    description: "Build something that creates opportunities for others — for our team, our partners, our suppliers, and our community.",
  },
]

const timelineItems = [
  { year: "2021", event: "Frydays was founded with one blender and a dream in Teshie." },
  { year: "2022", event: "Launched our first bubble tea menu — instantly sold out every Friday." },
  { year: "2023", event: "Expanded to smoothies and began catering local events in Accra." },
  { year: "2024", event: "Opened our full bar location in Teshie, welcoming hundreds of daily visitors." },
  { year: "2025", event: "Partnered with local farms for 100% locally sourced ingredients." },
  { year: "2026", event: "Going digital — now taking online orders and event bookings." },
]

export function AboutContent() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-50px" })

  return (
    <>
      {/* Hero */}
      <section className="relative pt-36 pb-20 bg-[#09403B] overflow-hidden">
        <motion.div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: "radial-gradient(circle at 30% 50%, #F2DBB2 0%, transparent 60%)",
          }}
        />
        <div className="max-w-5xl mx-auto px-6 relative z-10">
          <motion.span
            className="text-[#F2DBB2]/60 text-xs font-semibold tracking-[0.3em] uppercase"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            Our Story
          </motion.span>
          <motion.h1
            className="text-5xl md:text-7xl font-black text-[#F2DBB2] tracking-tight mt-3 leading-[0.95]"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.7 }}
          >
            Born in Teshie,
            <br />
            <span className="text-[#F2DBB2]/60">Brewed with Love.</span>
          </motion.h1>
          <motion.p
            className="text-[#F2DBB2]/70 text-lg max-w-xl mt-6 leading-relaxed font-medium"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            Frydays Bubble & Smoothies Bar started as a weekend passion project and grew into Teshie's
            favourite fresh drink destination. We believe every sip should feel like a treat — and be genuinely good for you.
          </motion.p>
        </div>
      </section>

      {/* Logo + Mission */}
      <section className="py-20 bg-[#F2DBB2]">
        <div className="max-w-5xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
              className="relative"
            >
              <div className="relative w-full aspect-square max-w-sm mx-auto">
                <motion.div
                  className="absolute inset-0 bg-[#09403B]/10 rounded-[40%_60%_60%_40%/50%_50%_60%_40%]"
                  animate={{
                    borderRadius: [
                      "40% 60% 60% 40% / 50% 50% 60% 40%",
                      "60% 40% 40% 60% / 60% 40% 50% 50%",
                      "40% 60% 60% 40% / 50% 50% 60% 40%",
                    ],
                  }}
                  transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
                />
                <Image
                  src="/images/frydays-black.png"
                  alt="Frydays Logo"
                  fill
                  className="object-contain relative z-10 p-8"
                />
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
              className="space-y-6"
            >
              <h2 className="text-4xl font-black text-[#09403B] tracking-tight">
                Our Mission
              </h2>
              <p className="text-[#09403B]/70 leading-relaxed font-medium">
                To make fresh, healthy, and delicious bubble teas and smoothies accessible to everyone in Teshie and
                beyond — without compromising on quality or natural goodness.
              </p>
              <p className="text-[#09403B]/70 leading-relaxed font-medium">
                We're not just a bar. We're a community hub where neighbours meet, friends catch up, and
                everyone leaves happier (and healthier) than when they arrived.
              </p>
              <div className="flex items-center gap-4 pt-2">
                <div className="text-center">
                  <p className="text-3xl font-black text-[#09403B]">5+</p>
                  <p className="text-xs text-[#09403B]/50 font-semibold uppercase tracking-wide">Years Active</p>
                </div>
                <div className="w-px h-10 bg-[#09403B]/20" />
                <div className="text-center">
                  <p className="text-3xl font-black text-[#09403B]">20+</p>
                  <p className="text-xs text-[#09403B]/50 font-semibold uppercase tracking-wide">Menu Items</p>
                </div>
                <div className="w-px h-10 bg-[#09403B]/20" />
                <div className="text-center">
                  <p className="text-3xl font-black text-[#09403B]">1000s</p>
                  <p className="text-xs text-[#09403B]/50 font-semibold uppercase tracking-wide">Happy Sippers</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-[#09403B]">
        <div className="max-w-5xl mx-auto px-6">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-black text-[#F2DBB2] tracking-tight">What We Stand For</h2>
            <p className="text-[#F2DBB2]/60 mt-3 font-medium">The four ideas behind every sip we serve.</p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {values.map((val, i) => (
              <motion.div
                key={val.title}
                className="bg-[#F2DBB2]/10 border border-[#F2DBB2]/10 rounded-2xl p-6 hover:bg-[#F2DBB2]/15 transition-colors"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -4 }}
              >
                <div className="w-10 h-10 rounded-xl bg-[#F2DBB2]/20 flex items-center justify-center mb-4">
                  <val.icon className="w-5 h-5 text-[#F2DBB2]" />
                </div>
                <h3 className="font-black text-[#F2DBB2] text-lg mb-2">{val.title}</h3>
                <p className="text-[#F2DBB2]/60 text-sm leading-relaxed font-medium">{val.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-20 bg-[#F2DBB2]">
        <div className="max-w-3xl mx-auto px-6">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-black text-[#09403B] tracking-tight">Our Journey</h2>
          </motion.div>

          <div ref={ref} className="space-y-0">
            {timelineItems.map((item, i) => (
              <motion.div
                key={item.year}
                className="flex gap-6"
                initial={{ opacity: 0, x: -20 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{ delay: i * 0.1, duration: 0.5 }}
              >
                <div className="flex flex-col items-center">
                  <div className="w-10 h-10 rounded-full bg-[#09403B] text-[#F2DBB2] flex items-center justify-center text-xs font-black shrink-0">
                    {item.year.slice(2)}
                  </div>
                  {i < timelineItems.length - 1 && (
                    <div className="w-0.5 h-12 bg-[#09403B]/20 my-1" />
                  )}
                </div>
                <div className="pb-10">
                  <p className="text-xs font-black text-[#09403B]/50 uppercase tracking-widest mb-1">{item.year}</p>
                  <p className="text-[#09403B]/80 font-medium leading-relaxed">{item.event}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}

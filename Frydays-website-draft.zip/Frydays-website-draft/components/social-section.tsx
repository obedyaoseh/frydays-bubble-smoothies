"use client"

import { motion, useInView } from "framer-motion"
import { useRef } from "react"
import { Facebook, Heart, Instagram, Linkedin, Music2 } from "lucide-react"
import Image from "next/image"

const galleryItems = [
  { image: "/images/signature-matcha.jpg", name: "Matcha Cloud", likes: "3.2k" },
  { image: "/images/signature-blueberry.jpg", name: "Blueberry Slush", likes: "1.8k" },
  { image: "/images/signature-pistachio.jpg", name: "Pistachio Cream", likes: "2.6k" },
  { image: "/images/signature-matcha-pour.jpg", name: "Matcha Pour", likes: "2.1k" },
  { image: "/images/signature-green-pour.jpg", name: "Green Glow", likes: "1.4k" },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.06, delayChildren: 0.15 },
  },
}

const itemVariants = {
  hidden: { opacity: 0, scale: 0.8, y: 20 },
  visible: {
    opacity: 1,
    scale: 1,
    y: 0,
    transition: { type: "spring", stiffness: 100, damping: 20 },
  },
}

export function SocialSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-50px" })

  return (
    <section id="gallery" className="relative py-16 bg-[#09403B] overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: [0.25, 0.4, 0.25, 1] }}
          className="text-center mb-10"
        >
          <motion.span
            className="text-[#F2DBB2]/60 text-xs font-semibold tracking-widest uppercase inline-block"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            Fresh from the Bar
          </motion.span>
          <h2 className="text-3xl md:text-5xl font-black text-[#F2DBB2] tracking-tight mt-2 overflow-hidden">
            <motion.span
              className="inline-block"
              initial={{ y: 100 }}
              whileInView={{ y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1], delay: 0.2 }}
            >
              Follow Our{" "}
            </motion.span>
            <motion.span
              className="text-[#F2DBB2] underline decoration-[#F2DBB2]/30 inline-block"
              initial={{ y: 100 }}
              whileInView={{ y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1], delay: 0.3 }}
            >
              Journey
            </motion.span>
          </h2>
        </motion.div>

        <motion.div
          ref={ref}
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {galleryItems.map((post, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              whileHover={{
                scale: 1.05,
                zIndex: 10,
                transition: { type: "spring", stiffness: 300, damping: 20 },
              }}
              className="relative aspect-square rounded-xl overflow-hidden group cursor-pointer"
            >
              <Image
                src={post.image}
                alt={post.name}
                fill
                className="object-cover grayscale group-hover:grayscale-0 transition-all duration-500"
              />
              <div className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-2 bg-gradient-to-t from-[#09403B]/90 via-[#09403B]/45 to-transparent px-3 pb-3 pt-8 text-[#F2DBB2]">
                <span className="text-xs font-black leading-tight">{post.name}</span>
                <span className="inline-flex shrink-0 items-center gap-1 text-xs font-bold" aria-label={`${post.likes} likes`}>
                  <Heart className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
                  {post.likes}
                </span>
              </div>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          className="flex justify-center mt-8"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
        >
          <div className="flex flex-wrap justify-center gap-3">
          <motion.a
            href="https://www.instagram.com/frydaysghana?mdxt=eXRvZTRuZTZuczJt&utm_source=qr"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 bg-[#F2DBB2] text-[#09403B] px-6 py-3 rounded-full font-bold text-sm tracking-wide relative overflow-hidden group"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            transition={{ type: "spring", stiffness: 400, damping: 17 }}
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full"
              whileHover={{ x: "200%" }}
              transition={{ duration: 0.6 }}
            />
            <Instagram className="w-4 h-4 relative z-10" />
            <span className="relative z-10">Instagram</span>
          </motion.a>
          <motion.a
            href="https://www.tiktok.com/@frydaysghana"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="TikTok"
            className="flex items-center gap-2 border border-[#F2DBB2]/35 text-[#F2DBB2] px-6 py-3 rounded-full font-bold text-sm tracking-wide relative overflow-hidden group"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            transition={{ type: "spring", stiffness: 400, damping: 17 }}
          >
            <Music2 className="w-4 h-4" aria-hidden="true" />
            <span>TikTok</span>
          </motion.a>
          <motion.a
            href="https://www.linkedin.com/company/frydays-bubble-smoothies-bar/home/?viewAsMember=true"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn"
            className="flex items-center gap-2 border border-[#F2DBB2]/35 text-[#F2DBB2] px-6 py-3 rounded-full font-bold text-sm tracking-wide relative overflow-hidden group"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            transition={{ type: "spring", stiffness: 400, damping: 17 }}
          >
            <Linkedin className="w-4 h-4" aria-hidden="true" />
            <span>LinkedIn</span>
          </motion.a>
          <motion.a
            href="https://www.facebook.com/share/1C78bDbC2J/?mibextid=wwXIfr"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Facebook"
            className="flex items-center gap-2 border border-[#F2DBB2]/35 text-[#F2DBB2] px-6 py-3 rounded-full font-bold text-sm tracking-wide relative overflow-hidden group"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            transition={{ type: "spring", stiffness: 400, damping: 17 }}
          >
            <Facebook className="w-4 h-4" aria-hidden="true" />
            <span>Facebook</span>
          </motion.a>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

"use client"

import { motion } from "framer-motion"
import { useState } from "react"
import Link from "next/link"
import { ArrowRight, Facebook, Handshake, Instagram, Linkedin, Mail, MapPin, MessageCircle, Phone, Send } from "lucide-react"

const contactPathways = [
  {
    icon: MapPin,
    title: "Visit Us",
    description: "Come in, pull up a chair, and make yourself comfortable.",
    detail: "Teshie, Accra, Ghana",
    href: "#location",
    cta: "Find Frydays near you",
  },
  {
    icon: MessageCircle,
    title: "Talk to Us",
    description: "Questions, feedback, collaborations, or just something you want us to know?",
    detail: "We would love to hear from you.",
    href: "#message",
    cta: "Send us a message",
  },
  {
    icon: Handshake,
    title: "Work With Us",
    description: "Interested in investing, franchising, supplying, or partnering with Frydays?",
    detail: "Let’s build something good together.",
    href: "/franchise",
    cta: "Partner with us",
  },
]

export function ContactContent() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "", website: "" })
  const [sent, setSent] = useState(false)
  const [sending, setSending] = useState(false)
  const [sendError, setSendError] = useState("")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value })
    setSent(false)
    setSendError("")
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (sending) return

    setSending(true)
    setSent(false)
    setSendError("")
    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      })
      const result = await response.json().catch(() => null)
      if (!response.ok) {
        throw new Error(result?.error ?? "We couldn't send your message right now. Please try again.")
      }
      setForm({ name: "", email: "", subject: "", message: "", website: "" })
      setSent(true)
    } catch (error) {
      setSendError(error instanceof Error ? error.message : "We couldn't send your message right now. Please try again.")
    } finally {
      setSending(false)
    }
  }

  const inputClass =
    "w-full bg-[#09403B]/5 border-2 border-[#09403B]/15 rounded-xl px-4 py-3 text-[#09403B] placeholder:text-[#09403B]/40 text-sm font-medium focus:outline-none focus:border-[#09403B] transition-all duration-300"

  return (
    <>
      {/* Hero */}
      <section className="relative pt-36 pb-20 bg-[#09403B] overflow-hidden">
        <motion.div
          className="absolute inset-0 opacity-10"
          style={{ backgroundImage: "radial-gradient(circle at 70% 50%, #F2DBB2 0%, transparent 60%)" }}
        />
        <div className="max-w-5xl mx-auto px-6 relative z-10">
          <motion.span
            className="text-[#F2DBB2]/60 text-xs font-semibold tracking-[0.3em] uppercase"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            Get in Touch
          </motion.span>
          <motion.h1
            className="text-5xl md:text-7xl font-black text-[#F2DBB2] tracking-tight mt-3 leading-[0.95]"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.7 }}
          >
            Visit Frydays in Teshie, Accra.
          </motion.h1>
          <motion.p
            className="text-[#F2DBB2]/70 text-lg max-w-xl mt-6 leading-relaxed font-medium"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            Whether you have a question, want to say hello, explore a partnership, or simply want to find your nearest Frydays — we would love to hear from you.
          </motion.p>
        </div>
      </section>

      {/* Contact Details */}
      <section className="py-16 bg-[#F2DBB2]">
        <div className="max-w-5xl mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-4 mb-16">
            {contactPathways.map((pathway, i) => (
              <motion.div
                key={pathway.title}
                className="bg-[#09403B] rounded-2xl p-6 flex flex-col"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -4 }}
              >
                <div className="w-10 h-10 rounded-xl bg-[#F2DBB2]/10 flex items-center justify-center mb-4">
                  <pathway.icon className="w-5 h-5 text-[#F2DBB2]" />
                </div>
                <h3 className="font-black text-[#F2DBB2] mb-2">{pathway.title}</h3>
                <p className="text-[#F2DBB2]/60 text-sm font-medium leading-relaxed">{pathway.description}</p>
                <p className="text-[#F2DBB2]/45 text-xs font-semibold mt-3">{pathway.detail}</p>
                <Link href={pathway.href} className="inline-flex items-center gap-2 text-[#F2DBB2] text-xs font-black mt-auto pt-6">
                  {pathway.cta} <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </motion.div>
            ))}
          </div>

          {/* Contact Form + Map */}
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Form */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <h2 id="message" className="text-3xl font-black text-[#09403B] mb-6">Send Us a Message</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div aria-hidden="true" className="hidden">
                  <label htmlFor="contact-website">Leave this field blank</label>
                  <input
                    id="contact-website"
                    name="website"
                    value={form.website}
                    onChange={handleChange}
                    tabIndex={-1}
                    autoComplete="off"
                  />
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-[#09403B]/60 uppercase tracking-wide block mb-1">Name</label>
                    <input
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      placeholder="Your name"
                      required
                      className={inputClass}
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-[#09403B]/60 uppercase tracking-wide block mb-1">Email</label>
                    <input
                      name="email"
                      type="email"
                      value={form.email}
                      onChange={handleChange}
                      placeholder="your@email.com"
                      required
                      className={inputClass}
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-semibold text-[#09403B]/60 uppercase tracking-wide block mb-1">Subject</label>
                  <select
                    name="subject"
                    value={form.subject}
                    onChange={handleChange}
                    required
                    className={inputClass}
                  >
                    <option value="">Choose a subject...</option>
                    <option value="order">Place an Order</option>
                    <option value="event">Book for an Event</option>
                    <option value="corporate">Corporate Wellness</option>
                    <option value="partnership">Partnership or Franchise</option>
                    <option value="supplier">Supplier Enquiry</option>
                    <option value="general">General Enquiry</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-[#09403B]/60 uppercase tracking-wide block mb-1">Message</label>
                  <textarea
                    name="message"
                    value={form.message}
                    onChange={handleChange}
                    placeholder="Tell us what you need..."
                    rows={5}
                    required
                    className={`${inputClass} resize-none`}
                  />
                </div>
                {sent && (
                  <p role="status" className="text-sm font-semibold text-[#09403B]">
                    Thanks, your message was sent to the Frydays team.
                  </p>
                )}
                {sendError && (
                  <p role="alert" className="text-sm font-semibold text-red-700">
                    {sendError}{" "}
                    <a href="mailto:frydaysghana@gmail.com" className="underline underline-offset-2">
                      Email us directly
                    </a>
                    .
                  </p>
                )}
                <motion.button
                  type="submit"
                  disabled={sending}
                  className="w-full flex items-center justify-center gap-2 bg-[#09403B] text-[#F2DBB2] px-6 py-4 rounded-xl font-bold text-sm tracking-wide relative overflow-hidden disabled:cursor-not-allowed disabled:opacity-70"
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                >
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent"
                    initial={{ x: "-100%" }}
                    whileHover={{ x: "100%" }}
                    transition={{ duration: 0.5 }}
                  />
                  <Send className="w-4 h-4 relative z-10" />
                  <span className="relative z-10">
                    {sending ? "Sending…" : sent ? "Message Sent!" : "Send Message"}
                  </span>
                </motion.button>
              </form>
            </motion.div>

            {/* Map / Location card */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
              className="space-y-6"
            >
              <h2 id="location" className="text-3xl font-black text-[#09403B]">Find Frydays near you</h2>

              <div className="w-full aspect-[4/3] rounded-2xl overflow-hidden bg-[#09403B]/10 border-2 border-[#09403B]/10">
                <iframe
                  title="Frydays Bubble & Smoothies Bar"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d791.1015692151026!2d-0.12220157063659529!3d5.59444013214007!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf856dcb1146f9%3A0xc93098ff499efd2a!2sFrydays%20Bubble%20%26%20Smoothies%20Bar!5e0!3m2!1sen!2sgh!4v1792268350867!5m2!1sen!2sgh"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="strict-origin-when-cross-origin"
                  className="w-full h-full"
                />
              </div>

              {/* Social links */}
              <div className="bg-[#09403B] rounded-2xl p-6">
                <h3 className="font-black text-[#F2DBB2] mb-2">Stay in the Loop</h3>
                <p className="text-[#F2DBB2]/55 text-sm leading-relaxed mb-5">New flavours. New locations. Community moments. The occasional surprise.</p>
                <div className="space-y-3">
                  <a
                    href="https://www.instagram.com/frydaysghana?mdxt=eXRvZTRuZTZuczJt&utm_source=qr"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 text-[#F2DBB2]/70 hover:text-[#F2DBB2] transition-colors"
                  >
                    <Instagram className="w-5 h-5" />
                    <span className="font-semibold text-sm">Instagram</span>
                  </a>
                  <a
                    href="https://www.tiktok.com/@frydaysghana"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 text-[#F2DBB2]/70 hover:text-[#F2DBB2] transition-colors"
                  >
                    <span className="w-5 h-5 flex items-center justify-center text-xs font-black">TT</span>
                    <span className="font-semibold text-sm">TikTok</span>
                  </a>
                  <a
                    href="https://www.facebook.com/share/1C78bDbC2J/?mibextid=wwXIfr"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 text-[#F2DBB2]/70 hover:text-[#F2DBB2] transition-colors"
                  >
                    <Facebook className="w-5 h-5" />
                    <span className="font-semibold text-sm">Facebook</span>
                  </a>
                  <a
                    href="https://www.linkedin.com/company/frydays-bubble-smoothies-bar/home/?viewAsMember=true"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 text-[#F2DBB2]/70 hover:text-[#F2DBB2] transition-colors"
                  >
                    <Linkedin className="w-5 h-5" />
                    <span className="font-semibold text-sm">LinkedIn</span>
                  </a>
                </div>
                <div className="mt-5 border-t border-[#F2DBB2]/10 pt-4">
                  <a href="mailto:frydaysghana@gmail.com" className="flex items-center gap-3 text-[#F2DBB2]/70 hover:text-[#F2DBB2] transition-colors">
                    <Mail className="w-4 h-4" />
                    <span className="font-semibold text-sm">frydaysghana@gmail.com</span>
                  </a>
                  <a href="tel:+233596198209" className="flex items-center gap-3 text-[#F2DBB2]/70 hover:text-[#F2DBB2] transition-colors mt-3">
                    <Phone className="w-4 h-4" />
                    <span className="font-semibold text-sm">Call 059 619 8209</span>
                  </a>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  )
}

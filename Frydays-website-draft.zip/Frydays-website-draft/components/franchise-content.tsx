"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { ArrowRight, BarChart3, Handshake, Rocket, Store, CheckCircle2 } from "lucide-react"

const opportunities = [
  { icon: BarChart3, title: "Invest in Frydays", description: "Join us as we build a proudly Ghanaian food and beverage brand with a focus on quality, community, and sustainable growth.", cta: "Explore investment opportunities" },
  { icon: Store, title: "Bring Frydays to your community", description: "Have a location, business experience, or a community that needs a Frydays? Build with an established brand, products, systems, and support.", cta: "Explore franchising" },
]

const benefits = ["A recognisable, locally loved brand", "Menu and operations playbook", "Training from opening day through launch", "Supplier and sourcing guidance", "Marketing assets and campaign support", "A growing community of Frydays customers"]

export function FranchiseContent() {
  return (
    <>
      <section className="pt-36 pb-20 bg-[#09403B] text-[#F2DBB2]">
        <div className="max-w-5xl mx-auto px-6">
          <motion.span className="text-[#F2DBB2]/60 text-xs font-semibold tracking-[0.3em] uppercase" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>Investment &amp; Franchise</motion.span>
          <motion.h1 className="text-5xl md:text-7xl font-black tracking-tight mt-3 leading-[0.95]" initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
            Let&apos;s Grow Frydays
            <br /><span className="text-[#F2DBB2]/60">Together.</span>
          </motion.h1>
          <motion.p className="text-lg text-[#F2DBB2]/70 max-w-2xl mt-6 leading-relaxed font-medium" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
            Frydays started with a family and a simple idea. We are now building a brand with room to grow — across communities, cities, and eventually beyond Ghana. We are open to people who believe in the vision and want to be part of the journey.
          </motion.p>
          <motion.div className="flex flex-col sm:flex-row gap-3 mt-8" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
            <a href="#opportunities" className="rounded-full bg-[#F2DBB2] text-[#09403B] px-6 py-3 font-black text-sm inline-flex items-center justify-center gap-2">Explore opportunities <ArrowRight className="w-4 h-4" /></a>
            <Link href="/contact" className="rounded-full border-2 border-[#F2DBB2]/30 px-6 py-3 font-black text-sm inline-flex items-center justify-center">Start a conversation</Link>
          </motion.div>
        </div>
      </section>

      <section id="opportunities" className="py-20">
        <div className="max-w-5xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-6">
            {opportunities.map((opportunity, i) => (
              <motion.article key={opportunity.title} className="bg-[#09403B] rounded-3xl p-8 text-[#F2DBB2]" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} whileHover={{ y: -6 }}>
                <div className="w-12 h-12 rounded-2xl bg-[#F2DBB2]/15 flex items-center justify-center"><opportunity.icon className="w-6 h-6" /></div>
                <h2 className="text-2xl font-black mt-8">{opportunity.title}</h2>
                <p className="text-[#F2DBB2]/65 leading-relaxed mt-3 font-medium">{opportunity.description}</p>
                <Link href="/contact" className="inline-flex items-center gap-2 mt-8 text-sm font-black hover:gap-3 transition-all">{opportunity.cta} <ArrowRight className="w-4 h-4" /></Link>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-[#09403B] text-[#F2DBB2]">
        <div className="max-w-5xl mx-auto px-6 grid lg:grid-cols-2 gap-14 items-center">
          <div>
            <span className="text-[#F2DBB2]/60 text-xs font-semibold tracking-[0.3em] uppercase">Built to grow. Made to belong.</span>
            <h2 className="text-4xl font-black tracking-tight mt-3">Build something people love.</h2>
            <p className="text-[#F2DBB2]/65 mt-4 leading-relaxed font-medium">We are not looking for partners who simply want another business. We are looking for people who want to build something people love. From the first conversation to your first 1000 cups, our team helps protect the quality and warmth that make Frydays special.</p>
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            {benefits.map((benefit) => <div key={benefit} className="flex gap-3 items-start bg-[#F2DBB2]/10 rounded-xl p-4 text-sm font-semibold"><CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />{benefit}</div>)}
          </div>
        </div>
      </section>

      <section className="py-20 text-center">
        <Rocket className="w-10 h-10 mx-auto text-[#09403B]" />
        <h2 className="text-4xl font-black text-[#09403B] mt-4">You bring the passion. We bring the Frydays way.</h2>
        <p className="max-w-xl mx-auto mt-3 text-[#09403B]/60 font-medium">Tell us a little about yourself, your location, and whether you&apos;re interested in franchising or investment.</p>
        <Link href="/contact" className="mt-7 inline-flex items-center gap-2 rounded-full bg-[#09403B] text-[#F2DBB2] px-7 py-4 font-black text-sm"><Handshake className="w-4 h-4" /> Talk to our team</Link>
        <p className="mt-8 text-sm font-black tracking-wide text-[#09403B]">Frydays</p>
        <p className="mt-1 text-sm italic text-[#09403B]/55">Every day deserves a little Friday.</p>
      </section>
    </>
  )
}
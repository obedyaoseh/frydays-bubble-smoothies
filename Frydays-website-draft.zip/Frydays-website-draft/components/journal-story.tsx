import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, ArrowRight } from "lucide-react"
import { getJournalStory, journalStories } from "@/lib/journal-data"

export function JournalStory({ slug }: { slug: string }) {
  const story = getJournalStory(slug)
  if (!story) return null

  const currentIndex = journalStories.findIndex((item) => item.slug === slug)
  const nextStory = journalStories[(currentIndex + 1) % journalStories.length]

  return (
    <>
      <article className="bg-[#F2DBB2]">
        <section className="bg-[#09403B] pb-16 pt-32 text-[#F2DBB2] md:pb-24 md:pt-40">
          <div className="mx-auto max-w-5xl px-6">
            <Link href="/" className="inline-flex items-center gap-2 text-sm font-bold text-[#F2DBB2]/65 transition-colors hover:text-[#F2DBB2]">
              <ArrowLeft className="h-4 w-4" /> Back home
            </Link>
            <div className="mt-12 max-w-4xl">
              <p className="text-xs font-bold uppercase tracking-[0.28em] text-[#F2DBB2]/55">{story.category}</p>
              <h1 className="mt-4 max-w-3xl text-5xl font-black leading-[0.95] tracking-tight md:text-7xl">{story.title}</h1>
              <p className="mt-7 max-w-2xl text-lg font-medium leading-relaxed text-[#F2DBB2]/70">{story.excerpt}</p>
            </div>
          </div>
        </section>

        <section className="mx-auto grid max-w-5xl gap-10 px-6 py-16 md:grid-cols-[1.05fr_0.95fr] md:items-start md:gap-16 md:py-24">
          <div className="relative aspect-[4/5] overflow-hidden rounded-3xl bg-[#09403B]/10">
            <Image src={story.image} alt={story.title} fill priority className="object-cover" />
            <div className="absolute bottom-5 left-5 rounded-full bg-[#09403B] px-4 py-2 text-xs font-bold uppercase tracking-[0.18em] text-[#F2DBB2]">{story.accent}</div>
          </div>
          <div className="pt-1">
            <p className="text-xs font-bold uppercase tracking-[0.28em] text-[#09403B]/50">A note from Frydays</p>
            <div className="mt-8 space-y-6 text-lg font-medium leading-relaxed text-[#09403B]/75">
              {story.body.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
            </div>
            <Link href="/order" className="mt-10 inline-flex items-center gap-2 rounded-full bg-[#09403B] px-6 py-4 text-sm font-black text-[#F2DBB2] transition-transform hover:-translate-y-1">
              Find your next sip <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </section>
      </article>

      <section className="bg-[#f8efd9] py-16">
        <div className="mx-auto flex max-w-5xl flex-col justify-between gap-6 px-6 md:flex-row md:items-center">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.28em] text-[#09403B]/50">Next in the journal</p>
            <h2 className="mt-3 text-3xl font-black text-[#09403B]">{nextStory.title}</h2>
          </div>
          <Link href={`/blog/${nextStory.slug}`} className="inline-flex items-center gap-2 self-start rounded-full border-2 border-[#09403B] px-5 py-3 text-sm font-black text-[#09403B] transition-colors hover:bg-[#09403B] hover:text-[#F2DBB2]">
            Read next <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </>
  )
}
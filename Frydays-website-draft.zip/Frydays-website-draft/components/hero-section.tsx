"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

export function HeroSection() {
  return (
    <section
      id="hero"
      className="relative min-h-screen bg-[#F2DBB2] overflow-hidden flex items-center"
    >
      {/* Soft oversized shapes echo the reference's calm, editorial canvas. */}
      <motion.div
        aria-hidden="true"
        className="absolute -left-24 bottom-8 h-64 w-64 rounded-full bg-[#09403B]/[0.035]"
        animate={{ y: [0, -14, 0] }}
        transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        aria-hidden="true"
        className="absolute -right-20 top-20 h-96 w-96 rounded-full bg-[#09403B]/[0.035]"
        animate={{ scale: [1, 1.06, 1] }}
        transition={{ duration: 9, repeat: Infinity, ease: "easeInOut" }}
      />

      <div className="relative z-10 mx-auto flex min-h-screen w-full max-w-7xl flex-col justify-between px-6 pb-16 pt-28 md:pb-14">
        <div className="flex flex-1 flex-col justify-center">
          <motion.h1
            className="text-center text-[clamp(4rem,18vw,14rem)] font-black leading-[0.78] tracking-[-0.085em] text-[#09403B]"
            initial={{ opacity: 0, scale: 0.92, y: 24 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ delay: 0.15, duration: 0.8, ease: [0.25, 0.4, 0.25, 1] }}
          >
            <span className="block">FRYDAYS</span>
            <span className="mt-7 block text-[clamp(1rem,2.6vw,1.7rem)] font-bold leading-tight tracking-[0.04em]">
              Smoothies, Bubble Tea &amp; Pastries in Teshie, Accra
            </span>
          </motion.h1>

          <motion.div
            className="mt-8 text-center"
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.55, duration: 0.6 }}
          >
            <p className="text-[clamp(1.35rem,3.6vw,3rem)] font-semibold leading-none tracking-[0.04em] text-[#09403B]/70">
              Every Day Deserves a Little Friday.
            </p>
          </motion.div>
        </div>

        <div className="flex flex-col items-center justify-between gap-8 md:flex-row md:items-end">
          <motion.div
            className="grid grid-cols-2 gap-x-5 gap-y-2.5 text-xs font-medium text-[#09403B]/65 sm:grid-cols-3 md:max-w-[620px]"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.9, duration: 0.6 }}
          >
            {["Fresh fruit blends", "Custom sweetness", "500 ml regular cups", "Bubble tea toppings", "Pastries & desserts", "Pickup & local delivery"].map((benefit) => (
              <span key={benefit} className="flex items-center gap-2 whitespace-nowrap">
                <span className="h-2 w-2 rounded-full bg-[#09403B]" />
                {benefit}
              </span>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1, duration: 0.6 }}
          >
            <Link
              href="/order"
              className="group inline-flex items-center gap-3 rounded-md bg-[#F5B735] px-6 py-4 text-xs font-black uppercase tracking-wide text-[#09403B] shadow-sm transition-all hover:-translate-y-1 hover:bg-[#e9a824] hover:shadow-lg"
            >
              Order now
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

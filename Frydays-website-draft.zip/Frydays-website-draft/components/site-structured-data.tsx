import { SITE_NAME, SITE_URL } from "@/lib/seo"

const socialProfiles = [
  "https://www.instagram.com/frydaysghana",
  "https://www.tiktok.com/@frydaysghana",
  "https://www.linkedin.com/company/frydays-bubble-smoothies-bar/",
  "https://www.facebook.com/share/1C78bDbC2J/",
]

const structuredData = [
  {
    "@context": "https://schema.org",
    "@type": "Organization",
    "@id": `${SITE_URL}/#organization`,
    name: SITE_NAME,
    url: SITE_URL,
    logo: `${SITE_URL}/images/frydays-logo.jpg`,
    sameAs: socialProfiles,
  },
  {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "@id": `${SITE_URL}/#website`,
    name: SITE_NAME,
    url: SITE_URL,
    inLanguage: "en-GH",
    publisher: { "@id": `${SITE_URL}/#organization` },
  },
  {
    "@context": "https://schema.org",
    "@type": "Restaurant",
    "@id": `${SITE_URL}/#business`,
    name: SITE_NAME,
    url: SITE_URL,
    image: `${SITE_URL}/opengraph-image`,
    logo: `${SITE_URL}/images/frydays-logo.jpg`,
    telephone: "+233596198209",
    email: "frydaysghana@gmail.com",
    priceRange: "GH₵5–46",
    currenciesAccepted: "GHS",
    servesCuisine: ["Bubble tea", "Smoothies", "Pastries"],
    hasMenu: `${SITE_URL}/order`,
    address: {
      "@type": "PostalAddress",
      addressLocality: "Teshie, Accra",
      addressRegion: "Greater Accra Region",
      addressCountry: "GH",
    },
    geo: {
      "@type": "GeoCoordinates",
      latitude: 5.59444013214007,
      longitude: -0.12220157063659529,
    },
    sameAs: socialProfiles,
    parentOrganization: { "@id": `${SITE_URL}/#organization` },
  },
]

export function SiteStructuredData() {
  return (
    <>
      {structuredData.map((schema) => (
        <script
          key={schema["@id"]}
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(schema).replace(/</g, "\\u003c"),
          }}
        />
      ))}
    </>
  )
}

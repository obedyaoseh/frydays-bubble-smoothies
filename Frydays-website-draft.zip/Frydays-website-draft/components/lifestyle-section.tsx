"use client"

import { motion, useInView } from "framer-motion"
import { useRef } from "react"

const testimonials = [
  {
    handle: "@kwame_teshie",
    text: "Frydays is my go-to after the gym. The green detox hits different — so fresh and natural! 🌿",
    likes: "1.2k",
  },
  {
    handle: "@abena_smoothielover",
    text: "Finally a smoothie bar in Teshie that actually uses real fruit. The berry blast is incredible.",
    likes: "876",
  },
  {
    handle: "@emmanuel_accra",
    text: "Ordered Frydays for our office event. Everyone was obsessed with the bubble tea bar setup!",
    likes: "2.1k",
  },
]

const cardVariants = {
  hidden: { opacity: 0, y: 30, scale: 0.95 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { type: "spring", stiffness: 100, damping: 20 },
  },
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1, delayChildren: 0.2 },
  },
}

export function LifestyleSection() {
  const cardsRef = useRef(null)
  const isCardsInView = useInView(cardsRef, { once: true, margin: "-50px" })

  return (
    <section id="community-love" className="relative py-20 bg-[#09403B] overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: [0.25, 0.4, 0.25, 1] }}
          className="text-center mb-12"
        >
          <motion.span
            className="text-[#F2DBB2]/60 text-sm font-semibold tracking-widest uppercase inline-block"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            Community Love
          </motion.span>
          <h2 className="text-4xl md:text-6xl font-black text-[#F2DBB2] tracking-tight mt-4 overflow-hidden">
            <motion.span
              className="inline-block"
              initial={{ y: 100 }}
              whileInView={{ y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1], delay: 0.15 }}
            >
              What Teshie{" "}
            </motion.span>
            <motion.span
              className="text-[#F2DBB2]/70 inline-block"
              initial={{ y: 100 }}
              whileInView={{ y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1], delay: 0.25 }}
            >
              is Saying
            </motion.span>
          </h2>
        </motion.div>

        <motion.div
          ref={cardsRef}
          className="grid md:grid-cols-3 gap-6"
          variants={containerVariants}
          initial="hidden"
          animate={isCardsInView ? "visible" : "hidden"}
        >
          {testimonials.map((post, index) => (
            <motion.div
              key={index}
              variants={cardVariants}
              whileHover={{
                y: -8,
                scale: 1.02,
                transition: { type: "spring", stiffness: 400, damping: 17 },
              }}
              className="bg-[#F2DBB2]/10 backdrop-blur-sm rounded-2xl p-6 border border-[#F2DBB2]/10 cursor-pointer"
            >
              <div className="flex items-center gap-3 mb-4">
                <motion.div
                  className="w-10 h-10 rounded-full bg-[#F2DBB2]/20 flex items-center justify-center"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ type: "spring", stiffness: 400, damping: 17 }}
                >
                  <span className="text-[#F2DBB2] font-bold text-sm">{post.handle.charAt(1).toUpperCase()}</span>
                </motion.div>
                <span className="text-[#F2DBB2]/60 text-sm font-medium">{post.handle}</span>
              </div>
              <p className="text-[#F2DBB2] text-base leading-relaxed font-medium">{post.text}</p>
              <motion.div
                className="flex items-center gap-2 mt-4 text-[#F2DBB2]/40 text-sm font-semibold"
                whileHover={{ color: "#F2DBB2" }}
                transition={{ duration: 0.2 }}
              >
                <motion.svg
                  className="w-4 h-4"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                  whileHover={{ scale: 1.2 }}
                  transition={{ type: "spring", stiffness: 400, damping: 17 }}
                >
                  <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                </motion.svg>
                {post.likes}
              </motion.div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
